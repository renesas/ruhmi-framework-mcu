/*
* Copyright (c) 2020 - 2025 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/
/**********************************************************************************************************************
 * File Name    : ruhmi_perf_eval.c
 * Description  : .
 **********************************************************************************************************************/
#include "hal_data.h"
#include "utils/time_counter.h"
#include "utils/external_memory.h"

// ############### User variable and function definition ###############

// ToDo

// ############ End of User variable and function definition ###########

// ############### USER SETTING ###############
#define EXTERNAL_MEMORY_OSPI_ENABLE  (0)
#define EXTERNAL_MEMORY_SDRAM_ENABLE (0)
#define INTERNAL_MEMORY_SIP_ENABLE   (0)
// ############ END OF USER SETTING ###########

volatile uint32_t ruhmi_perf_eval_time = 0;

void ruhmi_perf_eval(void)
{
    fsp_err_t fsp_status = FSP_SUCCESS;
    volatile uint32_t t1, t2 = 0;

    TimeCounter_Init();

#if defined(R_NPU)
    fsp_status = RM_ETHOSU_Open(&g_rm_ethosu0_ctrl, &g_rm_ethosu0_cfg);
    if(FSP_SUCCESS != fsp_status)
    {
        __BKPT(0);
    }
#endif

    TimeCounter_CountReset();

    t1 = TimeCounter_CurrentCountGet();

    // ############### User inference execution code ###############

    // ToDo

    // ############ End of user inference execution code ###########

    t2 = TimeCounter_CurrentCountGet();

    if(t1 < t2)
    {
        ruhmi_perf_eval_time = t2 - t1;
    }
    else
    {
        // Timer overflow may happen
        __BKPT(0);
    }

    // Successful done if the program stops at the following BP
    __BKPT(0);
}

void ruhmi_external_memory_init(void)
{
#if (EXTERNAL_MEMORY_OSPI_ENABLE == 1)
#if __has_include("r_ospi_b.h")
    user_ospi_b_init((void *)&g_ospi0);
#else
#warning "Add and configure R_OSPI_B driver stack on FSP configurator, or add your own code below"
#endif
#endif

#if (EXTERNAL_MEMORY_SDRAM_ENABLE == 1)
#if (BSP_CFG_SDRAM_ENABLED == 1)
    // Since SDRAM memory initialization is done in R_BSP_WarmStart(), no additional code is needed here.
#else
#warning "Enable and configure SDRAM setting in BSP tab property on FSP configurator"
#endif
#endif

#if (INTERNAL_MEMORY_SIP_ENABLE == 1)
#if (BSP_CFG_OSPI_B_STARTUP_ENABLED == 1) && defined(BSP_CFG_OSPI_B_STARTUP_FN)
    // Since SiP flash memory initialization is done in R_BSP_WarmStart(), no additional code is needed here.
#else
#warning "Add SiP Flash IS25WX64 (r_ospi_b) stack on FSP configurator"
#endif
#endif
}
