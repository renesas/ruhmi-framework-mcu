/*
* Copyright (c) 2020 - 2025 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/
/**********************************************************************************************************************
 * File Name    : ethosu_dcache_maintenance.c
 * Description  : .
 **********************************************************************************************************************/
#include "hal_data.h"
#include "common_data.h"

// ############### USER SETTING ###############
#if defined(RENESAS_CORTEX_M33) && defined(R_CACHE)
#define CUSTOM_CFG_SCACHE_ENABLED (0) // 0: Disabled, 1: Enabled
                                      // This file shows an example of S-cache maintenance. But FSP BSP does not support CM33 L1 cache.
                                      // Not that users must implement cache enabling code themselves to use s-cache.
#endif
// ############ END OF USER SETTING ###########

// Overwrite cache clean API of ethos-u-driver
void ethosu_flush_dcache(uint32_t *p, size_t bytes)
{
#if defined(RENESAS_CORTEX_M85) && (BSP_CFG_DCACHE_ENABLED == 1)
    if(p != NULL)
    {
        SCB_CleanDCache_by_Addr(p, (int32_t) bytes);
    }
    else
    {
        SCB_CleanDCache();
    }
#elif defined(RENESAS_CORTEX_M33) && defined(R_CACHE) && (CUSTOM_CFG_SCACHE_ENABLED == 1)
    FSP_PARAMETER_NOT_USED(p);
    FSP_PARAMETER_NOT_USED(bytes);

    R_CACHE->SCAFCT_b.WB = 1;
    __DSB();
    FSP_HARDWARE_REGISTER_WAIT(R_CACHE->SCAFCT_b.WB, 0U);
    __DSB();
    __ISB();
#else
    FSP_PARAMETER_NOT_USED(p);
    FSP_PARAMETER_NOT_USED(bytes);
#endif
}

// Overwrite cache invalidate API of ethos-u-driver
void ethosu_invalidate_dcache(uint32_t *p, size_t bytes)
{
#if defined(RENESAS_CORTEX_M85) && (BSP_CFG_DCACHE_ENABLED == 1)
    if(p != NULL)
    {
        SCB_InvalidateDCache_by_Addr(p, (int32_t) bytes);
    }
    else
    {
        SCB_InvalidateDCache();
    }
#elif defined(RENESAS_CORTEX_M33) && defined(R_CACHE) && (CUSTOM_CFG_SCACHE_ENABLED == 1)
    FSP_PARAMETER_NOT_USED(p);
    FSP_PARAMETER_NOT_USED(bytes);

    R_CACHE->SCAFCT_b.FS = 1;
    __DSB();
    FSP_HARDWARE_REGISTER_WAIT(R_CACHE->SCAFCT_b.FS, 0U);
    __DSB();
    __ISB();
#else
    FSP_PARAMETER_NOT_USED(p);
    FSP_PARAMETER_NOT_USED(bytes);
#endif
}
