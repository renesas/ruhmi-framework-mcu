ra/arm/CMSIS-DSP/Source/MatrixFunctions/arm_mat_add_q15.o: \
  ../ra/arm/CMSIS-DSP/Source/MatrixFunctions/arm_mat_add_q15.c \
  /home/eldorado/e2_studio/workspace_6.4/ruhmi_perf_eval_ek_ra8p1/ra/arm/CMSIS-DSP/Include/dsp/matrix_functions.h \
  /home/eldorado/e2_studio/workspace_6.4/ruhmi_perf_eval_ek_ra8p1/ra/arm/CMSIS-DSP/Include/arm_math_types.h \
  /home/eldorado/e2_studio/workspace_6.4/ruhmi_perf_eval_ek_ra8p1/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_compiler.h \
  /home/eldorado/e2_studio/workspace_6.4/ruhmi_perf_eval_ek_ra8p1/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_clang.h \
  /home/eldorado/e2_studio/workspace_6.4/ruhmi_perf_eval_ek_ra8p1/ra/arm/CMSIS-DSP/Include/arm_math_memory.h \
  /home/eldorado/e2_studio/workspace_6.4/ruhmi_perf_eval_ek_ra8p1/ra/arm/CMSIS-DSP/Include/dsp/none.h \
  /home/eldorado/e2_studio/workspace_6.4/ruhmi_perf_eval_ek_ra8p1/ra/arm/CMSIS-DSP/Include/dsp/utils.h
/home/eldorado/e2_studio/workspace_6.4/ruhmi_perf_eval_ek_ra8p1/ra/arm/CMSIS-DSP/Include/dsp/matrix_functions.h:
/home/eldorado/e2_studio/workspace_6.4/ruhmi_perf_eval_ek_ra8p1/ra/arm/CMSIS-DSP/Include/arm_math_types.h:
/home/eldorado/e2_studio/workspace_6.4/ruhmi_perf_eval_ek_ra8p1/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_compiler.h:
/home/eldorado/e2_studio/workspace_6.4/ruhmi_perf_eval_ek_ra8p1/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_clang.h:
/home/eldorado/e2_studio/workspace_6.4/ruhmi_perf_eval_ek_ra8p1/ra/arm/CMSIS-DSP/Include/arm_math_memory.h:
/home/eldorado/e2_studio/workspace_6.4/ruhmi_perf_eval_ek_ra8p1/ra/arm/CMSIS-DSP/Include/dsp/none.h:
/home/eldorado/e2_studio/workspace_6.4/ruhmi_perf_eval_ek_ra8p1/ra/arm/CMSIS-DSP/Include/dsp/utils.h:
