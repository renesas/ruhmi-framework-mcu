################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_abs_f16.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_abs_f32.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_abs_f64.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_abs_q15.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_abs_q31.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_abs_q7.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_add_f16.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_add_f32.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_add_f64.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_add_q15.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_add_q31.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_add_q7.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_and_u16.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_and_u32.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_and_u8.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_clip_f16.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_clip_f32.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_clip_q15.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_clip_q31.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_clip_q7.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_dot_prod_f16.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_dot_prod_f32.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_dot_prod_f64.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_dot_prod_q15.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_dot_prod_q31.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_dot_prod_q7.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_mult_f16.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_mult_f32.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_mult_f64.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_mult_q15.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_mult_q31.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_mult_q7.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_negate_f16.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_negate_f32.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_negate_f64.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_negate_q15.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_negate_q31.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_negate_q7.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_not_u16.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_not_u32.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_not_u8.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_offset_f16.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_offset_f32.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_offset_f64.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_offset_q15.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_offset_q31.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_offset_q7.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_or_u16.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_or_u32.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_or_u8.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_scale_f16.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_scale_f32.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_scale_f64.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_scale_q15.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_scale_q31.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_scale_q7.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_shift_q15.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_shift_q31.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_shift_q7.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_sub_f16.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_sub_f32.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_sub_f64.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_sub_q15.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_sub_q31.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_sub_q7.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_xor_u16.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_xor_u32.c \
../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_xor_u8.c 

C_DEPS += \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_abs_f16.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_abs_f32.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_abs_f64.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_abs_q15.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_abs_q31.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_abs_q7.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_add_f16.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_add_f32.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_add_f64.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_add_q15.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_add_q31.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_add_q7.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_and_u16.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_and_u32.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_and_u8.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_clip_f16.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_clip_f32.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_clip_q15.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_clip_q31.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_clip_q7.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_dot_prod_f16.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_dot_prod_f32.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_dot_prod_f64.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_dot_prod_q15.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_dot_prod_q31.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_dot_prod_q7.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_mult_f16.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_mult_f32.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_mult_f64.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_mult_q15.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_mult_q31.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_mult_q7.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_negate_f16.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_negate_f32.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_negate_f64.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_negate_q15.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_negate_q31.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_negate_q7.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_not_u16.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_not_u32.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_not_u8.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_offset_f16.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_offset_f32.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_offset_f64.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_offset_q15.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_offset_q31.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_offset_q7.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_or_u16.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_or_u32.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_or_u8.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_scale_f16.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_scale_f32.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_scale_f64.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_scale_q15.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_scale_q31.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_scale_q7.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_shift_q15.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_shift_q31.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_shift_q7.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_sub_f16.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_sub_f32.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_sub_f64.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_sub_q15.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_sub_q31.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_sub_q7.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_xor_u16.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_xor_u32.d \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_xor_u8.d 

CREF += \
ruhmi_perf_eval_ek_ra8p1.cref 

OBJS += \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_abs_f16.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_abs_f32.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_abs_f64.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_abs_q15.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_abs_q31.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_abs_q7.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_add_f16.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_add_f32.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_add_f64.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_add_q15.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_add_q31.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_add_q7.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_and_u16.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_and_u32.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_and_u8.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_clip_f16.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_clip_f32.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_clip_q15.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_clip_q31.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_clip_q7.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_dot_prod_f16.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_dot_prod_f32.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_dot_prod_f64.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_dot_prod_q15.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_dot_prod_q31.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_dot_prod_q7.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_mult_f16.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_mult_f32.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_mult_f64.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_mult_q15.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_mult_q31.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_mult_q7.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_negate_f16.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_negate_f32.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_negate_f64.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_negate_q15.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_negate_q31.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_negate_q7.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_not_u16.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_not_u32.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_not_u8.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_offset_f16.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_offset_f32.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_offset_f64.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_offset_q15.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_offset_q31.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_offset_q7.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_or_u16.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_or_u32.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_or_u8.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_scale_f16.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_scale_f32.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_scale_f64.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_scale_q15.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_scale_q31.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_scale_q7.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_shift_q15.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_shift_q31.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_shift_q7.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_sub_f16.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_sub_f32.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_sub_f64.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_sub_q15.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_sub_q31.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_sub_q7.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_xor_u16.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_xor_u32.o \
./ra/arm/CMSIS-DSP/Source/BasicMathFunctions/arm_xor_u8.o 

MAP += \
ruhmi_perf_eval_ek_ra8p1.map 


# Each subdirectory must supply rules for building sources it contributes
ra/arm/CMSIS-DSP/Source/BasicMathFunctions/%.o: ../ra/arm/CMSIS-DSP/Source/BasicMathFunctions/%.c
	@echo 'Building file: $<'
	$(file > $@.in,-mcpu=cortex-m85 -mthumb -mlittle-endian -mfloat-abi=hard -Os -ffunction-sections -fdata-sections -fno-strict-aliasing -fmessage-length=0 -funsigned-char -Wunused -Wuninitialized -Wall -Wextra -Wmissing-declarations -Wconversion -Wpointer-arith -Wshadow -Waggregate-return -Wno-parentheses-equality -Wfloat-equal -g3 -std=c99 -flax-vector-conversions -fshort-enums -fno-unroll-loops -w -I"/home/eldorado/e2_studio/workspace_6.4/ruhmi_perf_eval_ek_ra8p1/ra_gen" -I"." -I"/home/eldorado/e2_studio/workspace_6.4/ruhmi_perf_eval_ek_ra8p1/ra_cfg/fsp_cfg/bsp" -I"/home/eldorado/e2_studio/workspace_6.4/ruhmi_perf_eval_ek_ra8p1/ra_cfg/fsp_cfg" -I"/home/eldorado/e2_studio/workspace_6.4/ruhmi_perf_eval_ek_ra8p1/src" -I"/home/eldorado/e2_studio/workspace_6.4/ruhmi_perf_eval_ek_ra8p1/ra/fsp/inc" -I"/home/eldorado/e2_studio/workspace_6.4/ruhmi_perf_eval_ek_ra8p1/ra/fsp/inc/api" -I"/home/eldorado/e2_studio/workspace_6.4/ruhmi_perf_eval_ek_ra8p1/ra/fsp/inc/instances" -I"/home/eldorado/e2_studio/workspace_6.4/ruhmi_perf_eval_ek_ra8p1/ra/arm/CMSIS_6/CMSIS/Core/Include" -I"/home/eldorado/e2_studio/workspace_6.4/ruhmi_perf_eval_ek_ra8p1/ra/fsp/src/rm_ethosu" -I"/home/eldorado/e2_studio/workspace_6.4/ruhmi_perf_eval_ek_ra8p1/ra/npu/ethos-u-core-driver/include" -I"/home/eldorado/e2_studio/workspace_6.4/ruhmi_perf_eval_ek_ra8p1/ra/arm/CMSIS-DSP/PrivateInclude" -I"/home/eldorado/e2_studio/workspace_6.4/ruhmi_perf_eval_ek_ra8p1/ra/arm/CMSIS-DSP/Include" -I"/home/eldorado/e2_studio/workspace_6.4/ruhmi_perf_eval_ek_ra8p1/ra/arm/CMSIS-NN/Include" -I"/home/eldorado/e2_studio/workspace_6.4/ruhmi_perf_eval_ek_ra8p1/ra/arm/CMSIS-NN" -D_RENESAS_RA_ -D_RA_CORE=CPU0 -D_RA_ORDINAL=1 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -x c "$<" -c -o "$@")
	@clang --target=arm-none-eabi @"$@.in"

