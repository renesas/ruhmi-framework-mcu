################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_boolean_distance.c \
../ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_braycurtis_distance_f16.c \
../ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_braycurtis_distance_f32.c \
../ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_canberra_distance_f16.c \
../ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_canberra_distance_f32.c \
../ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_chebyshev_distance_f16.c \
../ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_chebyshev_distance_f32.c \
../ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_chebyshev_distance_f64.c \
../ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_cityblock_distance_f16.c \
../ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_cityblock_distance_f32.c \
../ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_cityblock_distance_f64.c \
../ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_correlation_distance_f16.c \
../ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_correlation_distance_f32.c \
../ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_cosine_distance_f16.c \
../ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_cosine_distance_f32.c \
../ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_cosine_distance_f64.c \
../ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_dice_distance.c \
../ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_dtw_distance_f32.c \
../ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_dtw_init_window_q7.c \
../ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_dtw_path_f32.c \
../ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_euclidean_distance_f16.c \
../ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_euclidean_distance_f32.c \
../ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_euclidean_distance_f64.c \
../ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_hamming_distance.c \
../ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_jaccard_distance.c \
../ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_jensenshannon_distance_f16.c \
../ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_jensenshannon_distance_f32.c \
../ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_kulsinski_distance.c \
../ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_minkowski_distance_f16.c \
../ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_minkowski_distance_f32.c \
../ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_rogerstanimoto_distance.c \
../ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_russellrao_distance.c \
../ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_sokalmichener_distance.c \
../ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_sokalsneath_distance.c \
../ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_yule_distance.c 

C_DEPS += \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_boolean_distance.d \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_braycurtis_distance_f16.d \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_braycurtis_distance_f32.d \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_canberra_distance_f16.d \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_canberra_distance_f32.d \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_chebyshev_distance_f16.d \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_chebyshev_distance_f32.d \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_chebyshev_distance_f64.d \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_cityblock_distance_f16.d \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_cityblock_distance_f32.d \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_cityblock_distance_f64.d \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_correlation_distance_f16.d \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_correlation_distance_f32.d \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_cosine_distance_f16.d \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_cosine_distance_f32.d \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_cosine_distance_f64.d \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_dice_distance.d \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_dtw_distance_f32.d \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_dtw_init_window_q7.d \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_dtw_path_f32.d \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_euclidean_distance_f16.d \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_euclidean_distance_f32.d \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_euclidean_distance_f64.d \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_hamming_distance.d \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_jaccard_distance.d \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_jensenshannon_distance_f16.d \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_jensenshannon_distance_f32.d \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_kulsinski_distance.d \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_minkowski_distance_f16.d \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_minkowski_distance_f32.d \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_rogerstanimoto_distance.d \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_russellrao_distance.d \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_sokalmichener_distance.d \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_sokalsneath_distance.d \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_yule_distance.d 

CREF += \
ruhmi_perf_exal_ek_ra8p1_base_project_fsp660.cref 

OBJS += \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_boolean_distance.o \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_braycurtis_distance_f16.o \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_braycurtis_distance_f32.o \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_canberra_distance_f16.o \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_canberra_distance_f32.o \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_chebyshev_distance_f16.o \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_chebyshev_distance_f32.o \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_chebyshev_distance_f64.o \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_cityblock_distance_f16.o \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_cityblock_distance_f32.o \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_cityblock_distance_f64.o \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_correlation_distance_f16.o \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_correlation_distance_f32.o \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_cosine_distance_f16.o \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_cosine_distance_f32.o \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_cosine_distance_f64.o \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_dice_distance.o \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_dtw_distance_f32.o \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_dtw_init_window_q7.o \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_dtw_path_f32.o \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_euclidean_distance_f16.o \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_euclidean_distance_f32.o \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_euclidean_distance_f64.o \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_hamming_distance.o \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_jaccard_distance.o \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_jensenshannon_distance_f16.o \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_jensenshannon_distance_f32.o \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_kulsinski_distance.o \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_minkowski_distance_f16.o \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_minkowski_distance_f32.o \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_rogerstanimoto_distance.o \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_russellrao_distance.o \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_sokalmichener_distance.o \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_sokalsneath_distance.o \
./ra/arm/CMSIS-DSP/Source/DistanceFunctions/arm_yule_distance.o 

MAP += \
ruhmi_perf_exal_ek_ra8p1_base_project_fsp660.map 


# Each subdirectory must supply rules for building sources it contributes
ra/arm/CMSIS-DSP/Source/DistanceFunctions/%.o: ../ra/arm/CMSIS-DSP/Source/DistanceFunctions/%.c
	@echo 'Building file: $<'
	$(file > $@.in,-mcpu=cortex-m85 -mthumb -mlittle-endian -mfloat-abi=hard -Os -ffunction-sections -fdata-sections -fno-strict-aliasing -fmessage-length=0 -funsigned-char -Wunused -Wuninitialized -Wall -Wextra -Wmissing-declarations -Wconversion -Wpointer-arith -Wshadow -Waggregate-return -Wno-parentheses-equality -Wfloat-equal -g3 -std=c99 -flax-vector-conversions -fshort-enums -fno-unroll-loops -w -I"/home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra_gen" -I"." -I"/home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra_cfg/fsp_cfg/bsp" -I"/home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra_cfg/fsp_cfg" -I"/home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/src" -I"/home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/fsp/inc" -I"/home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/fsp/inc/api" -I"/home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/fsp/inc/instances" -I"/home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/arm/CMSIS_6/CMSIS/Core/Include" -I"/home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/fsp/src/rm_ethosu" -I"/home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/npu/ethos-u-core-driver/include" -I"/home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/arm/CMSIS-DSP/PrivateInclude" -I"/home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/arm/CMSIS-DSP/Include" -I"/home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/arm/CMSIS-NN/Include" -I"/home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/arm/CMSIS-NN" -D_RENESAS_RA_ -D_RA_CORE=CPU0 -D_RA_ORDINAL=1 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -x c "$<" -c -o "$@")
	@clang --target=arm-none-eabi @"$@.in"

