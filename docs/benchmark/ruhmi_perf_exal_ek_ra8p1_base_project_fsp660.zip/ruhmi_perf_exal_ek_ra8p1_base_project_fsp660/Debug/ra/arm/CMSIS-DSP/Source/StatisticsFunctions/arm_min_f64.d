ra/arm/CMSIS-DSP/Source/StatisticsFunctions/arm_min_f64.o: \
  ../ra/arm/CMSIS-DSP/Source/StatisticsFunctions/arm_min_f64.c \
  /home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/arm/CMSIS-DSP/Include/dsp/statistics_functions.h \
  /home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/arm/CMSIS-DSP/Include/arm_math_types.h \
  /home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_compiler.h \
  /home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_clang.h \
  /home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/arm/CMSIS-DSP/Include/arm_math_memory.h \
  /home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/arm/CMSIS-DSP/Include/dsp/none.h \
  /home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/arm/CMSIS-DSP/Include/dsp/utils.h \
  /home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/arm/CMSIS-DSP/Include/dsp/basic_math_functions.h \
  /home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/arm/CMSIS-DSP/Include/dsp/fast_math_functions.h
/home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/arm/CMSIS-DSP/Include/dsp/statistics_functions.h:
/home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/arm/CMSIS-DSP/Include/arm_math_types.h:
/home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_compiler.h:
/home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_clang.h:
/home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/arm/CMSIS-DSP/Include/arm_math_memory.h:
/home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/arm/CMSIS-DSP/Include/dsp/none.h:
/home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/arm/CMSIS-DSP/Include/dsp/utils.h:
/home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/arm/CMSIS-DSP/Include/dsp/basic_math_functions.h:
/home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/arm/CMSIS-DSP/Include/dsp/fast_math_functions.h:
