################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../ra/arm/CMSIS-DSP/Source/BayesFunctions/arm_gaussian_naive_bayes_predict_f16.c \
../ra/arm/CMSIS-DSP/Source/BayesFunctions/arm_gaussian_naive_bayes_predict_f32.c 

C_DEPS += \
./ra/arm/CMSIS-DSP/Source/BayesFunctions/arm_gaussian_naive_bayes_predict_f16.d \
./ra/arm/CMSIS-DSP/Source/BayesFunctions/arm_gaussian_naive_bayes_predict_f32.d 

CREF += \
ruhmi_perf_exal_ek_ra8p1_base_project_fsp660.cref 

OBJS += \
./ra/arm/CMSIS-DSP/Source/BayesFunctions/arm_gaussian_naive_bayes_predict_f16.o \
./ra/arm/CMSIS-DSP/Source/BayesFunctions/arm_gaussian_naive_bayes_predict_f32.o 

MAP += \
ruhmi_perf_exal_ek_ra8p1_base_project_fsp660.map 


# Each subdirectory must supply rules for building sources it contributes
ra/arm/CMSIS-DSP/Source/BayesFunctions/%.o: ../ra/arm/CMSIS-DSP/Source/BayesFunctions/%.c
	@echo 'Building file: $<'
	$(file > $@.in,-mcpu=cortex-m85 -mthumb -mlittle-endian -mfloat-abi=hard -Os -ffunction-sections -fdata-sections -fno-strict-aliasing -fmessage-length=0 -funsigned-char -Wunused -Wuninitialized -Wall -Wextra -Wmissing-declarations -Wconversion -Wpointer-arith -Wshadow -Waggregate-return -Wno-parentheses-equality -Wfloat-equal -g3 -std=c99 -flax-vector-conversions -fshort-enums -fno-unroll-loops -w -I"/home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra_gen" -I"." -I"/home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra_cfg/fsp_cfg/bsp" -I"/home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra_cfg/fsp_cfg" -I"/home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/src" -I"/home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/fsp/inc" -I"/home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/fsp/inc/api" -I"/home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/fsp/inc/instances" -I"/home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/arm/CMSIS_6/CMSIS/Core/Include" -I"/home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/fsp/src/rm_ethosu" -I"/home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/npu/ethos-u-core-driver/include" -I"/home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/arm/CMSIS-DSP/PrivateInclude" -I"/home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/arm/CMSIS-DSP/Include" -I"/home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/arm/CMSIS-NN/Include" -I"/home/eldorado/e2_studio/workspace_6.6.0/ruhmi_perf_exal_ek_ra8p1_base_project_fsp660/ra/arm/CMSIS-NN" -D_RENESAS_RA_ -D_RA_CORE=CPU0 -D_RA_ORDINAL=1 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -x c "$<" -c -o "$@")
	@clang --target=arm-none-eabi @"$@.in"

