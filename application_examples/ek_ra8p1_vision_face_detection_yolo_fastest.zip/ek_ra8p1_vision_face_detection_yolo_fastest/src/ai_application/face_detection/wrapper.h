/*
 * SPDX-FileCopyrightText: Copyright 2022 Arm Limited and/or its affiliates <open-source-office@arm.com>
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#ifndef MODEL_WRAPPER_H
#define MODEL_WRAPPER_H

#include "model.h"
#include <stdint.h>

static inline uint8_t* mera_input_ptr() {
    return (uint8_t*) GetModelInputPtr_image_input();
}

static inline uint8_t* mera_output1_ptr() {
    return (uint8_t*) GetModelOutputPtr_Identity_70275();
}

static inline uint8_t* mera_output2_ptr() {
    return (uint8_t*) GetModelOutputPtr_Identity_1_70284();
}

static inline void mera_invoke() {
//    memcpy(mera_input_ptr(), model_image_input, model_image_input_SIZE);
    RunModel(false);
}

#endif // MODEL_WRAPPER_H
