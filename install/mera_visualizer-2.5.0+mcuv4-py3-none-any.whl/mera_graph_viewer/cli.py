#!/usr/bin/env python3
"""
Command line interface for MERA Viewer.
"""

import argparse
import sys
import json
import threading
import time
import webbrowser
from pathlib import Path


def main():
    """Main entry point for the mera_visualizer command."""
    parser = argparse.ArgumentParser(
        description="MERA Graph Visualization Tool - Neural Network Graph Viewer",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  mera_visualizer                              # Run on default port 5566
  mera_visualizer --port 8080                  # Run on port 8080
  mera_visualizer --host 0.0.0.0               # Run on all interfaces
  mera_visualizer --debug                      # Run in debug mode
  mera_visualizer --json path/to/graph.json    # Load JSON file and start server
        """,
    )

    parser.add_argument(
        "--port", "-p", type=int, default=5566, help="Port to run the server on (default: 5566)"
    )

    parser.add_argument(
        "--host",
        type=str,
        default="127.0.0.1",
        help="Host to run the server on (default: 127.0.0.1)",
    )

    parser.add_argument("--debug", action="store_true", help="Run in debug mode")

    parser.add_argument(
        "--json", "-j", type=str, dest="json_file", help="Path to JSON file to load and visualize"
    )

    parser.add_argument(
        "--no-browser",
        action="store_true",
        help="Do not automatically open browser when using --json",
    )

    parser.add_argument("--version", "-v", action="version", version="%(prog)s 2.5.0")

    parser.add_argument(
        "--access-info",
        type=str,
        dest="access_info_path",
        help="Path to write access info file with the result URL",
    )

    args = parser.parse_args()

    try:
        from mera_graph_viewer.factory import create_app

        config_name = "development" if args.debug else "default"
        app = create_app(config_name)

        result_id = None

        if args.json_file:
            json_path = Path(args.json_file)

            if not json_path.exists():
                print(f"Error: JSON file not found: {json_path}")
                sys.exit(1)

            if not json_path.is_file():
                print(f"Error: Path is not a file: {json_path}")
                sys.exit(1)

            print(f"Loading JSON file: {json_path}")

            try:
                with open(json_path, "r") as f:
                    file_content = f.read()

                input_json = json.loads(file_content)

                from mera_graph_viewer.json_graph_reader import parse_mera_json

                processed_graph_json_str = parse_mera_json(input_json)
                processed_graph_data = json.loads(processed_graph_json_str)

                processed_json = {
                    "received_from": f"cli: {json_path}",
                    "original_data": processed_graph_data,
                    "processing_status": "processed_successfully_with_parse_mera_json",
                    "notes": "JSON processed from CLI using parse_mera_json",
                }

                with app.app_context():
                    storage = app.extensions["storage"]
                    result_id = storage.save_graph(processed_json)

                print(f"JSON file processed successfully with ID: {result_id}")
            except Exception as e:
                print(f"Error processing JSON file: {e}")
                import traceback

                traceback.print_exc()
                sys.exit(1)

        print(f"Starting MERA Viewer on http://{args.host}:{args.port}")

        if result_id:
            result_url = f"http://{args.host}:{args.port}/result/{result_id}"
            print(f"{'-'*80}\nView your graph at: {result_url}\n{'-'*80}")

            # Write URL to access-info file if path is provided
            if args.access_info_path:
                access_info_path = Path(args.access_info_path)
                print(f"{'-'*80}")
                try:
                    access_info_path.parent.mkdir(parents=True, exist_ok=True)
                    with open(access_info_path, "w") as f:
                        f.write(result_url)
                    print(f"Access info saved to: {access_info_path.absolute()}")
                except PermissionError:
                    print(
                        f"Error: Permission denied. Cannot write to: {access_info_path.absolute()}"
                    )
                except OSError as e:
                    print(f"Error: Failed to write access info file: {e}")
                print(f"{'-'*80}")

            if not args.no_browser:

                def open_browser():
                    time.sleep(1.5)  # Wait for server to start
                    webbrowser.open(result_url)

                threading.Thread(target=open_browser, daemon=True).start()

        print("Press Ctrl+C to stop the server")
        app.run(host=args.host, port=args.port, debug=args.debug)
    except KeyboardInterrupt:
        print("\nShutting down MERA Viewer...")
        sys.exit(0)
    except Exception as e:
        print(f"Error starting MERA Viewer: {e}")
        import traceback

        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
