"""``mera_progress_viewer`` -- attach a live TUI to a running MERA compile.

Typical use: a ``mera.deploy`` with live progress prints a pid; run

    mera_progress_viewer --pid <pid>

in another terminal to watch the compile's progress live. It opens on the overall
overview; press ``d`` to toggle the per-node work breakdown and scroll it with the
arrow keys. ``--pid`` resolves the relay's TCP endpoints from the registry written
by the deploy; advanced users can point at endpoints directly with
``--events``/``--snapshot``.
"""

import argparse
import os
import sys
import threading

from . import endpoints, tui
from .state_model import DEFAULT_TOPIC, ZmqSubscriber

_CONNECT_TIMEOUT_S = 3.0


class _View:
    """Shared interactive view state. The render thread reads it and clamps the
    scroll ``offset`` against the true row count; the key reader thread toggles
    ``details`` and moves the viewport. ``max``/``page`` are filled by the renderer."""

    __slots__ = ("details", "offset", "max", "page", "quit")

    def __init__(self):
        self.details = False  # start on the overview; 'd' reveals the breakdown
        self.offset = 0
        self.max = 0
        self.page = 10
        self.quit = False


def _apply_key(ch, s):
    if ch in ("d", "\t"):  # toggle the detailed breakdown
        s.details = not s.details
        s.offset = 0
    elif ch in ("k", "\x1b[A"):  # up
        s.offset -= 1
    elif ch in ("j", "\x1b[B"):  # down
        s.offset += 1
    elif ch in ("\x1b[5~",):  # PgUp
        s.offset -= s.page
    elif ch in ("\x1b[6~", " "):  # PgDn / space
        s.offset += s.page
    elif ch in ("g", "\x1b[H"):  # top
        s.offset = 0
    elif ch in ("G", "\x1b[F"):  # bottom
        s.offset = s.max
    elif ch in ("q", "\x03"):  # quit
        s.quit = True
    s.offset = max(0, min(s.offset, s.max))


# Windows scan code (after a \x00/\xe0 lead byte) -> the escape _apply_key expects.
_WIN_KEYS = {
    "H": "\x1b[A",  # up
    "P": "\x1b[B",  # down
    "I": "\x1b[5~",  # PgUp
    "Q": "\x1b[6~",  # PgDn
    "G": "\x1b[H",  # Home
    "O": "\x1b[F",  # End
}


def _read_keys_posix(view, stop):
    """cbreak single-key reader (POSIX). Ctrl-C still raises SIGINT (ISIG kept)."""
    import select
    import termios
    import tty

    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    try:
        tty.setcbreak(fd)
        while not stop.is_set():
            r, _, _ = select.select([fd], [], [], 0.2)
            if r:
                ch = os.read(fd, 6).decode(errors="ignore")
                if ch:
                    _apply_key(ch, view)
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)


def _read_keys_windows(view, stop):
    """Single-key reader (Windows) via ``msvcrt``. Arrow/nav keys arrive as a lead
    byte (\\x00/\\xe0) then a scan code, which we map to the same escapes as POSIX."""
    assert sys.platform == "win32"
    import msvcrt

    while not stop.is_set():
        if not msvcrt.kbhit():
            stop.wait(0.05)
            continue
        ch = msvcrt.getwch()
        if ch in ("\x00", "\xe0"):
            ch = _WIN_KEYS.get(msvcrt.getwch(), "")
        if ch:
            _apply_key(ch, view)


def _key_reader():
    """The single-key reader for this platform, or None if unsupported."""
    if os.name == "posix":
        return _read_keys_posix
    if os.name == "nt":
        return _read_keys_windows
    return None


def _advance(subs):
    """Advance every subscriber once: (re)connect those without a snapshot,
    poll the live ones."""
    for sub in subs:
        if sub.epoch is None or sub.needs_resnapshot:
            sub.connect(timeout=0.3)  # retry until the producer/relay appears
        else:
            sub.poll(block_ms=100)


def _run(subs, info, opts):
    from rich.console import Console
    from rich.live import Live

    console = Console()
    view = None
    stop = threading.Event()
    reader = None
    reader_fn = _key_reader()
    if reader_fn is not None and sys.stdin.isatty():
        view = _View()
        reader = threading.Thread(target=reader_fn, args=(view, stop), daemon=True)
        reader.start()

    # Rich repaints on its own timer; _advance() blocks on the ZMQ poll, so the
    # loop needs no sleep of its own.
    tick = 0
    try:
        with Live(console=console, screen=True, auto_refresh=True) as live:
            while True:
                _advance(subs)
                if view is not None and view.quit:
                    break
                size = console.size
                live.update(
                    tui.render(
                        subs,
                        tick,
                        info,
                        opts,
                        height=size.height,
                        width=size.width,
                        view=view,
                    )
                )
                tick += 1
    finally:
        stop.set()
        if reader is not None:
            reader.join(timeout=0.5)


def _parse_args(argv):
    p = argparse.ArgumentParser(
        prog="mera_progress_viewer",
        description="Live TUI for a running MERA compile.",
    )
    p.add_argument(
        "--pid",
        type=int,
        default=None,
        help="pid printed by the deploy; resolves relay endpoints from the registry",
    )
    p.add_argument(
        "--events",
        default=None,
        help="override: PUB endpoint to subscribe to (bypasses --pid)",
    )
    p.add_argument(
        "--snapshot",
        default=None,
        help="override: snapshot ROUTER endpoint (bypasses --pid)",
    )
    p.add_argument("--topic", default=None, help="SUB topic filter")
    p.add_argument(
        "--max-depth",
        type=int,
        default=1,
        help="how deep to expand the breakdown (default 1: subgraphs only; -1 for the full tree).",
    )
    p.add_argument(
        "--show-ids", action="store_true", help="append each node's unique id"
    )
    return p.parse_args(argv)


def main(argv=None):
    args = _parse_args(argv)
    info = {"pid": args.pid, "model": ""}

    if args.events and args.snapshot:
        events, snapshot = args.events, args.snapshot
        topic = args.topic or DEFAULT_TOPIC
    elif args.pid is not None:
        try:
            ep = endpoints.resolve_endpoints(args.pid)
        except FileNotFoundError as e:
            print(str(e), file=sys.stderr)
            return 2
        events, snapshot = ep["publish"], ep["snapshot"]
        topic = args.topic or ep.get("topic", DEFAULT_TOPIC)
        info["model"] = ep.get("model", "")
    else:
        print(
            "error: pass --pid <pid> (from the deploy) or both --events and --snapshot.",
            file=sys.stderr,
        )
        return 2

    try:
        sub = ZmqSubscriber(events, snapshot, topic)
    except ImportError:
        print(
            "error: pyzmq is required for the viewer (pip install pyzmq).",
            file=sys.stderr,
        )
        return 2

    # A registry entry can outlive its deploy (a hard kill skips cleanup), so
    # confirm a relay actually answers before entering the live loop -- a
    # timed-out handshake, not a pid probe, is what tells us it's gone.
    if not sub.connect(timeout=_CONNECT_TIMEOUT_S):
        where = f"pid {args.pid}" if args.pid is not None else events
        print(
            f"No progress relay is responding for {where}; the deploy may have "
            f"already exited.",
            file=sys.stderr,
        )
        sub.close()
        if args.pid is not None:
            endpoints.remove_endpoints(args.pid)
        return 2

    opts = tui.RenderOpts(show_ids=args.show_ids, max_depth=args.max_depth)
    try:
        _run([sub], info, opts)
    except KeyboardInterrupt:
        return 0
    finally:
        sub.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
