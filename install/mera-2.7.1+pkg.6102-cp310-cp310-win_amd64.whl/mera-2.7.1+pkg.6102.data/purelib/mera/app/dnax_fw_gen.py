# Copyright 2025 EdgeCortix Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import argparse
from ..utils import cmd, find_tool


def main():
    arg_p = argparse.ArgumentParser(description="dnax firmware generation tool")
    args, unknownargs = arg_p.parse_known_args()
    if not unknownargs:
        cmd(f"{find_tool('dnax_fw_gen')} --help")
    else:
        cmd(f"{find_tool('dnax_fw_gen')} {' '.join(unknownargs)}")
