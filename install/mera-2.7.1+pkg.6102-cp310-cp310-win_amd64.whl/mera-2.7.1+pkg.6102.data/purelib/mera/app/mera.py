#! /usr/bin/env python3

import argparse
import mera
import sys


def main():
    arg_p = argparse.ArgumentParser(
        description="Utility to query information about MERA platform"
    )
    arg_p.add_argument(
        "-v",
        "--version",
        action="store_true",
        help="Display the current version about the installed MERA",
    )

    args = arg_p.parse_args()
    if args.version:
        print(mera.get_versions())
        return 0
    arg_p.print_help()
    return 0


if __name__ == "__main__":
    sys.exit(main())
