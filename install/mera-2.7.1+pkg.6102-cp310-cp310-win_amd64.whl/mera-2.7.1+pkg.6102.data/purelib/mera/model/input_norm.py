# Copyright 2025 EdgeCortix Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


class InputNormCfg:
    """Manages input normalization settings for model inputs.

    This class allows users to define normalization rules for one or more
    model inputs. Each call to :meth:`normalize` registers a configuration
    that scales and shifts the corresponding input prior to model inference.
    """

    def __init__(self):
        self.__data = {}

    def _to_dict(self):
        return self.__data

    def normalize(
        self,
        input_name: str,
        std: float | list[float],
        mean: float | list[float],
    ):
        """Configures the compiler to modify the model input specified by ``input_name`` so that it accepts
        unnormalized NHWC integer data and applies internal normalization using:

            X' = (X - mean) / std

        The integer dtype of the rewritten input depends on the source model format:

        * **ONNX** models: ``uint8`` (range ``[0, 255]``).
        * **TFLite** models: ``int8`` (range ``[-128, 127]``) — TFLite's native quantization dtype.
          Callers feeding a TFLite-derived deployment must pass ``int8`` data; the natural shift from
          ``uint8`` pixel data is ``int8 = uint8 - 128``.

        This operation updates the model's input/output specification, so users should ensure that
        this change is compatible with their deployment requirements.

        :param input_name: Name of the model input to which normalization should be applied.
        :param std: A single float or a list of per-channel floats representing the scaling factor(s).
        :param mean: A single float or a list of per-channel floats representing the offset(s) applied after scaling.
        :return: self
        """
        if not isinstance(std, list):
            std = [std]
        if not isinstance(mean, list):
            mean = [mean]
        if len(std) == 1 and len(mean) > 1:
            std = std * len(mean)
        if len(mean) == 1 and len(std) > 1:
            mean = mean * len(std)
        self.__data[input_name] = []
        for m, s in zip(mean, std):
            self.__data[input_name].append((float(m), float(s)))
        return self
