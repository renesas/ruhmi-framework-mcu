# Copyright 2022 EdgeCortix Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Mera Deployer classes"""

import contextlib
import os
import platform
import time
from pathlib import Path

from .deploy_project import (
    ArtifactFileType,
    CompilationFlow,
    Target,
    _create_mera_project,
    logger,
)
from .mera_deployment import (
    MeraDeployment,
    MeraInterpreterDeployment,
)
from .mera_model import (
    Mera2ModelFused,
    Mera2ModelQuantized,
    MeraModel,
)
from .mera_platform import AccelKind, Platform
from .utils import cmd, find_tool
from .version import __version__


def _progress_enabled(build_config) -> bool:
    """True when the build sets a truthy ``progress_bars`` flag (read at the top
    level or nested under ``scheduler_config``). Only that flag makes the DNA
    scheduler emit per-iteration progress, so only then is a live viewer useful."""
    if not isinstance(build_config, dict):
        return False
    scopes = (build_config, build_config.get("scheduler_config") or {})
    return any(
        str(s.get("progress_bars", "")).strip().lower() in ("1", "true", "yes", "on")
        for s in scopes
    )


@contextlib.contextmanager
def _progress_relay(build_config, model_name):
    """When the build enables ``progress_bars``, run a progress relay (see
    mera_progress_viewer) for the duration of the block and print how to attach a
    viewer; otherwise do nothing. A relay that fails to start is logged and
    skipped -- progress plumbing must never break a compile."""
    with contextlib.ExitStack() as stack:
        if _progress_enabled(build_config):
            try:
                from mera_progress_viewer.relay import serving

                relay = stack.enter_context(serving(os.getpid(), model_name))
                color = os.isatty(1) or os.isatty(2)
                tag = (
                    "\033[1;32m[progress]\033[0m" if color else "[progress]"
                )  # bold standard green
                cmd_hint = (
                    f"\033[1;36mmera_progress_viewer --pid {relay.pid}\033[0m"
                    if color
                    else f"mera_progress_viewer --pid {relay.pid}"
                )  # bold standard cyan
                logger.info(
                    f"{tag} Live progress enabled. Watch this compile from another "
                    f"terminal with:\n    {cmd_hint}"
                )
            except Exception as e:
                logger.warning(f"progress viewer relay disabled: {e}")
        yield


_DEPRECATED_PLATFORMS = {
    "DNAF200L0001",
    "DNAF200L0002",
    "DNAF200L0003",
    "DNAF100L0001",
    "DNAF100L0002",
    "DNAF100L0003",
    "DNAF10032x2",
    "DNAF132S0001",
    "DNAF232S0001",
    "DNAF232S0002",
    "DNAF632L0001",
    "DNAF632L0002",
    "DNAF632L0003",
    "DNAF300L0001",
    "DNAA400L0001",
}


class _DeployerBase:
    """Base class for Mera deployer handler"""

    def __init__(self, output_dir: str, overwrite: bool = False):
        """Create a new deployment project with a given toolchain

        :param output_dir: Output directory relative to cwd where the project should be deployed
        :param overwrite: Whether the folder should be wiped before starting a new deployment. Defaults to false
        """
        self.prj = _create_mera_project(output_dir, overwrite, self._get_compile_flow())

    def __enter__(self):
        self.prj._lock()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.prj._unlock()

    def _validate_args(self, model, mera_platform, target, host_arch):
        if not isinstance(model, MeraModel):
            raise ValueError("Model is not of MeraModel type.")

        if isinstance(target, str):
            target = Target[target]
        elif not isinstance(target, Target):
            raise ValueError(
                f"target parameter {target} could not be interpreted as a valid Target"
            )
        target_str = target.str_val
        x86_only = target.x86_only

        if isinstance(mera_platform, Platform):
            arch_val = mera_platform.platform_name
        else:
            arch_val = mera_platform

        if arch_val in _DEPRECATED_PLATFORMS:
            raise ValueError(
                f"Platform '{arch_val}' is not supported as of MERA {__version__}. "
                "Use Platform.SAKURA_II instead."
            )

        __PRCS_MAP = {
            "x86_64": "x86",
            "i386": "x86",
            "AMD64": "x86",
            # TODO - Missing mapping for ARM
        }
        __SUPPORTED_ARCH = ["x86", "arm"]
        if not host_arch:
            _prcs = platform.machine()
            host_arch = __PRCS_MAP.get(_prcs, _prcs)

        if host_arch not in __SUPPORTED_ARCH:
            raise ValueError(
                f'Unsupported host architecture "{host_arch}". '
                f"Only [{' '.join(__SUPPORTED_ARCH)}] architectures are supported."
            )

        if host_arch != "x86" and x86_only:
            raise ValueError(
                f'Selected host_arch="{host_arch}", but target "{target_str}" only supports x86 architectures'
            )
        return target_str, arch_val, host_arch, target

    def _get_compile_flow(self):
        raise NotImplementedError()


class MERADeployer(_DeployerBase):
    """MERA standard deployer using the MERA compiler stack."""

    def _get_compile_flow(self):
        return CompilationFlow.MERA

    def _prepare_model_parse_cfg(
        self,
        model,
        arch_str="",
        ccfg_str="",
        host_arch="",
        target=None,
        mera_platform=None,
        ccodegen_enable_ospi=False,
        ccodegen_enable_ref_data=False,
        ccodegen_to_can=False,
        fe_mode=None,
        dna_extract_qtz_io_to_cpu=True,
        enable_gather_mera_block=False,
        backend_options={},
        **kwargs,
    ):
        # TODO - Missing fields
        __SCHEMA_VER = 2
        sym_dims = model.shape_mapping if hasattr(model, "shape_mapping") else {}
        try:
            model_info = {}
            mi = model.model_info if hasattr(model, "model_info") else {}
            for mi_name, mi_data in mi.items():
                model_info[mi_name] = str(mi_data)
        except Exception as ex:
            logger.warning(f"Could not prepare model info data: {ex}")
            model_info = {}
        if fe_mode is not None:
            __fe_mode = fe_mode
        elif target == Target.MERAInterpreter:
            __fe_mode = "CONVERTED_ONLY"
        else:
            __fe_mode = "FULL"
        try:
            __DEVICE_MAP = {
                AccelKind.DNA: ["CPU", "EC_SAKURA_II"],
                AccelKind.MCU: ["CPU", "EC_C_CODEGEN"],
            }
            if mera_platform is not None:
                __devices = __DEVICE_MAP.get(mera_platform.accelerator_kind, ["CPU"])
                if mera_platform in [Platform.ALTX, Platform.ALTX_SMALL]:
                    __devices = ["EC_DNAX"]
            else:
                __devices = ["CPU"]
        except Exception:
            __devices = ["CPU"]
        __dna_backend = {}
        __dnax_backend = {}
        if mera_platform in [Platform.ALTX, Platform.ALTX_SMALL]:
            # Fill in DNAX info
            __dnax_backend = {
                "enable_cpu_only": bool(
                    backend_options.get("dnax.enable_cpu_only", False)
                ),
                "enable_dma": bool(backend_options.get("dnax.enable_dma", True)),
                "arch_name": mera_platform.platform_name,
            }
        # Fill in DNA info
        __dna_backend = {
            "arch_cfg": arch_str,
            "ccfg": ccfg_str,
            "extract_qtz_io_to_cpu": bool(dna_extract_qtz_io_to_cpu),
        }
        return {
            "schema": __SCHEMA_VER,
            "metadata": {},  # TODO
            "checksums": {},  # TODO
            "devices": __devices,
            "model_path": str(model.model_path),
            "output_dir": str(self.prj.get_cwd()),
            "symbolic_dimensions": sym_dims,
            "model_info": model_info,
            "frontend_options": {
                "kv_cache_length": int(kwargs.get("kv_cache_length", 0)),
                "attention_dim_pad": int(kwargs.get("attention_dim_pad", 32)),
                "input_norm": model.input_norm_cfg._to_dict()
                if model.input_norm_cfg is not None
                else {},
            },
            "backend_options": {
                "cpu": {"host_arch": host_arch},
                "dna": __dna_backend,
                "ccodegen": {
                    "enable_ethos": mera_platform == Platform.ALT2,
                    "enable_ospi": bool(ccodegen_enable_ospi),
                    "enable_ref_data": bool(ccodegen_enable_ref_data),
                    "convert_canonical": bool(ccodegen_to_can),
                },
                "dnax": __dnax_backend,
            },
            "fe_mode": __fe_mode,
            "enable_gather_mera_block": bool(enable_gather_mera_block),
        }

    def __populate_ccfg(self, bc):
        # Adds values to the currently mandatory Ccfg parameters
        def __add(key, val):
            if key not in bc:
                bc[key] = val

        __add("max_tile_width", 64)
        __add("max_tile_height", 64)
        __add("max_acc_tile_height", 16)
        __add("max_acc_tile_width", 32)
        __add("use_small_acc_mem", "true")
        return bc

    def _apply_frontend(self, model, deploy_cfg_json):
        extension = (
            Path(model.model_path_orig).suffix if model.model_path_orig else None
        )
        if isinstance(model, Mera2ModelFused):
            cmd(f"{find_tool('mera_fused_cli')} {deploy_cfg_json}")
        elif isinstance(model, Mera2ModelQuantized):
            cmd(f"{find_tool('fe_meraqtz_cli')} {deploy_cfg_json}")
        elif extension == ".onnx":
            cmd(f"{find_tool('fe_onnx_cli')} {deploy_cfg_json}")
        elif extension == ".tflite":
            cmd(f"{find_tool('fe_tflite_cli')} {deploy_cfg_json}")
        elif extension == ".pte":
            cmd(f"{find_tool('fe_exir_cli')} {deploy_cfg_json}")
        else:
            raise ValueError(f"File extension not supported: {extension}")

    def _fuse_models(self, mera_models, share_input):
        if share_input:
            raise ValueError("Input sharing for model fusion not supported yet")
        fuse_locs = []
        fused_out_path = self.prj.get_cwd() / "model" / "model.mera_fused"
        (self.prj.get_cwd() / "model").mkdir(exist_ok=True)
        for idx, m in enumerate(mera_models):
            self.prj.pushd(f"model_{idx}", abs=True)
            logger.info(f"** Loading fuse model #{idx}: {m.model_path}")
            deploy_cfg_json = self._prepare_model_parse_cfg(m, fe_mode="FRAMEWORK_ONLY")
            deploy_cfg_json = self.prj.save_artifact(
                "deploy_cfg.json", ArtifactFileType.JSON, "mera2_dcfg", deploy_cfg_json
            )
            self._apply_frontend(m, deploy_cfg_json)
            fuse_locs.append(str((self.prj.get_cwd() / "model.mir").resolve()))
            self.prj.popd()
        cmd(
            f"{find_tool('mera_model_fuser')} {str(fused_out_path.resolve())} {' '.join(fuse_locs)}"
        )
        return fused_out_path

    def deploy(
        self,
        model: MeraModel,
        mera_platform: Platform = Platform.SAKURA_2C,
        build_config: dict = {},
        target: Target = Target.Simulator,
        host_arch: str | None = None,
        mcu_config: dict = {},
        vela_config: dict = {},
        kv_cache_length: int = 0,
        **kwargs,
    ) -> MeraDeployment | MeraInterpreterDeployment | None:
        """Launches the compilation of a MERA project for a MERA model using the MERA stack.

        :param model: Model object loaded from mera.ModelLoader
        :param mera_platform: MERA platform architecture enum value
        :param build_config: MERA build configuration dictionary.
        :param target: MERA build target
        :param host_arch: Host arch to deploy for. If unset, it will pick the current host platform,
            provide a value to override the setting.
        :param mcu_config: Dictionary with user overrides for MCU CCodegen tool. The following fields are allowed:
            `suffix`, `weight_location`, `use_x86`
        :param vela_config: Dictionary with user overrides for MCU Vela tool. The following fields are allowed:
            `enable_ospi`, `config`, `sys_config`, `accel_config`, `optimise`, `memory_mode`, `verbose_all`.
        :param kv_cache_length: When deploying Transformer models, specifies the KV Cache's max size that will be built. If set to 0 (default), KV Cache won't be used.
        :return: The object representing the result of a MERA deployment
        """
        target_str, arch_val, host_arch, target = self._validate_args(
            model, mera_platform, target, host_arch
        )
        if isinstance(model, Mera2ModelFused):
            if mera_platform != Platform.SAKURA_2C:
                raise ValueError(
                    f"Cannot use this model fusion for MERA platform {mera_platform}"
                )
        curr_cwd = os.getcwd()
        logger.info(f" *** mera v{__version__} ***")
        logger.info(f"Starting deployment of model '{model.model_name}'...")

        # Change directory to target's build subdir
        self.prj.pushd("build", abs=True)
        self.prj.pushd(target_str)
        os.chdir(self.prj.get_cwd())

        tm_start = time.time()
        # Prepare deploy cfg file
        import yaml

        __from_qtz = bool(kwargs.get("__orig_mera_qtz", False))
        build_config["target"] = target_str
        build_config = (
            self.__populate_ccfg(build_config)
            if mera_platform.accelerator_kind == AccelKind.DNA
            else {}
        )
        ccfg_str = yaml.safe_dump(build_config).rstrip("\n")
        deploy_cfg_json = self._prepare_model_parse_cfg(
            model,
            arch_val,
            ccfg_str,
            host_arch,
            target,
            mera_platform,
            vela_config.get("enable_ospi", False),
            kwargs.get("enable_ref_data", False),
            __from_qtz,
            kv_cache_length=kv_cache_length,
            backend_options=kwargs.get("backend_options", {}),
            attention_dim_pad=kwargs.get("attention_dim_pad", 32),
            enable_gather_mera_block=kwargs.get("enable_gather_mera_block", False),
        )
        deploy_cfg_json = self.prj.save_artifact(
            "deploy_cfg.json", ArtifactFileType.JSON, "mera2_dcfg", deploy_cfg_json
        )
        cwd = self.prj.get_cwd()

        # Parse the model and assign target regions.
        self._apply_frontend(model, deploy_cfg_json)
        try:
            # Try to reload IO desc
            model._update_input_desc(cwd / "io_desc.json")
        except Exception:
            pass

        if target == Target.MERAInterpreter:
            # MERA2 Interpreter does not need extra deployment, finish it here
            self.prj.compile_flow = CompilationFlow.MERA_INTERPRETER
            model_ir_loc = cwd / "model.mir"
            self.prj.add_artifact([(target_str, model_ir_loc)])
            os.chdir(curr_cwd)
            return MeraInterpreterDeployment(model_ir_loc)
        elif target == Target.MCU:
            # MCU Flow

            from .backend.dnax_compile import (
                dnax_run_model_gen,
                has_dnax_regions,
                meradnax_compile,
            )
            from .backend.mcu_compile import (
                ccodegen_compile,
                ethos_compile,
                has_ethos_regions,
            )

            ir_loc = cwd / "compilation"
            ccodegen_loc = Path(find_tool("ccodegen"))
            __has_ethos = has_ethos_regions(ir_loc)
            __suffix = mcu_config.get("suffix", "")
            ccodegen_compile(
                ir_loc,
                ccodegen_loc,
                suffix=__suffix,
                weight_location=mcu_config.get("weight_location", "flash"),
                use_x86=mcu_config.get("use_x86", True),
                use_ospi=vela_config.get("enable_ospi", False),
            )
            if has_ethos_regions(ir_loc):
                ethos_compile(
                    ir_loc,
                    ccodegen_loc,
                    suffix=__suffix,
                    config=vela_config.get("config", None),
                    enable_ospi=vela_config.get("enable_ospi", False),
                    sys_config=vela_config.get("sys_config", "RA8P1"),
                    memory_mode=vela_config.get("memory_mode", "Sram_Only"),
                    accel_config=vela_config.get("accel_config", "ethos-u55-256"),
                    optimise=vela_config.get("optimise", "Performance"),
                    verbose_all=vela_config.get("verbose_all", False),
                )
            if bool(kwargs.get("enable_ref_data", False)):
                cmd(f"{ccodegen_loc / 'tflite_io_data'} {deploy_cfg_json}")

            if has_dnax_regions(ir_loc):
                meradnax_compile(ir_loc, self.prj, mera_platform)
            if mera_platform == Platform.ALTX_SMALL:
                dnax_run_model_gen(self.prj.root_path, self.prj.root_path, mcu_config)
            os.chdir(curr_cwd)
        else:
            self.prj.compile_flow = CompilationFlow.MERA
            # DNA - Flow
            # Compile for 'CPU' targets.
            from .backend.tvm_compile import apache_tvm_compile

            apache_tvm_compile(cwd / "compilation", logger, host_arch)

            # DNAX - Flow
            ir_loc = cwd / "compilation"
            from .backend.dnax_compile import has_dnax_regions, meradnax_compile

            if has_dnax_regions(ir_loc):
                plan_loc = meradnax_compile(
                    ir_loc,
                    self.prj,
                    mera_platform,
                    {
                        "dma_mode": "None"
                        if target in [Target.VerilatorSimulator]
                        else "Full"
                    },
                )
            else:
                # Compile for 'DNA' targets.
                with _progress_relay(build_config, model.model_name):
                    cmd(
                        f"{find_tool('mera_dna_compile')} {deploy_cfg_json}",
                        stdout=None,
                    )
                # Add mera.plan file to mark deployment for this target completed.
                plan_loc = cwd / "compilation" / "mera.plan"
            self.prj.add_artifact([(target_str, plan_loc)])

            tm_end = time.time()
            time_taken = tm_end - tm_start
            logger.info(
                f"Compilation finished successfully. Took {time.strftime('%Hh%Mm%Ss', time.gmtime(time_taken))}"
            )
            os.chdir(curr_cwd)
            return MeraDeployment(plan_loc, target)


# Useful alias
Deployer = MERADeployer
