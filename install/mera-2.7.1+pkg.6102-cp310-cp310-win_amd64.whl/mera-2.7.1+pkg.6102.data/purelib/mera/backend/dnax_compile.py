# Copyright 2025 EdgeCortix Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from pathlib import Path
from .utils import get_backend_binaries_dict, check_plan_json
from ..utils import cmd, find_tool
from ..mera_platform import Platform

_DNAX_BIN_ID = "mera_dnax"


def generate_dnax_compile_cfg(user_cfg):
    return {
        "compiler_workers": int(user_cfg.get("compiler_workers", 1)),
        "target": str(user_cfg.get("target", "IP")),
        "dma_mode": str(user_cfg.get("dma_mode", "Full")),
    }


def has_dnax_regions(compile_loc):
    return _DNAX_BIN_ID in get_backend_binaries_dict(compile_loc)


def dnax_run_model_gen(deploy_dir, output_dir, mcu_config={}):
    args = f"{find_tool('dnax_run_model_gen')} -d {deploy_dir} -o {output_dir}"
    if mcu_config.get("semihosting", False):
        args += " -s"
    if "dnax_regs_base" in mcu_config:
        args += f" --dnax-regs-base {mcu_config['dnax_regs_base']}"
    if "dnax_sram_base" in mcu_config:
        args += f" --dnax-sram-base {mcu_config['dnax_sram_base']}"
    if "muriscv_path" in mcu_config:
        args += f" --muriscv-path {mcu_config['muriscv_path']}"
    if "driver_dir" in mcu_config:
        args += f" --driver-dir {mcu_config['driver_dir']}"
    cmd(args)


def meradnax_compile(compile_loc, prj, mera_platform, compile_cfg={}):
    plan_loc = Path(check_plan_json(compile_loc))
    cfg_json = generate_dnax_compile_cfg(compile_cfg)
    from ..deploy_project import ArtifactFileType

    compile_cfg_loc = prj.save_artifact(
        "mdnax_compile_cfg.json", ArtifactFileType.JSON, "mera2_dcfg", cfg_json
    )
    platform_opt = "CHEETAH" if mera_platform == Platform.ALTX_SMALL else "SAKURA_X"
    cmd(
        f"{find_tool('mera_dnax_compile')} --plan_path {plan_loc} -c {compile_cfg_loc} -a {platform_opt}"
    )
    return plan_loc
