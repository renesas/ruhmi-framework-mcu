# Copyright 2022 EdgeCortix Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Mera: Public API for Mera ML compiler stack."""

# ruff: noqa: E402  -- Windows DLL directory setup below must run before native-extension imports

import os as _os

if _os.name == "nt":
    _mera2libs_dir = _os.path.join(_os.path.dirname(__file__), "mera2libs")
    if _os.path.isdir(_mera2libs_dir):
        try:
            _os.add_dll_directory(_mera2libs_dir)
        except (AttributeError, OSError):
            pass
        _os.environ["PATH"] = _mera2libs_dir + _os.pathsep + _os.environ.get("PATH", "")
    del _mera2libs_dir
del _os

from .version import (
    __version__ as __version__,
    get_versions as get_versions,
    get_mera_version as get_mera_version,
    get_mera_dna_version as get_mera_dna_version,
)

from .deploy import (
    MERADeployer as MERADeployer,
    Deployer as Deployer,
)

from .mera_model import (
    ModelLoader as ModelLoader,
    MeraModel as MeraModel,
    calculate_kv_cache_size as calculate_kv_cache_size,
)

from .model import InputNormCfg as InputNormCfg

from .mera_deployment import (
    load_mera_deployment as load_mera_deployment,
)

from .deploy_project import Target as Target, Layout as Layout

from .mera_platform import Platform as Platform

from .mera_quantizer import Quantizer as Quantizer

from .quantization_quality import (
    QuantizationQualityMetrics as QuantizationQualityMetrics,
    calculate_quantization_quality as calculate_quantization_quality,
)

from .model.input_desc import (
    InputDescription as InputDescription,
    InputDescriptionContainer as InputDescriptionContainer,
)

from .metrics.power_metrics import PowerMetrics as PowerMetrics
