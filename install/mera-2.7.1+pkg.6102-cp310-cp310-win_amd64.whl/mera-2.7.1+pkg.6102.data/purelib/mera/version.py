# Copyright 2022 EdgeCortix Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


# Current version, modify this file for release using "bump_version.py"
__version__ = "2.7.1+pkg.6102"
__release_date__ = "2026-08-07"


def get_mera_dna_version() -> str | None:
    """Gets the version string for libmeradna

    :return: Summary of libmeradna version
    """
    try:
        from .utils import find_tool
        import subprocess

        with subprocess.Popen(
            f"{find_tool('mera_dna_compile')} --version",
            shell=True,
            stdout=subprocess.PIPE,
        ) as p:
            # Removes trailing \n'
            assert p.stdout is not None
            v_str = str(list(p.stdout)[0])[:-3]
        return v_str if p.returncode == 0 else None
    except Exception:
        return None


def get_mera_version() -> str:
    """Gets the version string for Mera

    :return: Version string for Mera
    """
    return f"mera version {__version__} released on {__release_date__}"


def get_mera2_rt_version() -> str | None:
    """
    "return: The version string for mera2-runtime
    """
    try:
        from mera2._version import __version__ as __m2rt_version
        from mera2._version import __githash__ as __m2rt_githash

        return f"{__m2rt_version} ({__m2rt_githash})"
    except Exception:
        return None


def _get_version_metadata():
    meradna_ver = get_mera_dna_version()
    mera2_rt_ver = get_mera2_rt_version()
    __VER: dict[str, dict[str, str | None]] = {
        "mera": {"version": __version__, "release_date": __release_date__}
    }
    if meradna_ver is not None:
        __VER["mera-dna"] = {"version": meradna_ver.split(" ")[1], "release_date": None}
    if mera2_rt_ver is not None:
        __VER["mera2-runtime"] = {
            "version": get_mera2_rt_version(),
            "release_date": None,
        }
    return __VER


def get_versions() -> str:
    """Return a summary of all installed modules on the Mera environment

    :return: List of all module's versions.
    """
    s = "Mera Environment Versions:\n"
    for m, d in _get_version_metadata().items():
        s += f" * {m} version {d['version']} "
        if d["release_date"]:
            s += f"released on {d['release_date']}"
        s += "\n"
    return s
