# Copyright 2022 EdgeCortix Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Mera Deployment classes"""

import abc
import json
import numpy as np
from pathlib import Path
from enum import Enum
from .deploy_project import (
    is_mera_project,
    _create_mera_project,
    Target,
    logger,
    CompilationFlow,
)
from .metrics.power_metrics import PowerMetrics
from .utils import mera2_sanitize, preload_dna_full_lib
from .version import __version__


class ModelRunnerBase(metaclass=abc.ABCMeta):
    """API for runtime inference of a model."""

    @abc.abstractmethod
    def set_input(self, data: np.ndarray | dict[str, np.ndarray] | list[np.ndarray]):
        """Sets the input data for running

        :param data: Input numpy data tensor or dict of input numpy data tensors if the model has more than one input.
            Setting multiple inputs should have the format `{input_name : input_data}`
        """
        pass

    @abc.abstractmethod
    def run(self) -> None:
        """Runs the model with the specified input data. :func:`set_input()` needs to be called before :func:`run()`"""
        pass

    @abc.abstractmethod
    def get_output(self, output_idx: int = 0) -> np.ndarray:
        """Returns the output tensor given an output id index. :func:`run()` needs to be called before :func:`get_output()`

        :param output_idx: Index of output variable to query
        :return: Output tensor values in numpy format
        """
        pass

    @abc.abstractmethod
    def get_outputs(self) -> list[np.ndarray]:
        """Returns a list of all output tensors. Equivalent to :func:`get_output()` from `[0, get_num_outputs()]`

        :return: List of output tensor values in numpy format
        """
        pass

    @abc.abstractmethod
    def get_num_outputs(self) -> int:
        """Gets the number of available outputs

        :return: Number of output variables
        """
        pass

    @abc.abstractmethod
    def get_runtime_metrics(self) -> dict:
        """Gets the runtime metrics reported from Mera after a :func:`run()`

        :return: Dictionary of measured metrics
        """
        pass

    @abc.abstractmethod
    def get_power_metrics(self) -> PowerMetrics:
        """Gets the power metrics reported from MERA after a :func:`run()`.
        Note power measurement mode might need to be enable in order to collect and generate such metrics.

        :return: Container with summary analysis of all collected metrics from MERA.
        """
        pass

    def set_dynamic_position(self, pos_idx: int):
        """Updates the position where the model's dynamic data will be fetch. Actual behaviour depends on the model's feature:
            - Transformer KV Cache: Marks the position where the current token will be saved in the cache. Accepted values will be 0 up to built sequence length.

        :param pos_idx: Logical position value
        """
        raise NotImplementedError(
            "set_dynamic_position not implemented for this runner"
        )

    def run_async(self) -> "MeraAsyncRunHandle":
        """Submits the model for non-blocking execution and returns a handle to poll/wait on.

        Only supported by the IP/device runner (:class:`MeraModelRunner`). CPU-only
        runners such as the interpreter execute synchronously and have no async path;
        use :func:`run` instead.

        :return: Handle to poll or wait on the in-flight run.
        """
        raise NotImplementedError(
            f"run_async() is not supported by {type(self).__name__}: this runner "
            "executes synchronously on CPU. Use run() instead."
        )


class MeraAsyncRunHandle:
    """Handle to a non-blocking inference submitted via :func:`MeraModelRunner.run_async`.

    Poll with :func:`ready`/:func:`status` or block with :func:`wait`. Inputs must be
    written before submitting, and outputs must only be read once the handle completes.
    """

    def __init__(self, native_handle):
        self._h = native_handle

    def ready(self) -> bool:
        """Non-blocking poll. Returns True once the run has completed."""
        return self._h.Ready()

    def status(self):
        """Returns the run status (`RunStatus` enum: InFlight / Complete / Failed)."""
        return self._h.Status()

    def wait(self, timeout_us: int | None = None) -> bool:
        """Blocks until the run completes, or up to `timeout_us` microseconds if given.

        :param timeout_us: Optional timeout in microseconds. If None, blocks indefinitely.
        :return: True if the run completed, False if the timeout elapsed.

        Re-raises any exception raised on the worker thread once the run completes.
        """
        if timeout_us is None:
            self._h.Wait()
            return True
        return self._h.WaitFor(timeout_us)


class MeraModelRunner(ModelRunnerBase):
    def __init__(self, runner, plan):
        self.runner = runner
        self.plan = plan
        self.input_names = {
            n[0]: (i, n[1]) for i, n in enumerate(list(runner.InputNames()))
        }
        self.output_names = {
            n[0]: (i, n[1]) for i, n in enumerate(list(runner.OutputNames()))
        }

    def __enter__(self):
        """For now, just return self."""
        return self

    def __exit__(self, exception_type, exception_value, traceback):
        """Clean the runtime"""
        self.cleanup()

    def cleanup(self):
        """Clean the MeraRuntime to ensure the DDR memory is clean"""
        del self.runner
        import gc

        gc.collect()

    def __check_input_name(self, name):
        if name not in self.input_names:
            raise ValueError(
                f"Input {name} is not one of the valid input(s) of the model: {list(self.input_names.keys())}"
            )

    def __check_output_name(self, name):
        if name not in self.output_names:
            raise ValueError(
                f"Output {name} is not one of the valid output(s) of the model: {list(self.output_names.keys())}"
            )

    def __sanitize_name(self, name):
        return str(name).replace(":", "_")

    def __get_input_idx(self, name):
        name = self.__sanitize_name(name)
        self.__check_input_name(name)
        return self.input_names[name][0]

    def __get_output_idx(self, name):
        name = self.__sanitize_name(name)
        self.__check_output_name(name)
        return self.output_names[name][0]

    def __mera_buffer_dtype_to_numpy_type(self, mera_dtype):
        import mera2.rt as m2rt

        if mera_dtype == m2rt.DType.BOOL:
            return "bool"
        elif mera_dtype == m2rt.DType.INT8:
            return "int8"
        elif mera_dtype == m2rt.DType.UINT8:
            return "uint8"
        elif mera_dtype == m2rt.DType.INT32:
            return "int32"
        elif mera_dtype == m2rt.DType.INT64:
            return "int64"
        elif mera_dtype == m2rt.DType.FLOAT32:
            return "float32"
        else:
            return "undefined"

    def __get_input_name(self, idx):
        for k, i in self.input_names.items():
            if i[0] == idx:
                return k
        raise ValueError(f"Input idx {idx} could not be found")

    def __get_input_datatype(self, idx):
        for _, i in self.input_names.items():
            if i[0] == idx:
                return i[1].data_type
        raise ValueError(f"Input idx {idx} could not be found")

    def __get_output_name(self, idx):
        for k, i in self.output_names.items():
            if i[0] == idx:
                return k
        raise ValueError(f"Output idx {idx} could not be found")

    def __get_output_datatype(self, idx):
        for _, i in self.output_names.items():
            if i[0] == idx:
                return i[1].data_type
        raise ValueError(f"Output idx {idx} could not be found")

    def get_input_handle(
        self, name: str, as_numpy: bool = True, dtype: str = "float32"
    ):
        """Gets the zero-copy handler to the specified model input.
        :param name: Name of the input.
        :param as_numpy: Whether to prepare handle as numpy array. Defaults to true.
        :param dtype: Viewer data type.

        :return: Input data handler.
        """
        import mera2.rt as m2rt

        self.__check_input_name(name)
        __dtype_map = {
            "float32": m2rt.InputViewFloat,
            "int64": m2rt.InputViewInt64,
            "int8": m2rt.InputViewInt8,
            "uint8": m2rt.InputViewUInt8,
            "int32": m2rt.InputViewInt32,
        }
        if dtype not in __dtype_map:
            raise ValueError(f"Unsupported viewer type {dtype}")
        in_viewer = __dtype_map[dtype](self.runner)
        in_viewer.SelectArea(name)
        if as_numpy:
            return np.asarray(in_viewer)
        return in_viewer

    def get_output_handle(
        self, name: str, as_numpy: bool = True, dtype: str = "float32"
    ):
        """Gets the zero-copy handler to the specified model output.
        :param name: Name of the output.
        :param as_numpy: Whether to prepare handle as numpy array. Defaults to true.
        :param dtype: Viewer data type.

        :return: Output data handler.
        """
        import mera2.rt as m2rt

        self.__check_output_name(name)
        __dtype_map = {
            "float32": m2rt.OutputViewFloat,
            "int64": m2rt.OutputViewInt64,
            "int8": m2rt.OutputViewInt8,
            "uint8": m2rt.OutputViewUInt8,
            "int32": m2rt.OutputViewInt32,
        }
        if dtype not in __dtype_map:
            raise ValueError(f"Unsupported viewer type {dtype}")
        out_viewer = __dtype_map[dtype](self.runner)
        out_viewer.SelectArea(name)
        if as_numpy:
            return np.asarray(out_viewer)
        return out_viewer

    def set_named_input(self, name: str, data: np.ndarray):
        """Copies data to the named model input using the zero-copy buffer.
        :param name: Name of the input.
        """
        name = self.__sanitize_name(name)
        in_buf = self.input_names[name][1]
        if (data.size * data.itemsize) > in_buf.bytes_size:
            raise ValueError(
                f'ERROR: Input data "{name}" with shape {data.shape}[{data.dtype.name}] '
                + f"overflows memory allocated for input with shape {in_buf.shape}[{in_buf.data_type}]"
            )
        handle = self.get_input_handle(name, as_numpy=True, dtype=data.dtype.name)
        np.copyto(handle, data, casting="no")
        return self

    def set_input(self, data: np.ndarray | dict[str, np.ndarray] | list[np.ndarray]):
        d_ = []
        if isinstance(data, list):
            for idx, d in enumerate(data):
                d_.append((self.__get_input_name(idx), d))
        elif isinstance(data, dict):
            for k, d in data.items():
                self.__check_input_name(self.__sanitize_name(k))
                d_.append((k, d))
        else:
            if len(self.input_names) > 1:
                raise ValueError(
                    f"Expected an array-like of inputs to be provided, got {type(data)} instead."
                )
            n = list(self.input_names)[0]
            d_.append((n, data))
        [self.set_named_input(name, data) for name, data in d_]
        logger.debug(f"Set {len(d_)} input data variables")
        return self

    def set_dynamic_position(self, pos_idx: int):
        self.runner.SetDynamicPosition(pos_idx)
        return self

    def run(self):
        self.runner.Run()
        return self

    def run_async(self) -> MeraAsyncRunHandle:
        """Submits the model for non-blocking execution and returns immediately.

        Write inputs via :func:`set_input` *before* calling. Read outputs via
        :func:`get_output`/:func:`get_outputs` only *after* the returned handle
        completes (`wait()` returns or `ready()` is True); between submit and
        completion the worker thread owns the I/O buffers. :func:`set_input` needs
        to be called before :func:`run_async`.

        :return: Handle to poll or wait on the in-flight run.
        """
        return MeraAsyncRunHandle(self.runner.RunAsync())

    def get_output(self, output_idx: int = 0) -> np.ndarray:
        out_dtype = self.__mera_buffer_dtype_to_numpy_type(
            self.__get_output_datatype(output_idx)
        )
        return self.get_output_handle(
            self.__get_output_name(output_idx), dtype=out_dtype
        )

    def get_output_row(self, row_idx: int, output_idx: int = 0) -> np.ndarray:
        out_dtype = self.__mera_buffer_dtype_to_numpy_type(
            self.__get_output_datatype(output_idx)
        )
        handle = self.get_output_handle(
            self.__get_output_name(output_idx), dtype=out_dtype, as_numpy=False
        )
        # Read the data here
        handle.FetchDynamicOutput(row_idx)
        return np.asarray(handle)

    def get_outputs(self) -> list[np.ndarray]:
        return [self.get_output(i) for i in range(self.get_num_outputs())]

    def get_outputs_dict(self) -> dict[str, np.ndarray]:
        return {
            out_name: self.get_output(i) for i, out_name in enumerate(self.output_names)
        }

    def get_input_names(self) -> list[str]:
        return list(self.input_names.keys())

    def get_input_dtypes(self) -> dict[str, np.dtype]:
        """Returns a dict mapping each input name to its numpy dtype."""
        return {
            name: np.dtype(self.__mera_buffer_dtype_to_numpy_type(buf_info.data_type))
            for name, (_, buf_info) in self.input_names.items()
        }

    def get_output_names(self) -> list[str]:
        return list(self.output_names.keys())

    def get_num_outputs(self) -> int:
        return len(self.output_names)

    def __parse_metrics_data(self, data):
        def __f(val):
            st = 0
            pos = 0
            D = {}

            while pos != -1:
                pos = val.find("=", st)
                next_key = val[st:pos]
                st = pos + 1
                if val[st] == "[":
                    pos = val.find("]", st)
                    next_val = [x for x in val[st + 1 : pos].split(",")]
                    st = pos + 2
                else:
                    pos = val.find(",", pos)
                    next_val = float(val[st:] if pos == -1 else val[st:pos])
                    st = pos + 1
                D[next_key] = next_val
            return D

        return {k: __f(v) for k, v in data.items()}

    def get_runtime_metrics(self) -> dict:
        return self.__parse_metrics_data(self.runner.GetRuntimeMetrics())

    def get_power_metrics(self) -> PowerMetrics:
        # TODO - Proper filtering function.
        return PowerMetrics(self.runner.GetPowerMetrics())


class MeraInterpreterModelRunner(ModelRunnerBase):
    def __init__(self, int_runner, int_cfg):
        self.int_runner = int_runner
        self.int_cfg = int_cfg
        self.input_info = self.int_runner.GetInputInfo()
        self.output_info = self.int_runner.GetOutputInfo()
        self.input_names = {n.id: (i, n.shape) for i, n in enumerate(self.input_info)}
        self.output_names = {n.id: (i, n.shape) for i, n in enumerate(self.output_info)}

    def __fetch_input_info(self, in_id):
        _s = [x for x in self.input_info if x.id == in_id]
        if len(_s) != 1:
            logger.warning(
                f"Provided input name {in_id} is not one of the valid inputs {list(self.input_names.keys())}. Ignoring it."
            )
            return
        return _s[0]

    def __fetch_output_info(self, out_id):
        _s = [x for x in self.output_info if x.id == out_id]
        if len(_s) != 1:
            raise ValueError(f"Could not find output info for tensor {out_id}")
        return _s[0]

    def __datatype_to_nptype(self, dtype_str):
        __dtype_map = {
            "UInt8": np.uint8,
            "Int8": np.int8,
            "Int32": np.int32,
            "Bool": bool,
            "Int64": np.int64,
            "Float32": np.float32,
        }
        return __dtype_map.get(dtype_str)

    def set_input(self, data: np.ndarray | dict[str, np.ndarray] | list[np.ndarray]):
        if self.get_num_inputs() == 1:
            if not isinstance(data, dict):
                _d = {self.input_info[0].id: data}
            else:
                _d = data
        elif not isinstance(data, dict):
            raise ValueError("Multiple inputs must be set by dict[str, data]")
        else:
            _d = data
        for in_id, in_data in _d.items():
            in_id = mera2_sanitize(in_id)
            iinfo = self.__fetch_input_info(in_id)
            if iinfo:
                assert isinstance(in_data, np.ndarray)
                if in_data.shape != tuple(iinfo.shape):
                    raise ValueError(
                        f"Shape input mismatch for {in_id}: {in_data.shape} vs {iinfo.shape}"
                    )
                if in_data.dtype != self.__datatype_to_nptype(iinfo.dtype_str):
                    raise ValueError(
                        f"Input dtype mismatch for {in_id}: {in_data.dtype} vs {iinfo.dtype_str}"
                    )
                self.int_runner.SetInput(in_id, in_data.ravel().view("uint8"))
        return self

    def set_dynamic_position(self, pos_idx: int):
        self.int_runner.SetDynamicPosition(pos_idx)
        return self

    def run(self):
        self.int_runner.Run()
        if self.int_cfg.get("profiling_mode", False):
            self.display_profiling_table()
        return self

    def display_profiling_table(self):
        profile_data = self.int_runner.GetProfilingResults()
        from tabulate import tabulate

        D = []
        profile_data = sorted(profile_data, key=lambda x: x.total_time_ms)
        total_lat = sum([float(x.total_time_ms) for x in profile_data])
        total_nodes = sum([int(x.node_count) for x in profile_data])
        for pd in profile_data:
            avg = pd.total_time_ms / pd.node_count
            perc = 100 * pd.total_time_ms / total_lat
            D.append([pd.node_class, pd.node_count, pd.total_time_ms, avg, perc])
        D.append(["TOTAL", total_nodes, total_lat, total_lat / total_nodes, 100.0])
        H = ["Node Class", "# of nodes", "Total time (ms)", "Avg (ms)", "Time %"]
        print(
            tabulate(
                D, headers=H, tablefmt="fancy_outline", numalign="right", floatfmt=".2f"
            )
        )

    def get_num_inputs(self) -> int:
        return len(self.input_info)

    def get_input_names(self) -> list[str]:
        return list(self.input_names.keys())

    def get_input_dtypes(self) -> dict[str, np.dtype]:
        """Returns a dict mapping each input name to its numpy dtype."""
        return {
            iinfo.id: np.dtype(self.__datatype_to_nptype(iinfo.dtype_str))
            for iinfo in self.input_info
        }

    def get_output(self, output_idx: int = 0) -> np.ndarray:
        return self.get_outputs()[output_idx]

    def get_output_row(self, row_idx: int, output_idx: int = 0) -> np.ndarray:
        return np.expand_dims(
            np.take(self.get_output(output_idx), row_idx, axis=-2), axis=0
        )

    def get_outputs(self) -> list[np.ndarray]:
        R = [None] * self.get_num_outputs()
        for k, v in self.get_outputs_dict().items():
            R[self.output_names[k][0]] = v
        return R

    def get_num_outputs(self) -> int:
        return len(self.output_names)

    def get_outputs_dict(self) -> dict[str, np.ndarray]:
        r = {}
        for out_name, data_raw in self.int_runner.GetOutputs().items():
            out_info = self.__fetch_output_info(out_name)
            out_dt = self.__datatype_to_nptype(out_info.dtype_str)
            r[out_name] = (
                np.array(data_raw, dtype=np.uint8)
                .view(out_dt)
                .reshape(tuple(out_info.shape))
            )
        return r

    def get_runtime_metrics(self) -> dict:
        raise NotImplementedError("get_runtime_metrics() not implemented yet.")

    def get_power_metrics(self) -> PowerMetrics:
        raise ValueError("get_power_metrics call not available for Interpreter runner.")


class DeviceTarget(Enum):
    """List of possible MERA runtime devices for running IP deployments."""

    SAKURA_1 = (
        "Sakura-1",
        1,
    )  #: Not supported as of MERA 2.6.0. Was EdgeCortix Sakura-1 ASIC.
    SAKURA_2 = ("Sakura-2", 5)  #: Target device is an EdgeCortix's Sakura-2 ASIC.
    XILINX_U50 = (
        "AMD Xilinx U50",
        2,
    )  #: Not supported as of MERA 2.6.0. Was AMD Xilinx U50 FPGA board.
    INTEL_IA420 = (
        "Intel IA420",
        3,
    )  #: Not supported as of MERA 2.6.0. Was Intel IA420 FPGA board.
    DRPAI_CPU_MEM = (
        "DrpAi Cpu Memory",
        1,
    )  #: Target device is an Renesas DRPAI with CPU memory
    DRPAI_BUILTIN_MEM = (
        "DrpAi Built-in Memory",
        36,
    )  #: Target device is an Renesas DRPAI with built-in memory (MMNGR for V2H, udma for V2ML)
    ALTX = ("ALTX", 20)  #: Target placeholder ALTX platform.

    def __init__(self, str_val, code):
        self.__str_val = str_val
        self.__code = code

    def __str__(self):
        return self.__str_val

    @property
    def code(self):
        return self.__code


class MeraDeployment:
    def __init__(self, plan_loc, target):
        self.plan_loc = Path(plan_loc)
        self.build_loc = self.plan_loc.parent
        self.target = target
        if not self.plan_loc.exists():
            raise ValueError(
                f"MERA execution plan file {self.plan_loc} does not exist."
            )

    def get_runner(
        self,
        device_target: DeviceTarget = DeviceTarget.SAKURA_2,
        device_ids: int | list[int] | None = None,
        start_address: int = -1,
        frequency_index: int = 1,
        dynamic_output_list: list[int | str] | None = None,
    ) -> MeraModelRunner:
        """Prepares the model for running with a given target

        :param device_target: Selects the device run target where the IP deployment will be run. Only applicable for deployments
            with target=IP. See `DeviceTarget` enum for a detailed list of possible values.
        :param device_ids: When running in a multi card environment, selects the SAKURA device(s) where the deployment will be run.
            If unset, MERA will automatically select any available card in the system. Only applicable when device_target is SAKURA_2.
        :param start_address: Renesas MPUs only. Set the DRP-AI start address.
        :param frequency_index: Renesas MPUs only. Set the board frequency index. (1:1000MHz,  3:630MHz, 4:420MHz, 5:315MHz, 6:252MHz, 7:210MHz, 8:180MHz, 9:158MHz 10:140MHz, 11:126MHz, 12:115MHz, 13:105MHz, 14: 97MHz, 15: 90MHz, 16: 84MHz)
        :param dynamic_output_list: Marks certain outputs so that only a dynamic subset of the data is returned. See special get_output_row() function
            in MeraModelRunner. This feature is only supported when running in IP.

        :return: Runner object
        """
        # TODO - device_target
        if self.target is None or self.target.x86_only:
            # Simulator/Interpreter targets are only implemented in libmeradna-full,
            # not in the libmeradna-runtime mera2.rt links against. Load it first so
            # it interposes. Unknown target (self.target is None) errs on preloading.
            preload_dna_full_lib()
        import mera2.rt as m2rt

        m2rt.RegisterLogger()

        # Load plan and create instance of MERA Runtime
        plan = m2rt.LoadRuntimePlan(str(self.plan_loc))
        runner = m2rt.MeraRuntime(plan, str(self.build_loc))

        if dynamic_output_list:
            # parse the list
            __dyn_output_parsed = []
            __out_names = list([x[0] for x in runner.OutputNames()])
            for dyn_out in dynamic_output_list:
                if isinstance(dyn_out, int):
                    __dyn_output_parsed.append(str(__out_names[dyn_out]))
                else:
                    __dyn_output_parsed.append(str(dyn_out))
            __needs_row_fetching = bool(self.target == Target.IP)
            runner.SetDynamicOutputs(__needs_row_fetching, set(__dyn_output_parsed))

        # Pre-load and initialize all the binary artifacts
        if device_ids is not None:
            if isinstance(device_ids, int):
                device_ids = [device_ids]
            runner.SetDevices(device_ids)
        if device_target in {
            DeviceTarget.DRPAI_CPU_MEM,
            DeviceTarget.DRPAI_BUILTIN_MEM,
        }:
            runner.SetStartAddress(start_address)
            runner.SetDeviceType(device_target.code)
            runner.SetFrequencyIndex(frequency_index)
        runner.Init()
        return MeraModelRunner(runner, plan)


class MeraPrjDeployment(MeraDeployment):
    def __init__(self, plan_loc, prj, target):
        super().__init__(plan_loc, target)
        self.prj = prj


class MeraInterpreterDeployment:
    def __init__(self, model_loc):
        self.model_loc = Path(model_loc)
        self.cfg_loc = self.model_loc.parent / "int_config.json"
        self.__constant_loc = self.model_loc.parent / "constants"
        if not self.model_loc.exists():
            raise ValueError(f"MERA model file {self.model_loc} does not exist.")

    def get_runner(
        self, profiling_mode: bool = False, config_dict: dict = {}, **kwargs
    ) -> MeraInterpreterModelRunner:
        """Prepares the Interpreter for running the model.

        :param profiling_mode: Enables collection of node execution times.

        :return: Runner object
        """
        from .mera2libs import interpreter as m2_interpreter

        m2_interpreter.RegisterLogger()

        __int_cfg = {
            "profiling_mode": profiling_mode,
            "constant_loc_path": str(self.__constant_loc),
            "buffer_dump_path": "",
            "enable_dnax_macrocode": False,
        }
        __int_cfg = {**__int_cfg, **config_dict}
        with open(self.cfg_loc, "w") as w:
            json.dump(__int_cfg, w)

        return MeraInterpreterModelRunner(
            m2_interpreter.CreateInterpreter(str(self.model_loc), str(self.cfg_loc)),
            __int_cfg,
        )


class MeraInterpreterPrjDeployment(MeraInterpreterDeployment):
    def __init__(self, model_loc, prj):
        super().__init__(model_loc)
        self.prj = prj


def load_mera_deployment(
    path: str, target: Target | None = None
) -> "MeraDeployment | MeraInterpreterDeployment":
    """Loads an already built deployment from a directory

    :param path: Directory of a Mera deployment project or full directory of built mera results
    :param target: If there are multiple targets built in the mera project selects which one.
        Optional if not loading a project or if there is a single target built.
    :return: Reference to deployment object
    """
    p = Path(path).resolve()
    if is_mera_project(p):
        logger.info(f"Loading deployment from Mera project '{p}' ...")
        prj = _create_mera_project(p)
        avail_targets = [x for x in Target if prj.has_artifact_section(x.str_val)]
        if not avail_targets:
            raise ValueError(f"Could not find any deployment in project {p}")
        if target and target not in avail_targets:
            raise ValueError(
                f"Could not find target {target} from available built targets [{' '.join([x.str_val for x in avail_targets])}]"
            )
        t = avail_targets[0] if len(avail_targets) == 1 else target
        assert t is not None

        if prj.compile_flow == CompilationFlow.TVM:
            raise ValueError(
                f"TVM deployment projects are not supported as of MERA {__version__}. "
                "Please recompile the model using MERADeployer."
            )
        elif (
            prj.compile_flow == CompilationFlow.MERA
            and target != Target.MERAInterpreter
        ):
            # Hand over the resolved target `t`, not the (optional) user argument, so
            # the deployment always knows what it is running.
            return MeraPrjDeployment(prj.get_artifact(t.str_val, "mera.plan"), prj, t)
        elif (
            prj.compile_flow == CompilationFlow.MERA_INTERPRETER
            or target == Target.MERAInterpreter
        ):
            return MeraInterpreterPrjDeployment(
                prj.get_artifact(t.str_val, "model.mir"), prj
            )
        else:
            raise ValueError(f"Unhandled compilation flow: {prj.compile_flow}")
    raise ValueError(f"Path '{path}' is not a valid MERA deployment project.")
