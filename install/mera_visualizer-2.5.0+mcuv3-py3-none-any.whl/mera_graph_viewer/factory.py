"""Flask application factory."""

import logging
from flask import Flask
from pathlib import Path

from .storage.graph_store import GraphStore
from .core.graph_processor import GraphProcessor


def create_app(config_name='default', db_path='mera_graphs.db'):
    """
    Create and configure Flask application.

    Args:
        config_name: Configuration preset ('default', 'testing', 'development')
        db_path: Path to SQLite database file

    Returns:
        Configured Flask app instance
    """
    app = Flask(__name__)

    if config_name == 'testing':
        app.config['TESTING'] = True
        import tempfile
        import os
        fd, temp_db = tempfile.mkstemp(suffix='.db', prefix='test_mera_')
        os.close(fd)
        app.config['DB_PATH'] = temp_db
    elif config_name == 'development':
        app.config['DEBUG'] = True
        app.config['TEMPLATES_AUTO_RELOAD'] = True
        app.config['DB_PATH'] = db_path
    else:
        app.config['DB_PATH'] = db_path

    app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16 MB max upload

    if not app.config.get('TESTING'):
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )

    storage = GraphStore(db_path=app.config['DB_PATH'])
    processor = GraphProcessor(storage)

    app.extensions = getattr(app, 'extensions', {})
    app.extensions['storage'] = storage
    app.extensions['processor'] = processor

    from .routes import web_bp, api_bp
    app.register_blueprint(web_bp)
    app.register_blueprint(api_bp, url_prefix='/api')

    app.logger.info(f"Application initialized (config={config_name}, db={app.config['DB_PATH']})")

    return app
