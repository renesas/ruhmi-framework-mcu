"""
MERA Viewer - Neural Network Graph Visualization Tool

A Flask-based web application for visualizing neural network graphs
with device compatibility and performance metrics visualization.
"""

__version__ = "2.5.0"
__author__ = "Neural Network Graph Visualization Tool"
__description__ = "A neural network graph visualization tool with interactive web interface"
