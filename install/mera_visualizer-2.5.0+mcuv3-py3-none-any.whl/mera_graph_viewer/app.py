"""Main application entry point."""

from .factory import create_app

app = create_app(config_name='default')

if __name__ == '__main__':
    app.run(debug=True, port=5000)
