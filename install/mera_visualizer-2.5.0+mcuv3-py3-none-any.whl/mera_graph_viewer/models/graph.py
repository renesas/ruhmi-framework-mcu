"""Data models for graph structures."""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional


@dataclass
class Node:
    """Graph node representation."""
    id: str
    label: str
    device_type: Optional[str] = None
    properties: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            'id': self.id,
            'label': self.label,
            'device_type': self.device_type,
            **self.properties
        }


@dataclass
class Edge:
    """Graph edge representation."""
    source: str
    target: str
    label: Optional[str] = None
    properties: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        result = {
            'source': self.source,
            'target': self.target,
        }
        if self.label:
            result['label'] = self.label
        result.update(self.properties)
        return result


@dataclass
class Graph:
    """Complete graph structure."""
    nodes: List[Node]
    edges: List[Edge]
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            'nodes': [n.to_dict() for n in self.nodes],
            'edges': [e.to_dict() for e in self.edges],
            **self.metadata
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Graph':
        """Create Graph from dictionary."""
        nodes = [
            Node(
                id=n['id'],
                label=n.get('label', ''),
                device_type=n.get('device_type'),
                properties={k: v for k, v in n.items()
                           if k not in ['id', 'label', 'device_type']}
            )
            for n in data.get('nodes', [])
        ]

        edges = [
            Edge(
                source=e['source'],
                target=e['target'],
                label=e.get('label'),
                properties={k: v for k, v in e.items()
                           if k not in ['source', 'target', 'label']}
            )
            for e in data.get('edges', [])
        ]

        metadata = {k: v for k, v in data.items()
                   if k not in ['nodes', 'edges']}

        return cls(nodes=nodes, edges=edges, metadata=metadata)
