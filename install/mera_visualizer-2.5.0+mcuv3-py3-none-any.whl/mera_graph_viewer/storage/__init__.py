"""Storage layer for graph persistence."""

from .graph_store import GraphStore

__all__ = ['GraphStore']
