"""SQLite-based graph storage with LRU eviction and compression."""

import sqlite3
import json
import gzip
import hashlib
import logging
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, Any
from contextlib import contextmanager

logger = logging.getLogger(__name__)


class GraphStore:
    """SQLite-backed storage for graph data with LRU eviction and compression."""

    # Size limits
    DEFAULT_MAX_GRAPHS = 1000
    DEFAULT_MAX_SIZE_MB = 5000  # 5GB safety limit
    COMPRESSION_THRESHOLD = 500_000  # Compress if data > 500KB

    def __init__(self, db_path: str = "mera_graphs.db",
                 max_graphs: int = DEFAULT_MAX_GRAPHS,
                 max_size_mb: float = DEFAULT_MAX_SIZE_MB):
        """
        Initialize graph store.

        Args:
            db_path: Path to SQLite database file
            max_graphs: Maximum number of graphs to keep (LRU eviction)
            max_size_mb: Maximum total database size in MB (safety limit)
        """
        self.db_path = Path(db_path)
        self.max_graphs = max_graphs
        self.max_size_mb = max_size_mb
        self.max_size_bytes = int(max_size_mb * 1024 * 1024)
        self._init_db()

    @contextmanager
    def _get_connection(self):
        """Get database connection with WAL mode for concurrent reads."""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _init_db(self):
        """Initialize database schema with performance optimizations."""
        with self._get_connection() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS graphs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    hash TEXT UNIQUE NOT NULL,
                    data BLOB NOT NULL,
                    is_compressed INTEGER DEFAULT 1,
                    original_size INTEGER NOT NULL,
                    compressed_size INTEGER NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    accessed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    metadata TEXT
                )
            """)

            conn.execute("CREATE INDEX IF NOT EXISTS idx_hash ON graphs(hash)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_created_at ON graphs(created_at DESC)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_accessed_at ON graphs(accessed_at DESC)")

            conn.execute("PRAGMA page_size = 4096")
            conn.execute("PRAGMA cache_size = -64000")
            conn.execute("PRAGMA temp_store = MEMORY")
            conn.execute("PRAGMA mmap_size = 268435456")

        logger.info(f"Database initialized at {self.db_path} (max_size={self.max_size_mb}MB)")

    def _generate_hash(self, data: Dict[Any, Any]) -> str:
        """Generate SHA256 hash from graph data."""
        json_str = json.dumps(data, sort_keys=True)
        return hashlib.sha256(json_str.encode()).hexdigest()

    def _compress_data(self, data: Dict[Any, Any]) -> tuple[bytes, bool, int, int]:
        """
        Compress graph data if it exceeds threshold.

        Args:
            data: Graph data dictionary

        Returns:
            Tuple of (compressed_bytes, is_compressed, original_size, compressed_size)
        """
        json_str = json.dumps(data)
        json_bytes = json_str.encode('utf-8')
        original_size = len(json_bytes)

        compressed = gzip.compress(json_bytes, compresslevel=6)
        compressed_size = len(compressed)

        if original_size > self.COMPRESSION_THRESHOLD:
            ratio = (1 - compressed_size / original_size) * 100
            logger.debug(f"Compressed {original_size} → {compressed_size} bytes ({ratio:.1f}% reduction)")

        return compressed, True, original_size, compressed_size

    def _decompress_data(self, compressed_bytes: bytes, is_compressed: bool) -> Dict[Any, Any]:
        """
        Decompress graph data.

        Args:
            compressed_bytes: Compressed or raw data bytes
            is_compressed: Whether data is compressed

        Returns:
            Decompressed graph data dictionary
        """
        if is_compressed:
            json_bytes = gzip.decompress(compressed_bytes)
        else:
            json_bytes = compressed_bytes

        return json.loads(json_bytes.decode('utf-8'))

    def _calculate_filesize(self, data: Dict[Any, Any]) -> int:
        """Calculate size of data in bytes."""
        return len(json.dumps(data).encode('utf-8'))

    def save_graph(self, graph_data: Dict[Any, Any]) -> str:
        """
        Save graph data with compression and return its hash.
        If graph already exists (same hash), returns existing hash.

        Args:
            graph_data: Graph data dictionary

        Returns:
            SHA256 hash of the graph

        Raises:
            Exception: If save fails or size limit exceeded
        """
        graph_hash = self._generate_hash(graph_data)
        compressed_data, is_compressed, original_size, compressed_size = self._compress_data(graph_data)

        with self._get_connection() as conn:
            existing = conn.execute(
                "SELECT hash FROM graphs WHERE hash = ?",
                (graph_hash,)
            ).fetchone()

            if existing:
                conn.execute(
                    "UPDATE graphs SET accessed_at = CURRENT_TIMESTAMP WHERE hash = ?",
                    (graph_hash,)
                )
                logger.info(f"Graph {graph_hash[:8]}... already exists, updated access time")
                return graph_hash

            current_stats = self._get_size_stats(conn)
            projected_size = current_stats['total_compressed_size'] + compressed_size

            if projected_size > self.max_size_bytes:
                self._cleanup_old_graphs(conn)

                current_stats = self._get_size_stats(conn)
                projected_size = current_stats['total_compressed_size'] + compressed_size

                if projected_size > self.max_size_bytes:
                    size_mb = projected_size / (1024 * 1024)
                    raise Exception(
                        f"Storage limit exceeded: {size_mb:.1f}MB would exceed {self.max_size_mb}MB limit. "
                        f"Please delete old graphs or increase limit."
                    )

            conn.execute(
                """
                INSERT INTO graphs (hash, data, is_compressed, original_size, compressed_size, metadata)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    graph_hash,
                    compressed_data,
                    1 if is_compressed else 0,
                    original_size,
                    compressed_size,
                    json.dumps({
                        'node_count': len(graph_data.get('nodes', [])),
                        'edge_count': len(graph_data.get('edges', []))
                    })
                )
            )

            compression_ratio = (1 - compressed_size / original_size) * 100 if original_size > 0 else 0
            compression_info = f"compressed {original_size} → {compressed_size} bytes ({compression_ratio:.1f}%)" if is_compressed else f"{original_size} bytes"
            logger.info(f"Saved graph {graph_hash[:8]}... ({compression_info})")

            self._cleanup_old_graphs(conn)

            return graph_hash

    def get_graph(self, graph_hash: str) -> Optional[Dict[Any, Any]]:
        """
        Retrieve graph data by hash with automatic decompression.
        Updates accessed_at timestamp.

        Args:
            graph_hash: SHA256 hash of the graph

        Returns:
            Graph data dictionary or None if not found
        """
        with self._get_connection() as conn:
            row = conn.execute(
                "SELECT data, is_compressed FROM graphs WHERE hash = ?",
                (graph_hash,)
            ).fetchone()

            if row:
                conn.execute(
                    "UPDATE graphs SET accessed_at = CURRENT_TIMESTAMP WHERE hash = ?",
                    (graph_hash,)
                )
                logger.info(f"Retrieved graph {graph_hash[:8]}...")
                return self._decompress_data(row['data'], bool(row['is_compressed']))

            logger.warning(f"Graph {graph_hash[:8]}... not found")
            return None

    def get_metadata(self, graph_hash: str) -> Optional[Dict[str, Any]]:
        """Get graph metadata without full data."""
        with self._get_connection() as conn:
            row = conn.execute(
                """
                SELECT hash, original_size, compressed_size, is_compressed,
                       created_at, accessed_at, metadata
                FROM graphs WHERE hash = ?
                """,
                (graph_hash,)
            ).fetchone()

            if row:
                meta = json.loads(row['metadata']) if row['metadata'] else {}
                compression_ratio = (1 - row['compressed_size'] / row['original_size']) * 100 if row['original_size'] > 0 else 0
                return {
                    'hash': row['hash'],
                    'original_size': row['original_size'],
                    'compressed_size': row['compressed_size'],
                    'is_compressed': bool(row['is_compressed']),
                    'compression_ratio_percent': round(compression_ratio, 1),
                    'created_at': row['created_at'],
                    'accessed_at': row['accessed_at'],
                    **meta
                }
            return None

    def delete_graph(self, graph_hash: str) -> bool:
        """Delete a graph by hash."""
        with self._get_connection() as conn:
            cursor = conn.execute("DELETE FROM graphs WHERE hash = ?", (graph_hash,))
            deleted = cursor.rowcount > 0
            if deleted:
                logger.info(f"Deleted graph {graph_hash[:8]}...")
            return deleted

    def _get_size_stats(self, conn: sqlite3.Connection) -> Dict[str, int]:
        """Get current size statistics."""
        row = conn.execute("""
            SELECT
                COUNT(*) as count,
                COALESCE(SUM(compressed_size), 0) as total_compressed,
                COALESCE(SUM(original_size), 0) as total_original
            FROM graphs
        """).fetchone()

        return {
            'count': row['count'],
            'total_compressed_size': row['total_compressed'],
            'total_original_size': row['total_original']
        }

    def _cleanup_old_graphs(self, conn: sqlite3.Connection):
        """
        Keep only the last max_graphs by insertion order.
        Called automatically after each save.
        """
        size_stats = self._get_size_stats(conn)
        count = size_stats['count']
        total_size = size_stats['total_compressed_size']

        to_delete_by_count = max(0, count - self.max_graphs)

        to_delete_by_size = 0
        if total_size > self.max_size_bytes:
            to_delete_by_size = max(10, count // 10)

        to_delete = max(to_delete_by_count, to_delete_by_size)

        if to_delete > 0:
            conn.execute("""
                DELETE FROM graphs
                WHERE id IN (
                    SELECT id FROM graphs
                    ORDER BY id ASC
                    LIMIT ?
                )
            """, (to_delete,))

            reason = []
            if to_delete_by_count > 0:
                reason.append(f"count limit ({self.max_graphs})")
            if to_delete_by_size > 0:
                size_mb = total_size / (1024 * 1024)
                reason.append(f"size limit ({size_mb:.1f}MB / {self.max_size_mb}MB)")

            logger.info(f"Cleaned up {to_delete} old graphs due to {' and '.join(reason)}")

    def get_stats(self) -> Dict[str, Any]:
        """Get storage statistics including compression info."""
        with self._get_connection() as conn:
            stats = conn.execute("""
                SELECT
                    COUNT(*) as total_graphs,
                    COALESCE(SUM(compressed_size), 0) as total_compressed,
                    COALESCE(SUM(original_size), 0) as total_original,
                    COALESCE(AVG(compressed_size), 0) as avg_compressed,
                    COALESCE(AVG(original_size), 0) as avg_original,
                    MIN(created_at) as oldest,
                    MAX(created_at) as newest
                FROM graphs
            """).fetchone()

            total_compressed = stats['total_compressed']
            total_original = stats['total_original']

            compression_ratio = 0
            if total_original > 0:
                compression_ratio = (1 - total_compressed / total_original) * 100

            storage_used_mb = total_compressed / (1024 * 1024)
            storage_utilization_percent = (total_compressed / self.max_size_bytes) * 100

            return {
                'total_graphs': stats['total_graphs'],
                'total_size_bytes': total_compressed,
                'total_size_mb': round(storage_used_mb, 2),
                'original_size_bytes': total_original,
                'original_size_mb': round(total_original / (1024 * 1024), 2),
                'compression_ratio_percent': round(compression_ratio, 1),
                'space_saved_mb': round((total_original - total_compressed) / (1024 * 1024), 2),
                'avg_compressed_bytes': int(stats['avg_compressed']),
                'avg_original_bytes': int(stats['avg_original']),
                'oldest_graph': stats['oldest'],
                'newest_graph': stats['newest'],
                'max_capacity_graphs': self.max_graphs,
                'max_capacity_mb': self.max_size_mb,
                'storage_utilization_percent': round(storage_utilization_percent, 1)
            }
