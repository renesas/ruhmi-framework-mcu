"""Graph parsing and validation."""

import json
import logging
from typing import Dict, Any, Optional, Tuple

logger = logging.getLogger(__name__)


def parse_json_file(file_content: str) -> Optional[Dict[str, Any]]:
    """
    Parse JSON content from uploaded file.

    Args:
        file_content: String content of JSON file

    Returns:
        Parsed JSON dict or None if invalid
    """
    try:
        data = json.loads(file_content)
        return data
    except json.JSONDecodeError as e:
        logger.error(f"JSON parsing error: {e}")
        return None


def validate_graph_structure(data: Dict[str, Any]) -> Tuple[bool, Optional[str]]:
    """
    Validate JSON has required graph structure.

    Args:
        data: Parsed JSON dictionary

    Returns:
        Tuple of (is_valid, error_message)
    """
    if not isinstance(data, dict):
        return False, "Data must be a JSON object"

    if 'subgraphs' in data:
        # Validate MERA format
        if not isinstance(data['subgraphs'], list):
            return False, "'subgraphs' must be an array"

        if len(data['subgraphs']) == 0:
            return False, "At least one subgraph is required"

        for idx, subgraph in enumerate(data['subgraphs']):
            if not isinstance(subgraph, dict):
                return False, f"Subgraph {idx} must be an object"

            if 'nodes' not in subgraph:
                return False, f"Subgraph {idx} missing 'nodes' field"

            if not isinstance(subgraph['nodes'], list):
                return False, f"Subgraph {idx} 'nodes' must be an array"

        return True, None

    elif 'nodes' in data and 'edges' in data:
        if not isinstance(data['nodes'], list):
            return False, "'nodes' must be an array"

        if not isinstance(data['edges'], list):
            return False, "'edges' must be an array"

        if len(data['nodes']) == 0:
            return False, "At least one node is required"

        for idx, node in enumerate(data['nodes']):
            if not isinstance(node, dict):
                return False, f"Node {idx} must be an object"

            if 'id' not in node:
                return False, f"Node {idx} missing 'id' field"

        for idx, edge in enumerate(data['edges']):
            if not isinstance(edge, dict):
                return False, f"Edge {idx} must be an object"

            if 'source' not in edge or 'target' not in edge:
                return False, f"Edge {idx} must have 'source' and 'target' fields"

        return True, None

    else:
        return False, "Graph must have either 'subgraphs' array or 'nodes'/'edges' arrays"


def extract_graph_metadata(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Extract metadata from graph data.

    Args:
        data: Parsed graph data

    Returns:
        Metadata dictionary with counts and statistics
    """
    metadata = {
        'format': 'unknown',
        'node_count': 0,
        'edge_count': 0,
        'subgraph_count': 0
    }

    if 'subgraphs' in data:
        metadata['format'] = 'mera'
        metadata['subgraph_count'] = len(data['subgraphs'])

        # Count total nodes across all subgraphs
        for subgraph in data['subgraphs']:
            metadata['node_count'] += len(subgraph.get('nodes', []))

    elif 'nodes' in data and 'edges' in data:
        metadata['format'] = 'simple'
        metadata['node_count'] = len(data.get('nodes', []))
        metadata['edge_count'] = len(data.get('edges', []))

    return metadata
