"""Graph processing and transformation logic."""

import logging
from typing import Dict, Any, Optional
from ..storage.graph_store import GraphStore
from .parser import parse_json_file, validate_graph_structure, extract_graph_metadata

logger = logging.getLogger(__name__)


class GraphProcessor:
    """Handles graph upload, validation, and storage."""

    def __init__(self, storage: GraphStore):
        """
        Initialize processor with storage backend.

        Args:
            storage: GraphStore instance for persistence
        """
        self.storage = storage

    def process_upload(self, file_content: str, max_size_mb: int = 15) -> Dict[str, Any]:
        """
        Process uploaded graph file.

        Args:
            file_content: Raw file content as string
            max_size_mb: Maximum allowed file size in MB

        Returns:
            Result dictionary with status, hash, error, etc.
        """
        # Check file size
        file_size_mb = len(file_content.encode('utf-8')) / (1024 * 1024)
        if file_size_mb > max_size_mb:
            return {
                'success': False,
                'error': f'File too large: {file_size_mb:.2f} MB (max {max_size_mb} MB)'
            }

        # Parse JSON
        data = parse_json_file(file_content)
        if data is None:
            return {
                'success': False,
                'error': 'Invalid JSON format'
            }

        # Validate structure
        is_valid, error_msg = validate_graph_structure(data)
        if not is_valid:
            return {
                'success': False,
                'error': f'Invalid graph structure: {error_msg}'
            }

        # Extract metadata
        metadata = extract_graph_metadata(data)

        # Save to storage
        try:
            graph_hash = self.storage.save_graph(data)
            logger.info(f"Processed graph: hash={graph_hash[:8]}..., nodes={metadata['node_count']}")

            return {
                'success': True,
                'hash': graph_hash,
                'metadata': metadata
            }
        except Exception as e:
            logger.error(f"Storage error: {e}")
            return {
                'success': False,
                'error': f'Failed to save graph: {str(e)}'
            }

    def get_graph_data(self, graph_hash: str) -> Optional[Dict[str, Any]]:
        """
        Retrieve graph data by hash.

        Args:
            graph_hash: SHA256 hash of the graph

        Returns:
            Graph data dictionary or None if not found
        """
        return self.storage.get_graph(graph_hash)
