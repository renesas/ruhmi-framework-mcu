from argparse import ArgumentParser
from pathlib import Path
from collections import defaultdict, namedtuple
import json
import networkx as nx
from copy import deepcopy
from pprint import pprint
import math
from statistics import median
from typing import List, Dict, Any

import numpy as np
import matplotlib.pyplot as plt

# Author: Uzzal Podder
# JSON graph reader and processor for MERA Model analysis

# Processing version - increment this when making changes that affect output
# This ensures cached graphs are invalidated when processing logic changes
PROCESSING_VERSION = "2.0.0"  # Added initializer memory aggregation


def get_dtype_size_bytes(dtype_str: str) -> int:
    """Get size in bytes for a given data type string."""
    dtype_map = {
        "Float32": 4,
        "Float16": 2,
        "BFloat16": 2,
        "Float64": 8,
        "Int8": 1,
        "UInt8": 1,
        "Int16": 2,
        "UInt16": 2,
        "Int32": 4,
        "UInt32": 4,
        "Int64": 8,
        "UInt64": 8,
        "Bool": 1,
    }
    return dtype_map.get(dtype_str, 4)  # default to 4 bytes if unknown


def construct_subgraphs(data):
    # Create graphs from the json data
    subgraph_holder = {}
    for subgraph in data["subgraphs"]:
        G = nx.DiGraph()
        # first insert nodes
        for node in subgraph["nodes"]:
            node_uid = node["output"]["name"]
            # First gather the details of incoming node (input or constant)
            input_connections = {}
            input_shapes = {}
            for input_name, input_info in node["input_names"].items():
                input_id = input_info["name"]
                input_connections[input_id] = {
                    "dtype": input_info["dt"],
                    "layout": input_info["layout"],
                    "shape": input_info["shape"],
                    "tensor_type": input_name,
                }
                input_shapes[input_name] = input_info.get("shape", [])

            # Compute metrics from available data
            output_shape = node["output"]["shape"]
            output_dtype = node["output"]["dt"]
            node_attrs = node.get("attributes", {})

            # Build base attributes
            node_attributes = {
                "dtype": output_dtype,
                "layout": node["output"]["layout"],
                "shape": output_shape,
                "node_attributes": node_attrs,  # Store original node attributes
            }

            # Only add computational metrics if they exist in node_data from source JSON
            if "node_data" in node:
                if "mac_count" in node["node_data"]:
                    node_attributes["mac_count"] = node["node_data"]["mac_count"]
                if "mem_parameter_bytes" in node["node_data"]:
                    node_attributes["mem_parameter_bytes"] = node["node_data"][
                        "mem_parameter_bytes"
                    ]
                if "mem_tensor_bytes" in node["node_data"]:
                    node_attributes["mem_tensor_bytes"] = node["node_data"]["mem_tensor_bytes"]

            G.add_node(
                node_uid,
                node_local_id=node["output"]["name"],
                op_name=node["op_name"],
                label=node["op_name"],
                attributes=node_attributes,
                device=subgraph["target_name"],
                subgraph_name=subgraph["subgraph_name"],
                input_connections=input_connections,
                tensor_type=None,  # will be updated later. value could be x, w, b
                style_info={},  # will be updated later
            )
        # then create connections
        for node in subgraph["nodes"]:
            curr_node_local_uid = node["output"]["name"]
            for tensor_type, input_node_info in node["input_names"].items():
                input_node_local_id = input_node_info["name"]
                G.nodes[input_node_local_id]["tensor_type"] = tensor_type
                G.add_edge(input_node_local_id, curr_node_local_uid)
        subgraph_holder[subgraph["subgraph_name"]] = G
        # save_graph(
        #     G,
        #     graph_name=subgraph["subgraph_name"] + "--" + subgraph["target_name"],
        # )
    print(f"Found {len(subgraph_holder)} subgraph")

    return subgraph_holder


def find_subgraph_joints(subgraphs):
    input_nodes = []
    output_nodes = []
    joints = []
    NodeInfo = namedtuple("NodeInfo", ["node_id", "node_data", "to_be_delete_node_data"])
    Edge = namedtuple("Edge", ["u_of_edge", "v_of_edge"])
    to_be_removed_nodes = []
    # first find all the input and output terminal nodes
    for subgraph_name, subgraph in subgraphs.items():
        for node_id, node_data in subgraph.nodes(data=True):
            predecessors = list(subgraph.predecessors(node_id))
            successors = list(subgraph.successors(node_id))
            # if there is no parent node for u, then it is an input node
            if len(predecessors) == 0:
                in_node_info = NodeInfo(node_id, node_data, None)
                # if it is an intermediate input, we can directly connect to actual ops node
                if len(successors) == 1:
                    next_node = subgraph.nodes(data=True)[successors[0]]
                    in_node_info = NodeInfo(node_id, next_node, node_data)
                input_nodes.append(in_node_info)

            # if there is no child for v, then it is an output node
            if len(successors) == 0:
                # the output node  itself is not useful
                # we need all the nodes that are connected to current output node
                for parent_node_id in predecessors:
                    parent_node_data = subgraph.nodes(data=True)[parent_node_id]
                    out_node_info = NodeInfo(parent_node_id, parent_node_data, node_data)
                    output_nodes.append(out_node_info)

    # not all empty parents nodes are connected to previous output nodes.
    # for example, FloatVecConstant or Int32VecConstant. So skip them
    # a node can be considered as sub-graph input node if is is mentioned as output in some other output node
    # if match found between two terminal, keep the pair to make new edge connection later
    output_set = set([x[0] for x in output_nodes])
    for input_node_id, input_node_data, inp_to_del_node in input_nodes:
        if input_node_id in output_set:
            # TODO: Use hashing instead of list traversing to make the matching faster
            for output_node_id, output_node_data, out_to_del_node in output_nodes:
                if input_node_id == output_node_id:
                    u = make_global_uid(
                        output_node_data["subgraph_name"],
                        output_node_data["node_local_id"],
                    )
                    v = make_global_uid(
                        input_node_data["subgraph_name"],
                        input_node_data["node_local_id"],
                    )
                    # print(f"Connecting u: {u} ---> v: {v}")
                    joints.append(
                        Edge(
                            u_of_edge=(u, output_node_data),
                            v_of_edge=(v, input_node_data),
                        )
                    )

                    to_be_removed_nodes.append(
                        {"u_terminal": out_to_del_node, "v_terminal": inp_to_del_node}
                    )
    return joints, to_be_removed_nodes


def combine_subgraphs(subgraphs, joints):
    final_graph = nx.DiGraph()
    for subgraph_name, subgraph in subgraphs.items():
        print(f"Combining {subgraph_name} to final graph ...")
        # first add nodes
        for node_name, node_data in subgraph.nodes(data=True):
            uid = make_global_uid(subgraph_name, node_name)
            attrs = deepcopy(node_data)
            final_graph.add_node(uid, **attrs)
        # then add edges
        for u, v in subgraph.edges(data=False):
            u_uid = make_global_uid(subgraph_name, u)
            v_uid = make_global_uid(subgraph_name, v)
            # make sure newly created node name for edge also exists in final graph
            assert u_uid in final_graph.nodes, f"Node {u_uid} not found in final graph."
            assert v_uid in final_graph.nodes, f"Node {v_uid} not found in final graph."
            data = populate_edge_info(u_uid, v_uid, final_graph)
            final_graph.add_edge(u_uid, v_uid, **data)
    # at this stage all the subgraphs are still disjoint
    # now add connections between disjoint subgraphs
    for joint in joints:
        # u_id, u_data = joint["u_of_edge"]
        # v_id, v_data = joint["v_of_edge"]
        # u_uid = make_global_uid(u_data["subgraph_name"], u_id)
        # v_uid = make_global_uid(v_data["subgraph_name"], v_id)
        u_uid, u_data = joint.u_of_edge
        v_uid, v_data = joint.v_of_edge
        # print(f"Connecting {u_uid} ---> {v_uid}")
        final_graph.add_edge(u_uid, v_uid)

    # remove_unwanted_nodes(final_graph, need_to_remove)

    print(
        f"Final graph has {final_graph.number_of_nodes()} nodes and {final_graph.number_of_edges()} edges."
    )
    # Check if the final graph is connected
    weakly_connected = list(nx.weakly_connected_components(final_graph))
    if len(weakly_connected) > 1:
        print(f"WARNING: Found {len(weakly_connected)} disjoint sets.")

    return final_graph


def remove_subgraph_terminal_nodes(final_graph, need_to_remove):
    u_terminal_nodes = defaultdict(list)
    v_terminal_nodes = defaultdict(list)
    for item in need_to_remove:
        u_n = item["u_terminal"]
        v_n = item["v_terminal"]
        if u_n is not None:
            u_uid = make_global_uid(u_n["subgraph_name"], u_n["node_local_id"])
            u_terminal_nodes[u_uid].append(u_n)
        if v_n is not None:
            v_uid = make_global_uid(v_n["subgraph_name"], v_n["node_local_id"])
            v_terminal_nodes[v_uid].append(v_n)

    selected_for_removal = []
    for u, v in final_graph.edges():
        # here u_terminal_nodes means GraphOutputs points. So we need to search v inside it
        if v in u_terminal_nodes and v in final_graph.nodes:
            selected_for_removal.append(v)
        # here v_terminal_nodes means input points. So we need to search u inside it
        if u in v_terminal_nodes and u in final_graph.nodes:
            selected_for_removal.append(u)
    for node_id in selected_for_removal:
        if node_id in final_graph.nodes:
            final_graph.remove_node(node_id)
            print(f"Removing node {node_id}")

    # also removed single isolated node
    # find nodes that have no successors and predecessors
    nodes_to_remove = []
    for node in final_graph.nodes:
        pred = list(final_graph.predecessors(node))
        succ = list(final_graph.successors(node))
        if len(pred) == 0 and len(succ) == 0:
            nodes_to_remove.append(node)
    final_graph.remove_nodes_from(nodes_to_remove)

    return final_graph


def get_graph_from_json(data):
    all_subgraph = construct_subgraphs(data)

    # joints, need_to_remove = find_graph_joint_points(all_subgraph)
    joints, need_to_remove = find_subgraph_joints(all_subgraph)
    # joints, need_to_remove  = find_graph_joint_points_v2(all_subgraph)

    final_graph = combine_subgraphs(all_subgraph, joints)
    final_graph = remove_subgraph_terminal_nodes(final_graph, need_to_remove)
    update_nodes_label(final_graph)
    # topological_sorted_json(final_graph)
    populate_style_info(final_graph)
    return final_graph


def log_scale_radii(values, base_radius=10.0, offset=1.0, min_radius=2):

    if not values:
        return []

    # find the “reference” (median of non-zero); if there are no non-zeros, fall back to overall median
    nonzeros = [v for v in values if v > 0]
    if nonzeros:
        ref_val = median(nonzeros)
    else:
        ref_val = median(values)

    ref_log = math.log(ref_val + offset)

    radii = []
    for v in values:
        if ref_log == 0:
            scaled = base_radius
        else:
            scaled = base_radius * (math.log(v + offset) / ref_log)

        if min_radius is not None:
            scaled = max(scaled, min_radius)

        radii.append(scaled)

    return radii


def heatmap_log_median_ratio(
    values: np.ndarray,
    offset: float = 1.0,
):
    arr = np.array(values).astype(float).ravel()
    nz = arr[arr > 0]
    ref = np.median(nz) if nz.size > 0 else np.median(arr)
    log_v = np.log(arr + offset)
    log_ref = np.log(ref + offset)
    if log_ref == 0 or np.isnan(log_ref):
        intensity_ratio = np.ones_like(log_v)
    else:
        intensity_ratio = log_v / log_ref

    return intensity_ratio


def map_to_log_range(values, target_range=[1.0, 10.0], offset=1.0):
    """Map values to target range using logarithmic scale."""
    if not values:
        return []

    t_min, t_max = target_range
    if t_max < t_min:
        raise ValueError("target_range must be (min, max) with min ≤ max.")

    has_zero = any(v == 0 for v in values)
    if has_zero and offset <= 0:
        raise ValueError("Since values contain zero, offset must be > 0 to avoid log(0).")

    v_min = 0.0 if has_zero else min(values)
    v_max = max(values)

    log_min = math.log(v_min + offset) if v_min + offset > 0 else float("-inf")
    log_max = math.log(v_max + offset) if v_max + offset > 0 else float("-inf")

    if math.isclose(log_max, log_min):
        mid = 0.5 * (t_min + t_max)
        return [mid for _ in values]

    scaled = []
    for v in values:
        log_v = math.log(v + offset)
        frac = (log_v - log_min) / (log_max - log_min)
        mapped = t_min + frac * (t_max - t_min)
        scaled.append(mapped)

    return scaled


def map_to_log_bins_and_contributions(
    values: List[float], num_bins: int = 100, offset: float = 1.0
):
    """
    Map a list of non-negative numbers into non-linear (logarithmic) bins and compute
    each item’s contribution (value / total_sum), using NumPy for vectorized operations.
    Zeros in `values` are handled via `offset > 0`.

    Args:
        values: List of input values (each ≥ 0). May contain zeros.
        num_bins: Number of discrete bins (default 100). Output bins run from 1..num_bins.
        offset: Small positive constant added to each value before taking log.
                If any value == 0, offset must be > 0 to avoid log(0). Default = 1.0.

    Returns:
        - binned: A list of integers (each in [1, num_bins]) giving the bin index for each input.
            * Values with the same log-scaled position land in the same bin.
            * If all values are identical (after offset), every element is assigned bin 1.
        - contributions: A list of floats where each entry is `v / total_sum`.
            * If total_sum == 0 (all values are 0), all contributions will be 0.0.
    """
    if not values:
        return [], []

    arr = np.array(values, dtype=float)

    total_sum = arr.sum()
    if total_sum > 0:
        tmp_arr = arr
        contributions = (tmp_arr - min(tmp_arr)) / (max(tmp_arr) - min(tmp_arr))
    else:
        contributions = [0.0] * len(values)

    if np.any(arr == 0) and offset <= 0:
        raise ValueError("Since values contain zero, offset must be > 0 to avoid log(0).")

    log_vals = np.log(arr + offset)

    log_min = float(log_vals.min())
    log_max = float(log_vals.max())

    if np.isclose(log_min, log_max):
        binned = [1] * len(values)
        return binned, contributions

    frac = (log_vals - log_min) / (log_max - log_min)

    zero_based = np.floor(frac * num_bins).astype(int)

    zero_based = np.clip(zero_based, 0, num_bins - 1)

    binned = zero_based + 1
    thickness = np.maximum(binned / 10.0, 5.0)
    return thickness, contributions


def is_initializer_node(op_name: str) -> bool:
    """Check if a node is an initializer/constant node based on its op_name."""
    if not op_name:
        return False
    # These patterns match nodes that contain weights, biases, and other constant values
    initializer_patterns = ["VecConstant", "FileBackedConstant", "Constant"]
    for pattern in initializer_patterns:
        if op_name.endswith(pattern) or op_name == pattern:
            return True
    return False


def populate_style_info(graph):
    """
    Populate style information for graph nodes including heatmap values.

    For memory metrics (mem_parameter_bytes, mem_tensor_bytes), this function
    aggregates values from initializer nodes (constants, weights, biases) to their
    consumer nodes. This ensures operational nodes display the total memory
    including their connected initializers, while initializer nodes themselves
    are filtered from display.
    """
    # First pass: identify initializer nodes and build predecessor mapping
    initializer_nodes = set()
    for node_id, node_data in graph.nodes(data=True):
        op_name = node_data.get("op_name", "")
        if is_initializer_node(op_name):
            initializer_nodes.add(node_id)

    # Second pass: for each non-initializer node, aggregate memory from predecessor initializers
    aggregated_mem_params = {}  # node_id -> aggregated mem_parameter_bytes
    aggregated_mem_tensor = {}  # node_id -> aggregated mem_tensor_bytes

    for node_id, node_data in graph.nodes(data=True):
        if node_id in initializer_nodes:
            # Skip initializer nodes - they will contribute to their consumers
            continue

        attributes = node_data.get("attributes", {})

        # Start with the node's own memory values
        own_mem_params = attributes.get("mem_parameter_bytes", 0)
        own_mem_tensor = attributes.get("mem_tensor_bytes", 0)

        # Add memory from all predecessor initializer nodes
        for pred_id in graph.predecessors(node_id):
            if pred_id in initializer_nodes:
                pred_data = graph.nodes[pred_id]
                pred_attrs = pred_data.get("attributes", {})
                own_mem_params += pred_attrs.get("mem_parameter_bytes", 0)
                own_mem_tensor += pred_attrs.get("mem_tensor_bytes", 0)

        aggregated_mem_params[node_id] = own_mem_params
        aggregated_mem_tensor[node_id] = own_mem_tensor

    # Build lists for styling calculations (only non-initializer nodes)
    mac_count_list = []
    mem_parameter_bytes_list = []
    mem_tensor_bytes_list = []
    node_id_list = []

    # Check if any node has these metrics
    has_mac_count = any(
        "mac_count" in node_data.get("attributes", {}) for _, node_data in graph.nodes(data=True)
    )
    has_mem_params = any(
        "mem_parameter_bytes" in node_data.get("attributes", {})
        for _, node_data in graph.nodes(data=True)
    )
    has_mem_tensor = any(
        "mem_tensor_bytes" in node_data.get("attributes", {})
        for _, node_data in graph.nodes(data=True)
    )

    for node_id, node_data in graph.nodes(data=True):
        attributes = node_data.get("attributes", {})

        # Get MAC count (not aggregated - only operational nodes have MACs)
        mac_count = attributes.get("mac_count", 0) if has_mac_count else 0

        # For memory values, use aggregated values for non-initializer nodes
        if node_id in initializer_nodes:
            # Initializer nodes keep their own values (for edge styling etc.)
            mem_parameter_bytes = attributes.get("mem_parameter_bytes", 0) if has_mem_params else 0
            mem_tensor_bytes = attributes.get("mem_tensor_bytes", 0) if has_mem_tensor else 0
        else:
            # Operational nodes use aggregated values (own + initializer predecessors)
            mem_parameter_bytes = aggregated_mem_params.get(node_id, 0) if has_mem_params else 0
            mem_tensor_bytes = aggregated_mem_tensor.get(node_id, 0) if has_mem_tensor else 0

        mac_count_list.append(mac_count)
        mem_parameter_bytes_list.append(mem_parameter_bytes)
        mem_tensor_bytes_list.append(mem_tensor_bytes)
        node_id_list.append(node_id)

        # Store aggregated values in attributes for frontend access
        if node_id not in initializer_nodes:
            graph.nodes[node_id]["attributes"]["aggregated_mem_params"] = mem_parameter_bytes
            graph.nodes[node_id]["attributes"]["aggregated_mem_tensor"] = mem_tensor_bytes

    radius_list = log_scale_radii(mem_parameter_bytes_list)
    colors_intensity_list = heatmap_log_median_ratio(mac_count_list)
    edge_thickness_list, edge_contrib_list = map_to_log_bins_and_contributions(
        mem_tensor_bytes_list
    )

    # Compute normalized heatmap values (0-1 range) for visualization
    # Use only visible (non-initializer) nodes for normalization
    def normalize_for_heatmap(values, node_ids, visible_node_ids):
        """Normalize values to 0-1 range for heatmap coloring.

        Only considers visible nodes for min/max calculation, ensuring
        the heatmap scale reflects what the user actually sees.
        """
        if not values:
            return []

        # Get values only from visible nodes for min/max calculation
        visible_values = [v for v, nid in zip(values, node_ids) if nid in visible_node_ids]

        if not visible_values:
            return [0.5] * len(values)

        arr = np.array(values, dtype=float)
        visible_arr = np.array(visible_values, dtype=float)
        min_val = float(visible_arr.min())
        max_val = float(visible_arr.max())

        if np.isclose(min_val, max_val):
            # All values are the same, return 0.5 for all
            return [0.5] * len(values)

        # Normalize all values using visible min/max, but clip to [0, 1]
        normalized = np.clip((arr - min_val) / (max_val - min_val), 0.0, 1.0)
        return normalized.tolist()

    # Set of visible (non-initializer) node IDs
    visible_node_ids = set(node_id_list) - initializer_nodes

    mac_heatmap = (
        normalize_for_heatmap(mac_count_list, node_id_list, visible_node_ids)
        if has_mac_count
        else []
    )
    mem_params_heatmap = (
        normalize_for_heatmap(mem_parameter_bytes_list, node_id_list, visible_node_ids)
        if has_mem_params
        else []
    )
    mem_tensor_heatmap = (
        normalize_for_heatmap(mem_tensor_bytes_list, node_id_list, visible_node_ids)
        if has_mem_tensor
        else []
    )

    for idx, (node_id, radius, color_intensity, edge_thickness, edge_contrib) in enumerate(
        zip(
            node_id_list,
            radius_list,
            colors_intensity_list,
            edge_thickness_list,
            edge_contrib_list,
        )
    ):
        graph.nodes[node_id]["style_info"]["radius"] = radius
        graph.nodes[node_id]["style_info"]["color_intensity"] = color_intensity
        graph.nodes[node_id]["style_info"]["edge_thickness"] = edge_thickness
        graph.nodes[node_id]["style_info"]["edge_contrib"] = edge_contrib

        # Add normalized heatmap values for each metric if available
        if mac_heatmap:
            graph.nodes[node_id]["style_info"]["mac_heatmap"] = mac_heatmap[idx]
        if mem_params_heatmap:
            graph.nodes[node_id]["style_info"]["mem_params_heatmap"] = mem_params_heatmap[idx]
        if mem_tensor_heatmap:
            graph.nodes[node_id]["style_info"]["mem_tensor_heatmap"] = mem_tensor_heatmap[idx]

    # Store min/max ranges for legend display (using only visible nodes with aggregated values)
    visible_mac = [v for v, nid in zip(mac_count_list, node_id_list) if nid in visible_node_ids]
    visible_mem_params = [
        v for v, nid in zip(mem_parameter_bytes_list, node_id_list) if nid in visible_node_ids
    ]
    visible_mem_tensor = [
        v for v, nid in zip(mem_tensor_bytes_list, node_id_list) if nid in visible_node_ids
    ]

    if has_mac_count and visible_mac:
        graph.graph["mac_count_range"] = {
            "min": float(min(visible_mac)),
            "max": float(max(visible_mac)),
        }
    if has_mem_params and visible_mem_params:
        graph.graph["mem_params_range"] = {
            "min": float(min(visible_mem_params)),
            "max": float(max(visible_mem_params)),
        }
    if has_mem_tensor and visible_mem_tensor:
        graph.graph["mem_tensor_range"] = {
            "min": float(min(visible_mem_tensor)),
            "max": float(max(visible_mem_tensor)),
        }


def topological_sorted_json(graph):
    # check if the graph has any cycle
    # the find_cycle function will raise an exception if a cycle is found
    try:
        cycle = nx.find_cycle(graph, orientation="original")
    except nx.NetworkXNoCycle:
        cycle = []
    assert len(cycle) == 0, f"Found cycle in the graph: {cycle}"

    topo_order = list(nx.topological_sort(graph))
    ordered_nodes = sorted(graph.nodes(), key=lambda x: topo_order.index(x))

    # Sort edges based on the source node's position
    position = {node: idx for idx, node in enumerate(topo_order)}
    ordered_edges = sorted(graph.edges(), key=lambda edge: position[edge[0]])

    # Add processing version to graph metadata for cache invalidation
    graph_meta = dict(graph.graph)
    graph_meta["processing_version"] = PROCESSING_VERSION

    # Modify the custom_node_link to include attributes
    custom_node_link = {
        "directed": graph.is_directed(),
        "multigraph": graph.is_multigraph(),
        "graph": graph_meta,  # Include graph-level attributes (heatmap ranges + version)
        "nodes": [{"id": node, **graph.nodes[node]} for node in ordered_nodes],
        "links": [
            {
                "source": u,
                "target": v,
                "label": str(
                    # graph.nodes[u]["attributes"]["shape"]
                    make_shape_list_to_string(graph.nodes[u]["attributes"]["shape"])
                ),
                "edge_thickness": graph.nodes[u]["style_info"]["edge_thickness"],
                "edge_contrib": graph.nodes[u]["style_info"]["edge_contrib"],
            }
            for u, v in ordered_edges
        ],
    }
    return custom_node_link


def make_global_uid(subgraph_name, node_local_id):
    return f"{subgraph_name}_{node_local_id}"


def update_nodes_label(graph):
    for node_id, node_data in graph.nodes(data=True):
        op_name = node_data["op_name"]
        label = op_name
        if op_name == "FloatVecConstant" or op_name == "Int32VecConstant":
            label = node_data["tensor_type"]
        elif op_name == "Var":
            label = node_data["tensor_type"]
        elif op_name == "FileBackedConstant" and node_data["tensor_type"] != "":
            label = node_data["tensor_type"]
        graph.nodes[node_id]["label"] = label


def populate_edge_info(u, v, graph):
    viz_obj_shape = "RECTANGLE"
    line_minlen = 10
    line_weight = 5
    relative_position = "top"  # top, bottom, left, right
    tensor_shape = None
    tensor_size = None
    label = ""

    u_node = graph.nodes(data=True)[u]
    v_node = graph.nodes(data=True)[v]
    if u_node["op_name"] == "FloatVecConstant":
        viz_obj_shape = "CIRCLE"
        line_minlen = 1
        line_weight = 10

    if u_node["op_name"] == "Int32VecConstant":
        viz_obj_shape = "CIRCLE"
        line_minlen = 1
        line_weight = 10

    data = {
        "label": label,
        "viz_obj_shape": viz_obj_shape,
        "line_minlen": line_minlen,
        "line_weight": line_weight,
        "relative_position": relative_position,
        "tensor_shape": tensor_shape,
        "tensor_size": tensor_size,
    }
    return data


def is_last_output_node(graph, node_id):
    successors = list(graph.successors(node_id))
    # first make sure it is leaf node
    if len(successors) == 0:
        predecessors = list(graph.predecessors(node_id))
        for pred_node in predecessors:
            pred_successors = list(graph.successors(pred_node))
            if len(pred_successors) > 1:
                return False
    return True


def remove_unwanted_nodes(graph, need_to_remove):
    # remove the nodes
    deleted_set = set()
    for node_id, node_data in need_to_remove:
        uid = make_global_uid(node_data["subgraph_name"], node_id)
        successors = list(graph.successors(uid))
        predecessors = list(graph.predecessors(uid))
        if not is_last_output_node(graph, uid):
            print(f"Removing node {uid}")
            graph.remove_node(uid)
            deleted_set.add(uid)
    # remove the edges

    # Remove var nodes
    edges = list(graph.edges(data=False))
    for u, v in edges:
        v_node = graph.nodes(data=True)[v]
        if v_node["op_name"] == "Var":
            predecessors = list(graph.predecessors(v))
            successors = list(graph.successors(v))
            if len(predecessors) > 0 and len(successors) > 0:
                # connect the predecessor and successor to skip the var node
                for pred in predecessors:
                    for succ in successors:
                        graph.add_edge(pred, succ)
                        print(f"Connecting {pred} ---> {succ}")
                graph.remove_edge(u, v)
                graph.remove_node(v)


# read json file
def read_json(file_path):
    with open(file_path, "r") as file:
        data = json.load(file)
    return data


def save_graph(G, graph_name):
    out_path = Path(__file__).resolve().parent / "dummy_model" / "graph"
    out_path.mkdir(parents=True, exist_ok=True)
    # Save as SVG using Graphviz layout
    nx.nx_agraph.write_dot(G, out_path / f"{graph_name}.dot")  # Save as DOT file
    # nx.drawing.nx_agraph.to_agraph(G).draw(
    #     out_path / f"{graph_name}.svg", prog="dot", format="svg"
    # )

    # Convert to AGraph and apply styling
    A = nx.drawing.nx_agraph.to_agraph(G)
    for node in A.nodes():
        new_label = (
            f"{G.nodes[node]['node_local_id']}"  # bold_code
            + f"\nop_name: {G.nodes[node]['op_name']}"
            + f"\ninputs: {list(G.predecessors(node))}"
            + f"\noutputs: {list(G.successors(node))}"
        )

        node.attr["label"] = new_label
        node.attr["style"] = "filled"
        color = "lightblue"
        if G.nodes[node]["device"] == "CPU":
            color = "salmon"
        elif G.nodes[node]["device"] == "SAKURA-II":
            color = "lightgreen"
        node.attr["fillcolor"] = color

    A.draw(out_path / f"{graph_name}.svg", prog="dot", format="svg")

    print("Graph saved as graph.svg")


def make_shape_list_to_string(shape_list):
    if not shape_list:
        return ""
    if isinstance(shape_list, list) or isinstance(shape_list, tuple):
        # First make each element a string
        shape_list = [str(x) for x in shape_list]
        # Then join them with 'x'. Example: [1, 2, 3] -> "1x3x224x224"
        return "x".join(shape_list)
    elif isinstance(shape_list, str):
        return shape_list
    else:
        raise ValueError(f"Unsupported type for shape_list: {type(shape_list)}")


def get_argument():
    parser = ArgumentParser(description="Process JSON graph data.")
    parser.add_argument(
        "--input",
        type=str,
        default="test_json/model_subgraphs_2.json",
        help="Path to the input JSON file.",
    )
    parser.add_argument("--output", type=str, default=None, help="Path to save the output graph.")
    parser.add_argument("--save_json", action="store_true", help="Flag to save the graph as JSON.")
    return parser.parse_args()


def parse_mera_json(json_data):
    graph = get_graph_from_json(json_data)
    data1 = topological_sorted_json(graph)
    json_graph_data = json.dumps(data1, indent=4)
    return json_graph_data


if __name__ == "__main__":
    args = get_argument()
    json_file_data = read_json(args.input)

    json_graph_data = parse_mera_json(json_file_data)

    if args.save_json:
        out_dir = Path("tmp_json_dir")
        out_dir.mkdir(parents=True, exist_ok=True)
        output_path = out_dir / "graph.json"
        with open(output_path, "w") as f:
            f.write(json_graph_data)
        print(f"Graph saved as JSON to {output_path}")
