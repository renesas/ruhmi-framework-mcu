"""Web routes for HTML UI."""

import json
import os
import logging
from flask import Blueprint, request, jsonify, render_template, current_app, url_for
from ..json_graph_reader import parse_mera_json

logger = logging.getLogger(__name__)

web_bp = Blueprint('web', __name__)


@web_bp.route('/')
def index():
    """Main upload page."""
    return render_template('index.html')


@web_bp.route('/api/v3/upload', methods=['POST'])
def upload_data():
    """
    Legacy upload endpoint (backward compatibility).
    Parse `model_subgraphs.json`, stores it using new storage, and returns a URL to the result.
    """
    try:
        input_json = None
        source = "unknown"

        if 'file' in request.files:
            file = request.files['file']
            if file.filename == '':
                return jsonify({"error": "No file selected"}), 400

            if file and (file.mimetype == 'application/json' or file.filename.lower().endswith('.json')):
                try:
                    content = file.read().decode('utf-8')
                    input_json = json.loads(content)
                    source = f"file: {file.filename}"
                except json.JSONDecodeError as e:
                    logger.error(f"Invalid JSON content in uploaded file '{file.filename}': {e}")
                    return jsonify({"error": "Invalid JSON content in the uploaded file"}), 400
                except Exception as e:
                    logger.error(f"Error reading file '{file.filename}': {str(e)}")
                    return jsonify({"error": f"Error reading file: {str(e)}"}), 500
            else:
                return jsonify({"error": "Invalid file type. Please upload a .json file"}), 400

        elif request.is_json:
            try:
                input_json = request.get_json()
                source = "pasted_json (application/json)"
            except Exception as e:
                logger.error(f"Invalid JSON data pasted (request.is_json was true): {str(e)}")
                return jsonify({"error": "Invalid JSON data pasted"}), 400

        else:
            try:
                raw_data = request.get_data(as_text=True)
                if raw_data:
                    input_json = json.loads(raw_data)
                    source = "pasted_raw_text"
                else:
                    return jsonify({"error": "No data received"}), 400
            except json.JSONDecodeError as e:
                logger.error(f"Invalid JSON data provided in raw data: {e}")
                return jsonify({"error": "Invalid JSON data provided"}), 400
            except Exception as e:
                logger.error(f"Error processing raw data: {str(e)}")
                return jsonify({"error": "Unsupported data format or missing data"}), 400

        if input_json is None:
            return jsonify({"error": "No JSON data could be processed"}), 400

        try:
            processed_graph_json_str = parse_mera_json(input_json)
            processed_graph_data = json.loads(processed_graph_json_str)
        except Exception as e:
            logger.error(f"Error processing JSON with parse_mera_json: {str(e)}")
            return jsonify({"error": f"Failed to process JSON data: {str(e)}"}), 400

        processed_json = {
            "received_from": source,
            "original_data": processed_graph_data,
            "processing_status": "processed_successfully_with_parse_mera_json",
            "notes": "JSON processed using parse_mera_json from json_graph_reader.py"
        }

        storage = current_app.extensions['storage']
        graph_hash = storage.save_graph(processed_json)

        logger.info(f"Stored data with hash: {graph_hash[:8]}...")

        result_url = url_for('web.show_result_page', unique_id=graph_hash, _external=True)

        return jsonify({
            "success": True,
            "message": "Data processed successfully.",
            "result_id": graph_hash,
            "redirect_url": result_url
        })

    except Exception as e:
        logger.error(f"Unhandled error in /api/v3/upload: {str(e)}", exc_info=True)
        return jsonify({"error": f"An unexpected server error occurred: {str(e)}"}), 500


@web_bp.route('/result/<unique_id>')
def show_result_page(unique_id):
    """Display result page for a graph."""
    storage = current_app.extensions['storage']
    result_data = storage.get_graph(unique_id)

    if result_data:
        display_json_str = json.dumps(result_data, indent=4, sort_keys=True)
        return render_template('result.html', result_json_str=display_json_str, unique_id=unique_id)
    else:
        logger.warning(f"Result page requested for ID '{unique_id}', but data not found.")
        return render_template('error.html', message=f"Result with ID '{unique_id}' not found or has expired."), 404


@web_bp.route('/api/v3/data/<unique_id>')
def get_json_data(unique_id):
    """Get JSON data for a graph (API endpoint)."""
    storage = current_app.extensions['storage']
    result_data = storage.get_graph(unique_id)

    if result_data:
        return jsonify(result_data)
    else:
        logger.warning(f"Data NOT found for API request ID: {unique_id}")
        return jsonify({"error": f"Data with ID '{unique_id}' not found or has expired."}), 404


@web_bp.route('/api/v3/device-colors')
def get_device_colors():
    """Serve the device colors configuration."""
    try:
        config_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'device_colors.json')
        with open(config_path, 'r') as f:
            colors_config = json.load(f)
        return jsonify(colors_config)
    except Exception as e:
        logger.error(f"Error loading device colors config: {str(e)}")
        # Return default colors if config file is missing
        return jsonify({
            "device_colors": {
                "CPU": {"fill": "#c62828", "border": "#8e0000", "label": "#ffffff"},
                "SAKURA-II": {"fill": "#2e7d32", "border": "#1b5e20", "label": "#ffffff"},
                "SAKURA_II": {"fill": "#2e7d32", "border": "#1b5e20", "label": "#ffffff"},
                "MERA_BLOCK": {"fill": "#6a1b9a", "border": "#4a148c", "label": "#ffffff"},
                "default": {"fill": "#f57c00", "border": "#e65100", "label": "#ffffff"}
            }
        })


@web_bp.route('/api/v3/node-filters')
def get_node_filters():
    """Serve the node filters configuration."""
    try:
        config_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'node_filters.json')
        with open(config_path, 'r') as f:
            filters_config = json.load(f)
        return jsonify(filters_config)
    except Exception as e:
        logger.error(f"Error loading node filters config: {str(e)}")
        # Return default filters if config file is missing
        return jsonify({
            "filter_patterns": {
                "exact_match": [],
                "contains": [],
                "ends_with": ["VecConstant"],
                "starts_with": []
            }
        })


@web_bp.errorhandler(404)
def page_not_found(e):
    """Handle 404 errors."""
    if request.path.startswith('/api/'):
        return jsonify({"error": "API endpoint not found or resource missing."}), 404
    return render_template('error.html', message="Page not found."), 404


@web_bp.errorhandler(Exception)
def handle_exception(e):
    """Handle unexpected exceptions."""
    logger.error(f"Unhandled server exception for path {request.path}: {str(e)}", exc_info=True)
    if request.path.startswith('/api/'):
        return jsonify({"error": "An unexpected server error occurred on an API route."}), 500
    return render_template('error.html', message="An unexpected server error occurred."), 500
