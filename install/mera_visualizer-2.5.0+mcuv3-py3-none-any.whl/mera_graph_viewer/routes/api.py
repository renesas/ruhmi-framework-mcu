"""REST API routes."""

import logging
from flask import Blueprint, request, jsonify, current_app
from typing import Dict, Any

logger = logging.getLogger(__name__)

api_bp = Blueprint('api', __name__)


@api_bp.route('/graphs', methods=['POST'])
def create_graph():
    """
    Upload and store a new graph.

    Request:
        POST /api/graphs
        Content-Type: application/json
        Body: Graph JSON data

    Response:
        201: { "hash": "abc123...", "metadata": {...} }
        400: { "error": "error message" }
    """
    if not request.is_json:
        return jsonify({'error': 'Content-Type must be application/json'}), 400

    try:
        raw_data = request.get_data(as_text=True)
    except Exception as e:
        return jsonify({'error': f'Failed to read request data: {str(e)}'}), 400

    processor = current_app.extensions['processor']
    result = processor.process_upload(raw_data)

    if result['success']:
        return jsonify({
            'hash': result['hash'],
            'metadata': result['metadata']
        }), 201
    else:
        return jsonify({'error': result['error']}), 400


@api_bp.route('/graphs/<graph_hash>', methods=['GET'])
def get_graph(graph_hash: str):
    """
    Retrieve graph data by hash.

    Request:
        GET /api/graphs/{hash}

    Response:
        200: Graph JSON data
        404: { "error": "Graph not found" }
    """
    storage = current_app.extensions['storage']
    graph_data = storage.get_graph(graph_hash)

    if graph_data is None:
        return jsonify({'error': 'Graph not found'}), 404

    return jsonify(graph_data), 200


@api_bp.route('/graphs/<graph_hash>/metadata', methods=['GET'])
def get_graph_metadata(graph_hash: str):
    """
    Retrieve graph metadata without full data.

    Request:
        GET /api/graphs/{hash}/metadata

    Response:
        200: { "hash": "...", "filesize": 1234, "created_at": "...", ... }
        404: { "error": "Graph not found" }
    """
    storage = current_app.extensions['storage']
    metadata = storage.get_metadata(graph_hash)

    if metadata is None:
        return jsonify({'error': 'Graph not found'}), 404

    return jsonify(metadata), 200


@api_bp.route('/graphs/<graph_hash>', methods=['DELETE'])
def delete_graph(graph_hash: str):
    """
    Delete a graph by hash.

    Request:
        DELETE /api/graphs/{hash}

    Response:
        204: No content (successful deletion)
        404: { "error": "Graph not found" }
    """
    storage = current_app.extensions['storage']
    deleted = storage.delete_graph(graph_hash)

    if not deleted:
        return jsonify({'error': 'Graph not found'}), 404

    return '', 204


@api_bp.route('/stats', methods=['GET'])
def get_stats():
    """
    Get storage statistics.

    Request:
        GET /api/stats

    Response:
        200: { "total_graphs": 42, "total_size_bytes": 1234567, ... }
    """
    storage = current_app.extensions['storage']
    stats = storage.get_stats()
    return jsonify(stats), 200
