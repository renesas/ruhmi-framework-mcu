# Copyright 2022 EdgeCortix Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Mera Quantizer classes"""

import json
import pickle
import numpy as np

from pathlib import Path
from .deploy_project import logger, Target, ArtifactFileType
from . import quantizer
from .mera_platform import Platform
from .model.input_desc import InputDescriptionContainer
from .version import __version__
from tqdm import tqdm
from datetime import datetime


class QuantizedMera2ModelResult:
    def __init__(self, prj_loc, input_desc, q_params, mera_platform, mera_qtz_params):
        self.prj_loc = prj_loc
        self.input_desc = input_desc
        self.q_params = q_params
        self.mera_platform = mera_platform
        self.mera_qtz_params = mera_qtz_params

    @staticmethod
    def load(file_name: str | Path) -> "QuantizedMera2ModelResultPack":
        f_path = Path(file_name).resolve()
        if not f_path.is_file():
            raise ValueError(
                f"Could not open MERA quantized model '{f_path}'. File not found."
            )
        try:
            with open(f_path, "rb") as f:
                pkl_data = pickle.load(f)

                def __extract_version_from_file(pkl_data):
                    # V1 does not contain an explicit field for version
                    return (
                        1
                        if (not isinstance(pkl_data, dict))
                        else int(pkl_data["version"])
                    )

                __mera_ver = __extract_version_from_file(pkl_data)

                if __mera_ver >= 4:
                    # Load for MERA2
                    input_desc, q_params, mera_platform = pkl_data["metadata"]
                    return QuantizedMera2ModelResultPack(
                        input_desc,
                        q_params,
                        mera_platform,
                        pkl_data["units"],
                        pkl_data["plan"],
                        pkl_data["params"],
                    )
                else:
                    # Backwards compatible unpacking. Versions 1-3 are not supported as of MERA 2.6.0.
                    raise ValueError(
                        f"Loading a .mera model in format v{__mera_ver} is not supported as of MERA {__version__}. "
                        "Please re-quantize your model with the current version of MERA."
                    )
        except Exception as ex:
            raise ValueError(
                f"Found error while loading MERA quantized model '{f_path}': {ex}"
            )

    def _get_files_from_backend(self, backend):
        __BACKEND_MAP = {
            "mera_dna": "model.dnair",
            "apache_tvm": "model.tflite",
            "mera_block": "model.mera_block",
        }
        if backend not in __BACKEND_MAP:
            raise ValueError(f"Unhandled plan backend {backend}")
        return __BACKEND_MAP[backend]

    def save(self, file_name: str | Path) -> None:
        f_path = Path(file_name).resolve()
        logger.debug(f"Saving quantized MERA model to '{f_path}' ...")
        __VERSION_PACK = 4
        pickle_data = {
            "version": __VERSION_PACK,
            "metadata": (self.input_desc, self.q_params, self.mera_platform),
            "params": self.mera_qtz_params,
            "units": [],
        }
        # Save the plan and all module inputs
        plan_loc = self.prj_loc.get_artifact("Quantizer", "mera.plan")
        compile_loc = plan_loc.parent.resolve()
        with open(plan_loc, "r") as r:
            plan_data_str = r.read()
            pickle_data["plan"] = plan_data_str
            plan_data = json.loads(plan_data_str)
        __all_units = []
        for stages in plan_data["execution"]["stages"]:
            for stage in stages:
                for groups in stage:
                    __all_units.append(groups[0])
        for unit in __all_units:
            binary_loc = compile_loc / unit["binaries_location"]

            def __fetch(file_name):
                return r.read()

            file_name = self._get_files_from_backend(unit["backend"])
            with open(binary_loc / file_name, "rb") as r:
                __unit_data = r.read()
            pickle_data["units"].append({"unit": unit, "data": __unit_data})
        with open(f_path, "wb") as f:
            pickle.dump(pickle_data, f)


class QuantizedMera2ModelResultPack(QuantizedMera2ModelResult):
    def __init__(
        self, input_desc, q_params, mera_platform, unit_list, plan_str, mera_qtz_params
    ):
        super().__init__(None, input_desc, q_params, mera_platform, mera_qtz_params)
        self.unit_list = unit_list
        self.plan_str = plan_str

    def to_deploy_dir(self, prj):
        # Recreate folder structure
        deploy_path = Path(prj.get_cwd()) / "compilation"
        deploy_path.mkdir(parents=True, exist_ok=True)
        with open(deploy_path / "mera.plan", "w") as w:
            w.write(self.plan_str)
        constant_data_path = Path(prj.get_cwd()) / "param_data"
        constant_data_path.mkdir(parents=True, exist_ok=True)
        for ct_name, ct_data in self.mera_qtz_params.items():
            with open(constant_data_path / f"{ct_name}.bin", "wb") as w:
                w.write(ct_data)
        for unit in self.unit_list:
            unit_info = unit["unit"]
            unit_dir = deploy_path / unit_info["binaries_location"]
            unit_dir.mkdir(parents=True, exist_ok=True)
            bin_name = self._get_files_from_backend(unit_info["backend"])
            with open(unit_dir / bin_name, "wb") as w:
                w.write(unit["data"])


class Quantizer:
    """Class with API to quantize models using MERA"""

    __PRJ_SECTION_NAME = "quantizer"

    def __init__(
        self,
        deployer,
        model,
        quantizer_config: quantizer.QuantizerConfig = quantizer.QuantizerConfigPresets.DEFAULT,
        mera_platform: Platform = Platform.SAKURA_2C,
        **kwargs,
    ):
        """Creates a class for creating MERA quantized models.

        :param deployer: Instance of deployment project created with mera.Deployer.
        :param model: Model to be quantized loaded with mera.ModelLoader.
        :param quantizer_config: Instance of quantizer configuration with user defined options.
        :param mera_platform: Platform to be used for quantizer deployment.
        """
        self.deployer = deployer
        self.prj = deployer.prj
        self.model = model
        if not isinstance(quantizer_config, quantizer.QuantizerConfig):
            raise ValueError(
                "Provided quantizer config is not of type quantizer.QuantizerConfig"
            )
        self.quantizer_config = quantizer_config
        self.mera_platform = mera_platform
        self.transformed = False
        if self.mera_platform == Platform.ALT2:
            self.quantizer_config.flow_version = 11
        elif self.mera_platform == Platform.ALTX:
            self.quantizer_config.flow_version = 2

        try:
            # Use cached deployment for quantizer
            self.fp32_mir_file = self.prj.get_artifact(
                Quantizer.__PRJ_SECTION_NAME, "model.mir"
            )
            logger.info("Using existing prepared model for quantization.")
        except Exception:
            # Deploy for MERA Interpreter target and get the MIR file for quantizer
            self.fp32_mir_file = self.deployer.deploy(
                self.model,
                mera_platform=self.mera_platform,
                target=Target.MERAInterpreter,
                __orig_mera_qtz=True,
                attention_dim_pad=64,
            ).model_loc
            self.prj.add_artifact([(Quantizer.__PRJ_SECTION_NAME, self.fp32_mir_file)])

        self.qtzer_cfg_path = self.prj.save_artifact(
            "qtz_conf.json",
            ArtifactFileType.JSON,
            Quantizer.__PRJ_SECTION_NAME,
            self.quantizer_config.to_dict(),
        )

        from .mera2libs import quantizer as m2_quantizer

        m2_quantizer.RegisterLogger()

        self.qtzer_impl = m2_quantizer.CreateQuantizer(
            str(self.fp32_mir_file), str(self.qtzer_cfg_path)
        )
        self.qlty_list = []
        self._calibration_count = 0
        self._eval_count = 0
        self.transform_report = None
        in_info = self.qtzer_impl.GetInputInfo()
        self.in_info = {n.id: n for n in in_info}
        out_info = self.qtzer_impl.GetOutputInfo()
        self.out_info = {n.id: n for n in out_info}
        logger.info("Model ready for quantization")

    def __format_sq_table(self, sq_data):
        from tabulate import tabulate

        D = []
        H = ["LayerNorm ID", "Applied", "alpha"]
        for node_id, d in sq_data.items():
            D.append(
                [
                    node_id,
                    d.applied,
                    np.round(d.chosen_alpha, 2) if bool(d.applied) else "N/A",
                ]
            )
        print(
            tabulate(
                D, headers=H, tablefmt="fancy_outline", numalign="right", floatfmt=".2f"
            )
        )

    def __human_fmt(self, x, units, scale=1000):
        for unit in units:
            if x < scale:
                return f"{x:3.1f}{unit}"
            x /= scale
        raise ValueError("Number too large")

    def __human_fmt_size(self, x):
        return self.__human_fmt(x, ["B", "KB", "MB", "GB", "TB", "EB"])

    def __human_fmt_count(self, x):
        return self.__human_fmt(x, ["", "K", "Mil", "Bil", "Tril"])

    def __format_qtz_transform_report(self, qt_data):
        __row_parsed = {}
        __all_types = set([t_row.data_type for t_row in qt_data.transform_data])
        for t_row in qt_data.transform_data:
            if t_row.node_class not in __row_parsed:
                __row_parsed[t_row.node_class] = {n: [0, 0] for n in __all_types}
            __row_parsed[t_row.node_class][t_row.data_type][0] += 1
            __row_parsed[t_row.node_class][t_row.data_type][1] += t_row.param_bytes
        from tabulate import tabulate

        print("Model param post-quantization report:")
        print(
            f"  Original size:    {self.__human_fmt_size(qt_data.orig_param_size_bytes)} ({self.__human_fmt_count(qt_data.orig_num_params)} params)"
        )
        print(
            f"  Transformed size: {self.__human_fmt_size(qt_data.transformed_param_size_bytes)} ({self.__human_fmt_count(qt_data.transformed_num_params)} params)"
        )
        print(
            f"  Not transformed size: {self.__human_fmt_size(qt_data.untransformed_param_size_bytes)} ({self.__human_fmt_count(qt_data.untransformed_num_params)})"
        )
        print(f"  Transform ratio: {qt_data.GetQuantizedRatio():.2f}")
        # Summary of Node_class : Count_of_types
        __all_types = list(__all_types)
        H = ["Node Class"] + [f"# {t}" for t in __all_types]
        D = []
        for node_class, row in __row_parsed.items():
            row_content = [
                str(row[t][0])
                + (f" ({self.__human_fmt_size(row[t][1])})" if row[t][1] > 0 else "")
                for t in __all_types
            ]
            D.append([node_class] + row_content)
        D.append(
            ["TOTAL"]
            + [
                str(sum([__row_parsed[n][t][0] for n in __row_parsed.keys()]))
                + f" ({self.__human_fmt_size(sum([__row_parsed[n][t][1] for n in __row_parsed.keys()]))})"
                for t in __all_types
            ]
        )
        print(
            tabulate(
                D, headers=H, tablefmt="fancy_outline", numalign="right", floatfmt=".2f"
            )
        )

    def __format_sensitivity_report(self, sdata):
        sdata = sorted(sdata, key=lambda x: x.recipe_root)
        H = ["Node Root", "Rewrite Name", "Metric Kind", "Value"]
        D = []
        for s_row in sdata:
            k, v = list(s_row.sensitivity_metrics.items())[0]
            D.append([s_row.recipe_root, s_row.rewrite_name, k, float(v)])
        from tabulate import tabulate

        print(tabulate(D, headers=H, tablefmt="fancy_outline", floatfmt=".2f"))

    def __run_samples_core(self, data, run_kind, qlty_list=None):
        n_runs = int(len(data))
        logger.info(f"Running model {run_kind} with {n_runs} samples ...")
        is_calibration = run_kind == "calibration"
        if is_calibration:
            self._calibration_count = n_runs
        else:
            self._eval_count = n_runs
        for it in tqdm(
            range(n_runs),
            ncols=100,
            colour="yellow",
            desc=f"Running {run_kind}",
            unit=" samples",
            bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining},{rate_noinv_fmt}{postfix}]",
        ):
            sample = data[it]
            if not isinstance(sample, dict):
                raise ValueError(
                    f"ERROR at #{it}: Data provided is not a dictionary, it is a {type(sample)}"
                )
            for in_name, in_data in sample.items():
                from .utils import mera2_sanitize

                in_name = mera2_sanitize(in_name)
                if in_name not in self.in_info:
                    logger.warning(
                        f"Provided input name {in_name} is not one of the valid inputs {list(self.in_info.keys())}. Ignoring it."
                    )
                    continue
                iinfo = self.in_info[in_name]
                __dtype_map = {
                    "UInt8": np.uint8,
                    "Int8": np.int8,
                    "Int32": np.int32,
                    "Bool": bool,
                    "Int64": np.int64,
                    "Float32": np.float32,
                }
                if in_data.shape != tuple(iinfo.shape):
                    raise ValueError(
                        f'ERROR at #{it}: Shape input mismatch for "{in_name}": {in_data.shape} vs {iinfo.shape}'
                    )
                if in_data.dtype != __dtype_map.get(iinfo.dtype_str):
                    raise ValueError(
                        f'ERROR at #{it}: Input dtype mismatch for "{in_name}": {in_data.dtype} vs {iinfo.dtype_str}'
                    )
                self.qtzer_impl.SetInput(str(in_name), in_data.ravel().view("uint8"))
            try:
                if is_calibration:
                    self.qtzer_impl.RunCalibrationSample()
                elif run_kind == "evaluation":
                    quality_data = self.qtzer_impl.RunEvaluationSample()
                    assert qlty_list is not None
                    qlty_list.append(
                        quantizer.QuantizationQuality(
                            quality_data.collected_metrics, list(self.out_info)
                        )
                    )
                elif run_kind == "sensitivity":
                    self.qtzer_impl.RunSensitivitySample()
                else:
                    raise ValueError("Unknown run kind")
            except RuntimeError as e:
                raise RuntimeError(
                    f"MERA internal compiler error during {run_kind} (sample #{it}):\n  {e}"
                ) from e

    def calibrate(self, calibration_data: list[dict[str, np.ndarray]]) -> "Quantizer":
        """Feeds a series of realistic input data samples in order to be able to compute accurate internal ranges.
        MERA will collect the information from the execution of these data samples and compute the quantization domains as determined
        by the user configuration. It is recommended to use a big enough dataset of realistic samples in order to obtain the best
        quantization accuracy results.

        :param calibration_data: List of dictionaries with the format {'input_name' : 'np_array'} containing the different data samples.
        """
        if not isinstance(calibration_data, list):
            raise ValueError(
                f"calibration_data argument is not a list, it is a {type(calibration_data)}"
            )
        if self.transformed:
            self.reset()
        self.__run_samples_core(calibration_data, "calibration")
        return self

    def cast_to_type(self, qtype: str = "bf16") -> "Quantizer":
        """Performs a full-model conversion to the specified quantization type, applying the transformation uniformly across all layers.
        Creates a new transformed model instance with all parameters and activations converted to the given data type.
        Note that calibration data is not required when converting between unquantized types (such as floating point conversions)

        :param qtype: Chosen Quantization type.
        """
        self.qtzer_impl.MixedPrecisionReady()
        self.transform_report = self.qtzer_impl.DirectCastTransform(qtype)
        # self.__format_qtz_transform_report(self.transform_report)
        self.transformed = True
        return self

    def for_mixed_precision(
        self, sensitivity_data: list[dict[str, np.ndarray]], display_table: bool = False
    ) -> "Quantizer":
        """Applies mixed-precision quantization to a machine learning model.

        Strategically quantizes different layers with varying bit-widths to optimize
        the trade-off between model accuracy and computational efficiency. More
        sensitive layers retain higher precision while less critical operations
        are aggressively quantized.

        :param sensitivity_data: List of realistic data samples used to compute the sensitivity of each layer in order to aid the
            choice of implementation.
        :param display_table: Display in stdout a table summarising the sensitivity per layer.
        """
        if not isinstance(sensitivity_data, list):
            raise ValueError(
                f"sensitivity_data argument is not a list, it is a {type(sensitivity_data)}"
            )
        if len(sensitivity_data) == 0:
            raise ValueError("sensitivity_data must contain at least one sample")
        self.qtzer_impl.MixedPrecisionReady()
        self.__run_samples_core(sensitivity_data, "sensitivity")
        stv_data = self.qtzer_impl.CalculateSensitivity()
        if display_table:
            self.__format_sensitivity_report(stv_data)
        return self

    def reset(self) -> "Quantizer":
        """Resets all the internal observed metrics of the quantizer as well as any existing qtz transformed model."""
        self.qtzer_impl.Reset()
        self.transformed = False
        self.qlty_list = []
        self.transform_report = None
        self._calibration_count = 0
        self._eval_count = 0
        return self

    def quantize(
        self,
        alpha: float = 0.25,
        gamma: float = 1.0,
        s_min: float = 8.0,
        beta: float = 10.0,
        k: float = 4.0,
    ) -> "Quantizer":
        """Uses the data gathered from the calibrate() method and creates a transformed model based on the quantizer configuration."""
        self.transform_report = self.qtzer_impl.QuantizeTransform(
            alpha, gamma, s_min, beta, k
        )
        self.__format_qtz_transform_report(self.transform_report)
        self.transformed = True
        return self

    def evaluate_quality(
        self, evaluation_data: list[dict[str, np.ndarray]], display_table: bool = True
    ) -> list[quantizer.QuantizationQuality]:
        """Measures the quantization quality of a transformed model with a given evaluation data.
        This should be some realistic data sample(s) ideally different from the calibration dataset.
        In order to measure quality the user must have called quantize() method first.

        :param evaluation_data: List of dictionaries with the format {'input_name' : 'np_array'} containing the different data samples.
        :param display_table: Whether to display quality metrics to stdout or not.
        :return: List of quality metrics container.
        """
        if not self.transformed:
            raise ValueError(
                "Can only get quality after the model is quantized. Call quantize() first"
            )
        if not isinstance(evaluation_data, list):
            raise ValueError(
                f"evaluation_data argument is not a list, it is a {type(evaluation_data)}"
            )
        self.qlty_list = []
        self.__run_samples_core(evaluation_data, "evaluation", qlty_list=self.qlty_list)
        if display_table:
            for q in self.qlty_list:
                node_table, out_table = q.to_table()
                print(node_table)
                print(out_table)
        return self.qlty_list

    def save_to(self, dst_path: str | Path) -> "Quantizer":
        """Saves the transformed model to file. Must have called quantize() first.
        :param dst_path: Destination path where the model will be saved.
        """
        if not self.transformed:
            raise ValueError(
                "Can only save after the model is quantized. Call quantize() first"
            )
        self.qtzer_impl.SaveQuantizedTo(str(dst_path))
        return self

    def apply_smoothquant(
        self, alpha: float = 0.5, autotune: bool = True
    ) -> "Quantizer":
        """Applies SmoothQuant transformation to the model to improve quantization accuracy
        for models with outlier activations (e.g. large language models).
        Migrates the quantization difficulty from activations to weights by smoothing activation
        scales into the weight tensors.

        :param alpha: Controls the migration strength between activations and weights (0.0–1.0).
            Lower values shift more quantization difficulty to weights; higher values to activations.
        :param autotune: If True, MERA automatically searches for the optimal alpha value.
        :return: self
        """
        sq_dst = self.prj.root_path / "model_sq.mera"
        sq_report = self.qtzer_impl.ApplySmoothQuant(alpha, autotune, str(sq_dst))
        self.__format_sq_table(sq_report)
        logger.info(f"Saved SmoothQuant transformed model to {sq_dst}")
        # Have to recreate the quantizer with the new SQ model
        from .mera2libs import quantizer as m2_quantizer

        self.qtzer_impl = m2_quantizer.CreateQuantizer(
            str(sq_dst), str(self.qtzer_cfg_path)
        )
        self.reset()
        return self

    def get_report(self, model_id: str) -> dict:
        """Extracts all information about the quantization process as a dictionary that can be saved for debugging.

        :param model_id: Identifier to be used for this document.
        """
        if not self.transformed:
            raise ValueError(
                "Can only generate quantization report after the model is quantized. Call quantize() first"
            )
        return {
            "model_id": model_id,
            "creation_time": datetime.now().strftime("%m/%d/%Y, %H:%M:%S"),
            "platform": str(self.mera_platform),
            "calib_count": self._calibration_count,
            "eval_count": self._eval_count,
            "transform_info": self.transform_report.ToDict()
            if self.transform_report is not None
            else {},
            "quality_info": [
                {"nodes": q.node_summary(), "outputs": q.out_summary()}
                for q in self.qlty_list
            ],
            "quantizer_config": self.quantizer_config.to_dict(),
        }


def get_input_desc(mera_model_path) -> InputDescriptionContainer:
    """Retrieve the input description of a MERA quantized model generated with MERA2.

    :param mera_model_path: Path to .mera model file.

    :return: Dict with info about the model's inputs.
    """
    from .mera2libs import quantizer as m2_quantizer

    data = m2_quantizer.GetInputDesc(str(mera_model_path))
    desc_parsed = {d.id: (tuple(d.shape), str(d.dtype_str).lower()) for d in data}
    return InputDescriptionContainer(desc_parsed)
