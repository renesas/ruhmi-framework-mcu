# Copyright 2024 EdgeCortix Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""MERA Utility functions."""

import ctypes
import os
import subprocess
import sys
import logging
from pathlib import Path


def cmd(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, raise_if_fail=True):
    logging.debug(f"Running command '{command}'")
    with subprocess.Popen(
        command,
        shell=True,
        stdout=stdout,
        stderr=stderr,
        universal_newlines=True,
        errors="replace",
    ) as p:
        if p.stdout is not None:
            for line in p.stdout:
                print(line, end="")
    if p.returncode != 0 and raise_if_fail:
        raise subprocess.CalledProcessError(p.returncode, command)
    return p.returncode


def find_tool(tool_name: str) -> str:
    import mera

    bin_dir = Path(mera.__file__).resolve().parent / "bin_utils"
    loc = bin_dir / tool_name
    loc_exe = bin_dir / (tool_name + ".exe")
    if loc.exists():
        return str(loc)
    if loc_exe.exists():
        return str(loc_exe)
    raise FileNotFoundError(f"Could not locate tool '{tool_name}' in {bin_dir}")


def mera2_sanitize(x: str) -> str:
    # TODO - Match MERA2
    return x.replace(":", "_").replace("/", "_").replace(".", "_")


# Result of the last preload attempt: None = not attempted yet, "" = attempted and
# skipped/failed, otherwise the path of the lib that got loaded.
_dna_full_preload = None


def find_dna_full_lib() -> Path | None:
    """Locates `libmeradna-full`, shipped by the `mera-native-compile` wheel.

    :return: Path to the lib, or None if it is not installed.
    """
    override = os.environ.get("MERA_DNA_FULL_LIB")
    if override:
        loc = Path(override)
        return loc if loc.exists() else None
    import mera

    libs_dir = Path(mera.__file__).resolve().parent / "mera2libs"
    # Versioned name sorts after the unversioned one (libmeradna-full.x86.so.2.7.0
    # vs libmeradna-full.x86.so); the versioned file is the one that gets shipped.
    matches = sorted(f for f in libs_dir.glob("libmeradna-full*.so*") if f.is_file())
    return matches[-1] if matches else None


def preload_dna_full_lib() -> str | None:
    """Loads `libmeradna-full` into the global symbol scope before the MERA runtime.

    The `mera-native-runtime` wheel ships `libmeradna-runtime`, which does not
    contain the DNA simulator; only `libmeradna-full` from `mera-native-compile`
    does. Loading `full` with RTLD_GLOBAL *before* `mera2.rt` pulls in its NEEDED
    `libmeradna-runtime` makes the meradna symbols resolve into `full`, which is
    the in-process equivalent of
    `LD_PRELOAD=<site-packages>/mera/mera2libs/libmeradna-full.x86.so.<version>`.

    Only meaningful for the x86 simulation/interpretation targets; IP runs are
    served by `libmeradna-runtime` alone. Set `MERA_DNA_PRELOAD=0` to disable, or
    `MERA_DNA_FULL_LIB=<path>` to point at a specific lib.

    :return: Path of the preloaded lib, or None if nothing was preloaded.
    """
    global _dna_full_preload
    if _dna_full_preload is not None:
        return _dna_full_preload or None
    _dna_full_preload = ""
    if os.name == "nt":
        # DLLs are bound by file name, so there is no interposition to do here.
        return None
    if os.environ.get("MERA_DNA_PRELOAD", "1") == "0":
        return None

    lib = find_dna_full_lib()
    if lib is None:
        logging.warning(
            "Could not find libmeradna-full; simulator targets need the DNA compiler"
            " libs. Install them with `pip install mera-native-compile`."
        )
        return None
    if "mera2.rt" in sys.modules:
        # Too late to interpose: mera2.rt already dragged in libmeradna-runtime and
        # its symbols are bound. Loading full now would only add a second, partly
        # live copy of meradna to the process.
        logging.warning(
            f"mera2.rt was imported before the MERA runtime was set up, cannot preload {lib}."
            f" Re-run with LD_PRELOAD={lib} if a simulator target fails."
        )
        return None
    try:
        ctypes.CDLL(str(lib), mode=ctypes.RTLD_GLOBAL)
    except OSError as e:
        logging.warning(f"Failed to preload {lib}: {e}")
        return None
    logging.debug(f"Preloaded DNA lib {lib}")
    _dna_full_preload = str(lib)
    return _dna_full_preload
