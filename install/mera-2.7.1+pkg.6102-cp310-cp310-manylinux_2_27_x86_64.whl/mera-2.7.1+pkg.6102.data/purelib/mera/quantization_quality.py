# Copyright 2022 EdgeCortix Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""MERA Quantization quality metrics."""

import numpy as np
import math
import json
from pathlib import Path


class QuantizationQualityMetrics:
    """Container for per-output quantization quality metrics computed from reference and quantized inference results."""

    def __init__(
        self,
        ref_data: list[tuple[np.ndarray, ...]],
        qtz_data: list[tuple[np.ndarray, ...]],
    ):
        assert isinstance(ref_data, list) and isinstance(qtz_data, list)
        assert len(ref_data) == len(qtz_data)
        assert len(ref_data) > 0
        assert np.all([len(r) == len(q) for r, q in zip(ref_data, qtz_data)])

        self.ref_data = ref_data
        self.qtz_data = qtz_data
        self.error = [
            tuple([a - b for a, b in zip(r, q)])
            for r, q in zip(self.ref_data, self.qtz_data)
        ]

    def __reduce_img(self, data, f):
        assert isinstance(data, list)
        return [tuple([f(x) for x in d]) for d in data]

    @property
    def images(self) -> int:
        return len(self.qtz_data)

    @property
    def num_elements(self) -> tuple[int, ...]:
        r = self.__reduce_img(self.qtz_data, lambda x: int(x.size))
        return r if self.images == 1 else r[0]

    @property
    def mean_error(self) -> list[tuple[float, ...]]:
        return self.__reduce_img(self.error, lambda x: float(np.mean(x)))

    @property
    def std_dev(self) -> list[tuple[float, ...]]:
        return self.__reduce_img(self.error, lambda x: float(np.std(x)))

    @property
    def max_abs_error(self) -> list[tuple[float, ...]]:
        return self.__reduce_img(self.error, lambda x: float(np.max(np.abs(x))))

    @property
    def mean_squared_error(self) -> list[tuple[float, ...]]:
        def __f(x):
            try:
                return float(np.mean(x**2))
            except Exception:
                return float("inf")

        return self.__reduce_img(self.error, __f)

    @property
    def range(self) -> list[tuple[float, ...]]:
        return self.__reduce_img(self.ref_data, lambda x: float(np.max(x) - np.min(x)))

    @property
    def max(self) -> list[tuple[float, ...]]:
        return self.__reduce_img(self.ref_data, lambda x: float(np.max(x)))

    @property
    def min(self) -> list[tuple[float, ...]]:
        return self.__reduce_img(self.ref_data, lambda x: float(np.min(x)))

    @property
    def max_q(self) -> list[tuple[float, ...]]:
        return self.__reduce_img(self.qtz_data, lambda x: float(np.max(x)))

    @property
    def min_q(self) -> list[tuple[float, ...]]:
        return self.__reduce_img(self.qtz_data, lambda x: float(np.min(x)))

    @property
    def psnr_all(self) -> list[tuple[float, ...]]:
        max = self.range  # get full range of values, in case negative values exist
        mse = self.mean_squared_error
        psnr = []

        def __f(max, mse):
            try:
                if math.isinf(mse) or mse <= 0:
                    return float("-inf")
                return 10 * math.log10((max**2) / mse) if max > 0 else 100.0
            except Exception:
                print(f"Could not compute PSNR with values {max} {mse}")
                return float("-inf")

        for max_t, mse_t in zip(max, mse):
            psnr.append(
                tuple([float(__f(max_e, mse_e)) for max_e, mse_e in zip(max_t, mse_t)])
            )
        return psnr

    @property
    def psnr(self) -> tuple[float, ...]:
        return tuple(
            np.round(np.min(np.array(self.psnr_all), axis=0), decimals=2).tolist()
        )

    @property
    def all_scores(self) -> list[tuple[float, ...]]:
        """Custom function to give a score % on the quantization quality of a model. Computed as
        (1 - (max_abs_error / range)) * 100
        Should return a percentage on the worst case accuracy drop in the output data set.
        """

        # FIXME - Better score when range == 0
        def score_f(max_e, range):
            return (
                ((1 - max_e / range) * 100)
                if range != 0
                else (100 if max_e == 0 else 0)
            )

        return [
            tuple(
                [
                    float(score_f(max_err_e, range_e))
                    for max_err_e, range_e in zip(max_err, range)
                ]
            )
            for max_err, range in zip(self.max_abs_error, self.range)
        ]

    @property
    def score(self) -> tuple[float, ...]:
        """Simplified score function which will be the median across all the evaluation images
        for each of the outputs."""
        return tuple(np.round(np.min(np.array(self.all_scores), axis=0), decimals=2))

    def to_dict(self):
        _METRICS = [
            "images",
            "num_elements",
            "mean_error",
            "std_dev",
            "max_abs_error",
            "mean_squared_error",
            "range",
            "all_scores",
            "score",
            "psnr",
            "psnr_all",
            "max",
            "min",
            "max_q",
            "min_q",
        ]
        return {m: getattr(self, m) for m in _METRICS}


def calculate_quantization_quality(
    ref_data: tuple[np.ndarray, ...] | list[tuple[np.ndarray, ...]],
    qtz_data: tuple[np.ndarray, ...] | list[tuple[np.ndarray, ...]],
) -> QuantizationQualityMetrics:
    """Helper function that computes quantization quality metrics by comparing reference (fp32) output tensors
    to quantized output tensors.

    :param ref_data: Reference output(s) from the float model. Either a single tuple of outputs or a list of tuples (one per evaluation image).
    :param qtz_data: Quantized output(s) from the MERA quantized model, in the same format as ref_data.
    :return: Container with quality metrics comparing ref_data and qtz_data.
    """
    _ref_data = ref_data if isinstance(ref_data, list) else [ref_data]
    _qtz_data = qtz_data if isinstance(qtz_data, list) else [qtz_data]
    return QuantizationQualityMetrics(_ref_data, _qtz_data)


class MeraQualityContainer:
    def __init__(self, out_metrics):
        self.out_metrics = out_metrics

    def __getattr__(self, __attr: str):
        if __attr in self.__dict__:
            return getattr(self, __attr)
        return getattr(self.out_metrics, __attr)

    def plot_histogram(
        self,
        dest_file: Path,
        channels: int | tuple[int, int] | None = None,
        output_id: int | None = None,
        plot_title: str | None = None,
        axis: int | None = None,
    ) -> None:
        """Computes the histogram of the distribution comparing the floating point reference with the MERA quantized results.

        :param dest_file: Path to destination file where the plotted histogram will be saved.
        :param channels: Selection of channels where the distribution should be computed. If 'None' provided,
            it will compute the whole tensor.
            Accepts an integer for selecting a single channel or a tuple with ('start_channel', 'end_channel') values.
        :param output_id: If this quality container wraps several output tensors, selects which one to apply the operation.
            If there is a single output this argument is ignored.
        :param plot_title: If provided, overrides the autogenerated title of the plot.
        :param axis: Axis of tensor's dimension for the channels. It will be 1 for NCHW and 3 for NHWC.
            Only used when providing a value for 'channels' argument.
        """
        # TODO - Currently only generating for the first evaluation image.
        ref_data = self.out_metrics.ref_data[0]
        mera_data = self.out_metrics.qtz_data[0]

        if len(ref_data) > 1 and output_id is None:
            raise ValueError(
                "Quality container has multiple outputs but 'output_id' parameter has not been specified.\n"
                + f"Please set which of the {len(ref_data)} outputs you want to compute the histogram."
            )
        if not output_id:
            output_id = 0
        ref_data = ref_data[output_id]
        mera_data = mera_data[output_id]
        if len(ref_data.shape) < len(mera_data.shape):
            ref_data = np.expand_dims(ref_data, 0)
        if channels is None:
            ref_data = ref_data.flatten()
            mera_data = mera_data.flatten()
        else:
            if axis is None and len(ref_data.shape) > 1:
                raise ValueError(
                    "Need to provide an axis when selecting channels from multidimensional data.\n"
                    + f"Current shape: {ref_data.shape}"
                )
            slc = (
                channels
                if isinstance(channels, int)
                else slice(channels[0], channels[1])
            )
            ref_data = np.take(ref_data, slc, axis=axis).flatten()
            mera_data = np.take(ref_data, slc, axis=axis).flatten()
        if plot_title is None:
            plot_title = (
                "Data Histogram on "
                + (f"Channel(s) {channels}" if channels is not None else "Tensor")
                + f" of output #{output_id}"
            )
        try:
            import matplotlib.pyplot as plt
        except ImportError as e:
            raise ImportError(
                "plot_histogram() requires matplotlib. Install with: pip install 'mera[full]'"
            ) from e
        bins = np.histogram_bin_edges(
            np.concatenate([ref_data, mera_data]), bins="auto"
        )
        plt.clf()
        for label, data in [("fp32", ref_data), ("mera_qtz", mera_data)]:
            plt.hist(
                data,
                bins=bins,
                alpha=0.5,
                label=label,
                weights=np.ones(len(data)) * 100.0 / len(data),
            )
        plt.ylabel("Percent")
        plt.title(plot_title)
        plt.legend()
        plt.savefig(dest_file)
        plt.close()


class MeraDebugQualityContainer(MeraQualityContainer):
    @staticmethod
    def __dequantize(qtzed_images, q_params, node_name):
        deq_data = []
        data_dims = len(qtzed_images[0].shape)
        data_type = qtzed_images[0].dtype
        if data_type == np.float32:
            # Data is already dequantized, so treat it as such
            scl = 1
            zp = 0
        elif data_dims < 4:
            scl = np.array([q[0] for q in q_params])
            zp = np.array([q[1] for q in q_params])
            if len(q_params) > 1 and len(qtzed_images[0].shape) > 1:
                index = (
                    -1 if "MatMul" in node_name else -2
                )  # XXX - Awful check, but no other way to access this info atm.
                q_h = qtzed_images[0].shape[index]
                repeats = math.ceil(q_h / len(q_params))

                # per-channel dequantization
                def __to_dequant_shape(X):
                    return np.resize(
                        np.concatenate(tuple([X for _ in range(repeats)])), q_h
                    ).reshape((q_h, 1))

                scl = __to_dequant_shape(scl)
                zp = __to_dequant_shape(zp)
        elif data_dims == 4:
            n, c, h, w = qtzed_images[0].shape
            if len(q_params) == 1:
                scl = np.ones_like(qtzed_images[0]) * q_params[0][0]
                zp = np.ones_like(qtzed_images[0]) * q_params[0][1]
            elif n == 1:
                # Data dequantizing
                # Converts a list of channel scalars into a NCHW tensor with data filled out
                def __expand_per_channel(data, h, w):
                    return np.expand_dims(
                        np.array([np.tile(x, (h, w)) for x in data]), axis=0
                    )

                scl = __expand_per_channel([q[0] for q in q_params], h, w)
                zp = __expand_per_channel([q[1] for q in q_params], h, w)
            else:
                # Weight dequantizing
                def __expand_per_channel(data, c, h, w):
                    return np.array([np.tile(x, (c, h, w)) for x in data])

                scl = __expand_per_channel([q[0] for q in q_params], c, h, w)
                zp = __expand_per_channel([q[1] for q in q_params], c, h, w)
        else:
            raise ValueError(f"Cannot dequantize data with {data_dims}D shape")
        for img in qtzed_images:
            deq_data.append(scl * (img.astype(np.float32) - zp))
        return deq_data

    def __init__(self, out_metrics, qtzer_node_data, q_params):
        MeraQualityContainer.__init__(self, out_metrics)
        self.node_metrics = {}
        for node_name, node_data in qtzer_node_data.items():
            ref_data = node_data["ref"]
            got_data_qtz = node_data["got"]

            try:
                got_data = MeraDebugQualityContainer.__dequantize(
                    got_data_qtz, q_params[node_name], node_name
                )

                def __wrap(data):
                    return [(x,) for x in data]

                self.node_metrics[node_name] = calculate_quantization_quality(
                    __wrap(ref_data), __wrap(got_data)
                )
            except ValueError as ex:
                print(
                    f"ERROR While dequantizing {node_name} {got_data_qtz[0].shape} {ex}"
                )

    def summary(self):
        data = {}
        for op_name, metric in self.node_metrics.items():
            data[op_name] = metric.to_dict()
        with open("qtz_debug_metrics.json", "w") as w:
            w.write(json.dumps(data))
