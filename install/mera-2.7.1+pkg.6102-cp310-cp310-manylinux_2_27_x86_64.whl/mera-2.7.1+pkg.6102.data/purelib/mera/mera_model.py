# Copyright 2022 EdgeCortix Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Mera Model classes."""

from os.path import isfile
from collections.abc import Sequence
import json

from pathlib import Path
from .deploy_project import ArtifactFileType, logger, Layout
from .model import (
    InputDescriptionContainer,
    io_desc_from_mera2,
    io_desc_from_json_data,
    InputNormCfg,
)


class MeraModel:
    """Base class representing a ML model compatible with MERA deployment project."""

    def __init__(
        self,
        prj,
        model_name,
        model_path,
        use_prequantize_input=False,
        save_model=False,
        model_load_idx=None,
        input_norm_cfg=None,
    ):
        self.model_name = model_name
        self.model_path_orig = Path(model_path).resolve().absolute()
        self.model_path = self.model_path_orig
        self.use_prequantize_input = use_prequantize_input
        self.model_load_idx = (
            int(model_load_idx) if model_load_idx is not None else None
        )
        self._input_desc = None
        self.__input_norm_cfg = input_norm_cfg

        self.prj = prj
        self.model_export_dir = (
            f"model_{self.model_load_idx}"
            if self.model_load_idx is not None
            else "model"
        )
        if prj and save_model and model_path is not None:
            prj.pushd(self.model_export_dir, abs=True)
            ex_path = str(model_path) + "_data"
            self.model_path = prj.save_artifact(
                model_path, ArtifactFileType.FILE, "model"
            )
            if isfile(ex_path):
                prj.save_artifact(ex_path, ArtifactFileType.FILE, "model")
            prj.popd()
        self.__save_input_desc()

    def _load_model_tvm(self):
        # NOTE: Despite the name, this is NOT used by the removed TVMDeployer.
        # It is called only by apache_tvm_compile() (MERADeployer's CPU sub-graph path).
        # Keep until that caller is replaced.
        raise NotImplementedError()

    def _read_input_desc(self):
        # To be overriden by child classes
        raise NotImplementedError()

    def __save_input_desc(self):
        if self.prj:
            self.prj.pushd(self.model_export_dir, abs=True)
            self.prj.save_artifact(
                "input_desc.json",
                ArtifactFileType.JSON,
                self.model_export_dir,
                self.input_desc.to_dict(),
            )
            self.prj.popd()

    def _update_input_desc(self, io_desc_path):
        with open(io_desc_path, "r") as r:
            self._input_desc = io_desc_from_json_data(json.loads(r.read()))
        self.__save_input_desc()

    @property
    def input_desc(self):
        if self._input_desc is None:
            self._input_desc = self._read_input_desc()
        return self._input_desc

    @property
    def input_norm_cfg(self):
        return self.__input_norm_cfg

    def _get_mera_aux_config(self):
        return {"prequantize_input": self.use_prequantize_input}

    def get_input_shape(self, input_name: str | None = None) -> tuple[int, ...]:
        """Utility class to query the shape of an input variable of the model

        :param input_name: Specifies which input to get the shape from. If unset, assumes there is only one input.
        :return: A tuple representing the shape of the input variable.
        """
        if not input_name:
            if self.input_desc.num_inputs > 1:
                raise ValueError(
                    f"Multiple input variables exist in {self.model_name}. "
                    + 'Please specify using "input_name" argument.'
                )
            return list(self.input_desc.all_inputs.values())[0].input_shape
        else:
            return self.input_desc.input_desc.get(input_name).input_shape


class MeraModelOnnx(MeraModel):
    """Specialization of MeraModel for a ONNX ML model."""

    def __init__(
        self,
        prj,
        model_name,
        model_path,
        batch_num,
        shape_mapping,
        model_info,
        model_load_idx,
        input_norm_cfg,
    ):
        self.model_info = model_info
        self.batch_num = batch_num
        self.shape_mapping = shape_mapping
        super().__init__(
            prj,
            model_name,
            model_path,
            model_load_idx=model_load_idx,
            input_norm_cfg=input_norm_cfg,
        )

    def _read_input_desc(self):
        return io_desc_from_mera2("fe_onnx_cli", self.model_path, self.shape_mapping)


class MeraModelTflite(MeraModel):
    """Specialization of MeraModel for a TFLite ML model."""

    def __init__(
        self,
        prj,
        model_name,
        model_path,
        use_prequantize_input,
        model_load_idx=None,
        input_norm_cfg=None,
    ):
        super().__init__(
            prj,
            model_name,
            model_path,
            use_prequantize_input=use_prequantize_input,
            model_load_idx=model_load_idx,
            input_norm_cfg=input_norm_cfg,
        )

    def _read_input_desc(self):
        return io_desc_from_mera2("fe_tflite_cli", self.model_path)

    def _load_model_tvm(self):
        logger.info(f"Loading TFLite model {self.model_name} for TVM")

        from tflite import Model as __tfliteModel
        from tvm.relay.frontend import from_tflite as __tvm_from_tflite

        model_raw = self.model_path.read_bytes()
        model = __tfliteModel.GetRootAsModel(model_raw, 0)
        shape_dict, dtype_dict = self.input_desc._for_tvm_tflite()

        return __tvm_from_tflite(
            model, shape_dict=shape_dict, dtype_dict=dtype_dict, model_raw=model_raw
        )

    def _get_mera_aux_config(self):
        return {
            "weight_layout": "HWIO",
            "prequantize_input": self.use_prequantize_input,
        }


class MeraModelExecutorch(MeraModel):
    """Specialization of MeraModel for a Executorch/EXIR ML model."""

    def __init__(self, prj, model_name, model_path, input_norm_cfg):
        super().__init__(prj, model_name, model_path, input_norm_cfg=input_norm_cfg)

    def _read_input_desc(self):
        return io_desc_from_mera2("fe_exir_cli", self.model_path)

    def _load_model_tvm(self):
        raise NotImplementedError("Executorch not supported for TVM flow")


class Mera2ModelQuantized(MeraModel):
    """MeraModel class of a model quantized with MERA2 tools."""

    def __init__(self, prj, model_name, model_path):
        super().__init__(prj, model_name, model_path, False)

    def _read_input_desc(self):
        from .mera_quantizer import get_input_desc

        return InputDescriptionContainer(get_input_desc(self.model_path))


class Mera2ModelFused(MeraModel):
    def __init__(self, prj, fused_path, mera_models, share_input, fused_model_name):
        self._mera_models = mera_models
        self.share_input = share_input
        self.model_path = fused_path
        MeraModel.__init__(
            self,
            prj,
            ("fused_" + "_".join([str(m.model_name) for m in mera_models]))
            if not fused_model_name
            else fused_model_name,
            fused_path,
        )

    def _read_input_desc(self):
        return InputDescriptionContainer._join(
            [m.input_desc for m in self._mera_models]
        )


class ModelLoader:
    """Utility class for loading and converting ML models into models compatible with MERA

    :param deployer: Reference to a MERA deployer class, if None is provided,
        information about the model will not be added to the deployment project.
    :type deployer: mera.deploy.Deployer
    """

    def __init__(self, deployer=None):
        self.prj = deployer.prj if deployer else None
        self.deployer = deployer

    def __check_model(self, model_path, model_name):
        m_loc = Path(model_path).resolve()
        if not model_name:
            model_name = m_loc.stem

        if not m_loc.exists():
            raise ValueError(
                f"Model file {model_path} does not exist or could not be accessed"
            )
        return model_name

    def from_tflite(
        self,
        model_path: str,
        model_name: str | None = None,
        use_prequantize_input: bool = False,
        model_load_idx: int | None = None,
        input_norm_cfg: InputNormCfg | None = None,
    ) -> MeraModelTflite:
        """Converts a tensorflow model in TFLite format into a compatible model for MERA.

        :param model_path: Path to the tensorflow model file in TFLite format
        :param model_name: Display name of the model being deployed.
            Will default to the stem name of the model file if not provided.
        :param use_prequantize_input: Whether input is provided prequantized, or not. Defaults to False
        :param model_load_idx: An optional id to be used with model fusion, in order to identify the different models to be fused.
        :param input_norm_cfg: Configuration holder for input norm feature.

        :return: The input model compatible with MERA.
        """
        model_name = self.__check_model(model_path, model_name)
        return MeraModelTflite(
            self.prj,
            model_name,
            model_path,
            use_prequantize_input,
            model_load_idx,
            input_norm_cfg,
        )

    def from_onnx(
        self,
        model_path: str,
        model_name: str | None = None,
        layout: Layout = Layout.NHWC,
        batch_num: int = 1,
        shape_mapping: dict[str, int] = {},
        model_info: dict = {},
        model_load_idx: int | None = None,
        input_norm_cfg: InputNormCfg | None = None,
    ) -> MeraModelOnnx:
        """Converts a ONNX model into a compatible model for MERA.
        NOTE this loader is best optimised for float models using op_set=12

        :param model_path: Path to the ONNX model file.
        :param model_name: Display name of the model being deployed.
            Will default to the stem name of the model file if not provided.
        :param layout: Data layout of the model being loaded. Defaults to NHWC layout
        :param batch_num: If the model contains symbolic batch numbers, loads it resolving its value to
            the parameter provided. Defaults to 1.
        :param shape_mapping: If the model contains symbolic shapes, provides their static mapping.
        :param model_info: An optional dictionary with model's metadata or other hyperparameters.
        :param model_load_idx: An optional id to be used with model fusion, in order to identify the different models to be fused.
        :param input_norm_cfg: Configuration holder for input norm feature.

        :return: The input model compatible with MERA.
        """
        model_name = self.__check_model(model_path, model_name)
        return MeraModelOnnx(
            self.prj,
            model_name,
            model_path,
            batch_num,
            shape_mapping,
            model_info,
            model_load_idx,
            input_norm_cfg,
        )

    def from_quantized_mera(self, model_path: str, model_name: str | None = None):
        """Converts a previously quantized MERA model into a compatible deployable model.

        :param model_path: Path to the MERA model file
        :param model_name: Display name of the model being deployed.
            Will default to the stem name of the model file if not provided.

        :return: The input model compatible with MERA.
        """
        model_name = self.__check_model(model_path, model_name)
        return Mera2ModelQuantized(self.prj, model_name, model_path)

    def from_executorch(
        self,
        model_path: str,
        model_name: str | None = None,
        input_norm_cfg: InputNormCfg | None = None,
    ) -> MeraModelExecutorch:
        """Converts a PyTorch model in Executorch/EXIR format (.pte) into a compatible model for MERA.

        :param model_path: Path to the PyTorch model file in ExecuTorch format (.pte)
        :param model_name: Display name of the model being deployed.
            Will default to the stem name of the model file if not provided.
        :param input_norm_cfg: Configuration holder for input norm feature.

        :return: The input model compatible with MERA.
        """
        model_name = self.__check_model(model_path, model_name)
        return MeraModelExecutorch(self.prj, model_name, model_path, input_norm_cfg)

    def fuse_models(
        self,
        mera_models: Sequence[MeraModel],
        share_input: bool = False,
        fused_model_name: str | None = None,
    ) -> MeraModel:
        """Fusing multiple MERA models into a single model for compilation and deployment.
           This is especially useful for fully utilizing the compute resources of a large platform.
           The inputs of the fused model are the concatenation of the inputs of the models to be fused.
           Similarly, the outputs of the fused model are the concatenation of the outputs of the models to be fused.
           For example, let's suppose `mera_models` has two models, m1 and m2, then for the fused model,
           the inputs are [m1 inputs, m2 inputs] and the outputs are [m1 outputs, m2 outputs].
           When each model in `mera_models` has one input and `share_input` is True, the fused model has one input.

        :param mera_models: List of MERA models to be fused.
        :param share_input: Whether the models share input or not.
        :param fused_model_name: Overrides the autogenerated name for the fused model result.

        :return: The fused model.
        """
        assert self.deployer is not None
        fused_path = self.deployer._fuse_models(mera_models, share_input)
        return Mera2ModelFused(
            self.prj, fused_path, mera_models, share_input, fused_model_name
        )


def calculate_kv_cache_size(model_info: dict, token_length: int) -> int:
    """Helper function that calculates for a given model_info dictionary and a requested cache length,
    the amount of elements that need to be allocated on the device in order to provide KV cache functionality.
    This function can be used to give an estimate and to plan ahead of the extra impact in storage needs for a specific model.

    :param model_info: Model metadata and other hyperparameters.
    :param token_length: Desired max token length for the KV cache.

    :return: Amount of elements that the KV cache infrastructure will take on memory. Can be multiplied by the type size of the
    deployment to get the byte usage.
    """
    try:
        atten_size = int(model_info["hidden_size"])
        n_layers = int(model_info["num_hidden_layers"])
        return 2 * token_length * atten_size * n_layers
    except Exception as ex:
        raise ValueError(f"KV cache size could not be calculated: {ex}")
