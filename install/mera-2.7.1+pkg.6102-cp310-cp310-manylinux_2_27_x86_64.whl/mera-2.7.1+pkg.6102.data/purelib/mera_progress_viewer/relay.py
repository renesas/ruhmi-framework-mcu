"""In-process one-to-many relay for the compiler state stream.

The deploy process starts one of these in a daemon thread for the duration of a
progress-enabled compile: the compile subprocess PUSHes its state events to the
relay's collector (via ``EC_STATE_BROKER_URL``), the relay folds them into one
forest and re-publishes to any number of attached viewers (PUB), answering
late-join snapshot requests (ROUTER). All sockets bind ephemeral ports on
``tcp://127.0.0.1`` so it works on Windows (no ipc://).

  producer --PUSH connect--> [PULL collector] RELAY [PUB publish] --> SUB viewers
                                                     [ROUTER snapshot] <-- REQ viewers

All zmq sockets live and die on the relay thread (zmq sockets are not
thread-safe): ``start_relay`` waits until the thread has bound its sockets and
reported the endpoints, then returns a handle whose ``stop()`` signals the
thread to unwind and close them itself.
"""

import atexit
import contextlib
import json
import os
import threading
import time
from typing import Any

from .state_model import DEFAULT_TOPIC, StateTree

_BROKER_ENV = "EC_STATE_BROKER_URL"

_HEARTBEAT_S = 1.0
_POLL_MS = 200
_START_TIMEOUT_S = 5.0


class _Broker:
    def __init__(self, topic):
        self._topic = topic
        self._tree = StateTree()  # merged forest (one root per producer)
        self._seq = 0  # our own monotonic watermark
        self._epoch = "broker-" + str(os.getpid())
        self._zmq: Any = None
        self._ctx: Any = None
        self._collector: Any = None
        self._publisher: Any = None
        self._router: Any = None
        # Filled in by setup(); read by start_relay after the ready event.
        self.collector_url = self.publish_url = self.snapshot_url = None

    def setup(self):
        """Bind all sockets to ephemeral loopback TCP ports and record the actual
        endpoints. Must run on the relay thread."""
        import zmq

        self._zmq = zmq
        self._ctx = zmq.Context()
        self._collector = self._ctx.socket(zmq.PULL)  # producers PUSH here
        self._publisher = self._ctx.socket(zmq.PUB)  # viewers SUB here
        self._router = self._ctx.socket(zmq.ROUTER)  # viewers REQ snapshots here
        for sock in (self._collector, self._publisher, self._router):
            sock.setsockopt(zmq.LINGER, 0)
            sock.bind("tcp://127.0.0.1:0")
        self.collector_url = self._collector.getsockopt_string(zmq.LAST_ENDPOINT)
        self.publish_url = self._publisher.getsockopt_string(zmq.LAST_ENDPOINT)
        self.snapshot_url = self._router.getsockopt_string(zmq.LAST_ENDPOINT)

    def _forward(self, ev):
        """Re-stamp a producer event with our epoch+seq and publish it."""
        self._seq += 1
        ev = dict(ev)
        ev["epoch"] = self._epoch
        ev["seq"] = self._seq
        self._publisher.send_multipart([self._topic.encode(), json.dumps(ev).encode()])

    def _snapshot(self):
        return {
            "epoch": self._epoch,
            "seq": self._seq,
            "now": time.time(),
            "nodes": self._tree.snapshot_nodes(),
        }

    def run(self, stop_event):
        zmq = self._zmq
        poller = zmq.Poller()
        poller.register(self._collector, zmq.POLLIN)
        poller.register(self._router, zmq.POLLIN)
        last_hb = time.time()

        while not stop_event.is_set():
            socks = dict(poller.poll(timeout=_POLL_MS))

            if self._collector in socks:
                while True:
                    try:
                        frames = self._collector.recv_multipart(flags=zmq.NOBLOCK)
                    except zmq.Again:
                        break
                    if len(frames) < 2:
                        continue
                    try:
                        ev = json.loads(frames[1])
                    except ValueError:
                        continue
                    if ev.get("type") == "resync":
                        # Producer re-announce: rebuild its subtree, don't forward.
                        self._tree.apply_snapshot_nodes(ev.get("nodes", []))
                        continue
                    self._tree.apply(ev)
                    self._forward(ev)

            if self._router in socks:
                # ROUTER envelope: [identity, (empty), body]. Echo the envelope,
                # replace the body with the merged snapshot.
                msg = self._router.recv_multipart()
                envelope = msg[:-1]
                self._router.send_multipart(
                    envelope + [json.dumps(self._snapshot()).encode()]
                )

            now = time.time()
            if now - last_hb >= _HEARTBEAT_S:
                last_hb = now
                self._seq += 1
                hb = {
                    "type": "heartbeat",
                    "epoch": self._epoch,
                    "seq": self._seq,
                    "ts": now,
                }
                self._publisher.send_multipart(
                    [self._topic.encode(), json.dumps(hb).encode()]
                )

    def close(self):
        for sock in (self._collector, self._publisher, self._router):
            if sock is not None:
                sock.close(linger=0)
        if self._ctx is not None:
            self._ctx.term()


class RelayHandle:
    """Owns a running relay thread. ``collector_url`` is what the compile
    subprocess should PUSH to (``EC_STATE_BROKER_URL``)."""

    def __init__(self, pid, broker, thread, stop_event):
        self.pid = int(pid)
        self._thread = thread
        self._stop = stop_event
        self.collector_url = broker.collector_url
        self.publish_url = broker.publish_url
        self.snapshot_url = broker.snapshot_url

    def stop(self, timeout=2.0):
        """Signal the relay thread to unwind (it closes its own sockets) and drop
        the registry entry. Idempotent."""
        from . import endpoints

        self._stop.set()
        self._thread.join(timeout=timeout)
        endpoints.remove_endpoints(self.pid)


def start_relay(pid, model_name="", topic=DEFAULT_TOPIC) -> RelayHandle:
    """Start a relay thread bound to ephemeral loopback ports, register its
    endpoints keyed by ``pid`` so ``mera_progress_viewer --pid <pid>`` can find
    them, and return a handle. Raises ImportError if pyzmq is unavailable, or
    RuntimeError if the sockets can't be bound in time."""
    import zmq  # noqa: F401  -- fail fast & synchronously if pyzmq is missing

    from . import endpoints

    broker = _Broker(topic)
    stop_event = threading.Event()
    ready = threading.Event()
    err = {}

    def _target():
        try:
            broker.setup()
        except Exception as exc:  # bind failure, missing pyzmq, ...
            broker.close()  # release any sockets/context bound before the failure
            err["exc"] = exc
            ready.set()
            return
        ready.set()
        try:
            broker.run(stop_event)
        finally:
            broker.close()

    thread = threading.Thread(
        target=_target, name=f"mera-progress-relay-{pid}", daemon=True
    )
    thread.start()
    if not ready.wait(timeout=_START_TIMEOUT_S):
        stop_event.set()
        raise RuntimeError("progress relay failed to start (timed out binding sockets)")
    if "exc" in err:
        raise err["exc"]

    endpoints.write_endpoints(
        pid,
        {
            "publish": broker.publish_url,
            "snapshot": broker.snapshot_url,
            "collector": broker.collector_url,
            "topic": topic,
            "model": model_name,
        },
    )
    # Backstop for exit paths that skip stop(); a SIGKILL can't run it, but the
    # viewer's connection handshake covers that. Harmless once stop() removed it.
    atexit.register(endpoints.remove_endpoints, int(pid))
    return RelayHandle(pid, broker, thread, stop_event)


@contextlib.contextmanager
def serving(pid, model_name="", topic=DEFAULT_TOPIC):
    """Run a relay for the duration of the block: start it, publish its collector
    endpoint via ``EC_STATE_BROKER_URL`` so a child process's state producer feeds
    it, then on exit stop the relay and restore the prior environment (works
    whether the block exits normally or raises). Yields the RelayHandle."""
    handle = start_relay(pid, model_name, topic)
    prev = os.environ.get(_BROKER_ENV)
    os.environ[_BROKER_ENV] = handle.collector_url
    try:
        yield handle
    finally:
        handle.stop()
        if prev is None:
            os.environ.pop(_BROKER_ENV, None)
        else:
            os.environ[_BROKER_ENV] = prev
