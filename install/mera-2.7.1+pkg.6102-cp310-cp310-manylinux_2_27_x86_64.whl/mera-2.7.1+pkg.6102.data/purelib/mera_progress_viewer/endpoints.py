"""pid <-> TCP-endpoint resolution for the progress relay.

The relay binds ephemeral TCP ports (``tcp://127.0.0.1:0``), so the pid the user
passes to ``mera_progress_viewer --pid`` can't encode the ports directly. The
deploy process therefore writes a small registry entry keyed by its pid recording
the relay's publish/snapshot/collector endpoints; the viewer reads it back. The
pid is the only handle the user needs -- everything else is looked up here.

Entries live under ``<tempdir>/mera_progress/`` so it works on Linux and Windows.
"""

import json
import os
import tempfile
from pathlib import Path

_SUBDIR = "mera_progress"


def registry_dir() -> Path:
    """The per-user directory holding one ``<pid>.json`` entry per live relay.
    Created on demand."""
    d = Path(tempfile.gettempdir()) / _SUBDIR
    d.mkdir(parents=True, exist_ok=True)
    return d


def _entry_path(pid: int) -> Path:
    return registry_dir() / f"{int(pid)}.json"


def write_endpoints(pid: int, info: dict) -> Path:
    """Register the relay endpoints for ``pid``. ``info`` should carry
    ``publish``/``snapshot``/``collector``/``topic``/``model``; ``pid`` is added
    here. Written atomically (temp file + replace) so a viewer never reads a
    half-written entry."""
    payload = dict(info)
    payload["pid"] = int(pid)
    path = _entry_path(pid)
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(payload))
    os.replace(tmp, path)  # atomic on POSIX and Windows
    return path


def resolve_endpoints(pid: int) -> dict:
    """Read the registered relay endpoints for ``pid``. Raises FileNotFoundError
    with a user-facing message if nothing is registered for that pid.

    A registered entry can outlive the deploy that wrote it (a hard kill skips
    cleanup); whether the relay is actually reachable is settled by the viewer's
    connection handshake, not here."""
    path = _entry_path(pid)
    if not path.exists():
        raise FileNotFoundError(
            f"No MERA deploy with live progress is registered for pid {pid}. "
        )
    return json.loads(path.read_text())


def remove_endpoints(pid: int) -> None:
    """Delete the registry entry for ``pid`` (best-effort; ignores a missing one)."""
    try:
        _entry_path(pid).unlink()
    except FileNotFoundError:
        pass
