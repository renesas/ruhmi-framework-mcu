"""Rendering for the progress viewer.

A dashboard-style Rich front-end: a header panel with KPI stat tiles + an overall
gauge, and -- when toggled on -- a titled "work breakdown" panel holding a
scrollable, colour-gauged per-node view. Rendering is a pure function of a set of
``StateTree`` sources, so it can be exercised offline against a hand-built tree.
"""

from rich import box
from rich.console import Group
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

_SPINNER = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"

# Breakdown layout: the per-node bar fills leftover width but never below _BAR_MIN;
# the name is content-sized up to _NAME_CAP and compressed to _NAME_MIN when tight.
_BAR_MIN = 12
_NAME_CAP = 48
_NAME_MIN = 8

# At/above this terminal width the size column spells out "instructions"; below
# it, the abbreviated "insts" is used so the column stays narrow.
_FULL_INSTS_MIN_WIDTH = 110

# Label colour by status. Names use the terminal's DEFAULT fg (fixed greyNN is
# too faint on a dark background; `dim` is used only for secondary text). Only
# semantic states get a hue; running is bold-default so active work stands out.
_STATUS_STYLE = {
    "done": "green",
    "failed": "red bold",
    "skipped": "yellow",
    "running": "bold",
    "pending": "",  # terminal default foreground
}

# Thin single-row gauge: a heavy rule for the done portion, a light rule for the
# track, and a half-heavy tip at the leading edge.
_BAR_FILL = "━"
_BAR_EMPTY = "─"
_BAR_TIP = "╾"


class RenderOpts:
    """Display-only knobs set from the CLI."""

    def __init__(self, show_ids=False, max_depth=1):
        self.show_ids = show_ids
        self.max_depth = max_depth


# ---------------------------------------------------------------------------
# formatting helpers
# ---------------------------------------------------------------------------


def _fmt_time(seconds):
    if seconds is None or seconds < 0:
        return "--:--"
    total = int(seconds)
    h, rem = divmod(total, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"


def _spin(tick, frames):
    return frames[tick % len(frames)]


def _bar(fraction, width, color):
    """A slim gauge: heavy rule (``━``) for the done portion in ``color`` with a
    ``╾`` leading tip, over a light rule (``─``) track. Distinct heavy/light
    glyphs (not just colour) keep it legible on any terminal background."""
    width = max(1, width)
    f = max(0.0, min(1.0, fraction))
    bar = Text()
    if f >= 1.0:
        bar.append(_BAR_FILL * width, style=color)
        return bar
    n = int(round(f * width))  # cells covered by the done portion (incl. tip)
    if n <= 0:
        if f > 0.0:  # a sliver of progress still shows a tip
            bar.append(_BAR_TIP, style=color)
            bar.append(_BAR_EMPTY * (width - 1), style="dim")
        else:
            bar.append(_BAR_EMPTY * width, style="dim")
        return bar
    bar.append(_BAR_FILL * (n - 1) + _BAR_TIP, style=color)
    bar.append(_BAR_EMPTY * (width - n), style="dim")
    return bar


def _live_sources(sources):
    """Yield each source that has received its first snapshot (``epoch`` set);
    sources still connecting are skipped."""
    return (s for s in sources if s.epoch is not None)


def _live_trees(sources):
    """Yield the ``StateTree`` of each live source -- the common case for rollups
    that don't need the source's epoch."""
    return (s.tree for s in _live_sources(sources))


def overall(sources):
    """(known, fraction, eta) rolled up across every live source's roots. Used
    for the overview bar; unknown if any root subtree is indeterminate."""
    fracs, etas, n_roots = [], [], 0
    all_known = True
    for tree in _live_trees(sources):
        now = tree.producer_now()
        for root in tree.roots():
            known, val = tree.fraction(root)
            all_known &= known
            if known:
                fracs.append(val)
            e = tree.eta(root, now=now)
            if e is not None:
                etas.append(e)
            n_roots += 1
    if n_roots == 0:
        return (False, 0.0, None)
    return (
        all_known,
        sum(fracs) / n_roots if fracs else 0.0,
        max(etas) if etas else None,
    )


def _any_update(sources):
    """True once any node has reported progress or reached a terminal state --
    i.e. the compiler has started doing measurable work. Until then the whole
    view just waits, rather than showing a tree of 0% bars/spinners."""
    for tree in _live_trees(sources):
        stack = list(tree.roots())
        while stack:
            n = tree.find(stack.pop())
            if n is None:
                continue
            if (n.progress or 0) > 0 or n.status in ("done", "failed", "skipped"):
                return True
            stack.extend(tree.children(n.id))
    return False


def _root_elapsed(sources):
    """Longest running root elapsed, for the header 'elapsed' stat."""
    best = None
    for tree in _live_trees(sources):
        now = tree.producer_now()
        for root in tree.roots():
            el = tree.elapsed(root, now=now)
            if el is not None:
                best = el if best is None else max(best, el)
    return best


# ---------------------------------------------------------------------------
# Rich rendering
# ---------------------------------------------------------------------------


def _iter_str(tree, node_id, n):
    """Raw iteration count 'done/total' for a determinate leaf; "" otherwise.
    Reveals what the producer reported: absent means the node is deferred (no
    size yet), '0/N' that a total is known but no progress has been advanced."""
    if tree.children(node_id):
        return ""  # a parent's number is a rollup, not an iteration count
    if n.sizing.get("kind") == "determinate":
        total = n.sizing.get("total", 0)
        if total:
            return f"{int(n.progress)}/{int(total)}"
    return ""


def _sub_size(tree, node_id, full):
    """Instruction count of a subgraph, available from the moment it's declared:
    the scheduler sets the sub layer's weight to its instruction count to weight
    the overall bar, and that weight rides along in the declare/snapshot.
    Labelled 'instructions' when there's room, else 'insts'."""
    n = tree.find(node_id)
    if n is None or n.weight <= 1:
        return None
    return f"{int(n.weight)} {'instructions' if full else 'insts'}"


def _subtree_end(tree, node_id):
    """Latest ``ended_at`` anywhere in node_id's subtree (None if nothing ended)."""
    best = None
    stack = [node_id]
    while stack:
        node = tree.find(stack.pop())
        if node is None:
            continue
        if node.ended_at is not None and (best is None or node.ended_at > best):
            best = node.ended_at
        stack.extend(tree.children(node.id))
    return best


def _display_elapsed(tree, node_id, n, now):
    """Elapsed for display. A node the producer explicitly left already has a
    frozen elapsed; but a fully-complete grouping node (whose layer scope the
    producer keeps 'running' until teardown) would tick forever -- so freeze it at
    its subtree's last end instead of counting against ``now``."""
    if n.started_at is None:
        return None
    if n.ended_at is None:
        known, val = tree.fraction(node_id)
        if known and val >= 1.0:
            end = _subtree_end(tree, node_id)
            if end is not None:
                return max(0.0, end - n.started_at)
    return tree.elapsed(node_id, now=now)


def _name_text(tree, node_id, n, guide, opts):
    """The tree-indented node name (+ status tag, hint, optional id), left-aligned."""
    name = Text(guide, style="dim")
    name.append(n.label or node_id, style=_STATUS_STYLE.get(n.status, ""))
    if n.status in ("failed", "skipped"):
        name.append(f" ({n.status})", style=_STATUS_STYLE.get(n.status, ""))
    known, _ = tree.fraction(node_id)
    if not known:
        d, tot = tree.hint(node_id)
        if tot:
            name.append(f"  ({d}/{tot} done)", style="dim")
    if opts.show_ids:
        name.append(f"  [{node_id}]", style="dim")
    return name


def _node_metrics(tree, node_id, n, now, tick, opts, full_size, bar_w):
    """(insts, bar, %, N/M, elapsed, ETA) cells for a node; the bar is rendered to
    exactly ``bar_w`` so it fills its (width-driven) column."""
    known, val = tree.fraction(node_id)
    # A running node with no measurable progress yet (deferred, or a total the
    # producer hasn't advanced) spins rather than showing a stuck 0% bar.
    animated = not known or (n.status == "running" and val <= 0.0)
    if animated:
        bar = Text(_spin(tick, _SPINNER).center(bar_w), style="cyan")
        pct = Text("")
    else:
        finished = val >= 1.0
        color = "red" if n.status == "failed" else ("green" if finished else "cyan")
        bar = _bar(val, bar_w, color)
        pct = Text(f"{val * 100:.0f}%")

    size_txt = ""
    if n.parent_id in tree.roots():  # a subgraph -> its size proxy, own column
        size_txt = _sub_size(tree, node_id, full_size) or ""

    el = _display_elapsed(tree, node_id, n, now)
    eta_txt = ""
    if n.status == "running":
        e = tree.eta(node_id, now=now)
        if e is not None and e > 0:
            eta_txt = f"ETA {_fmt_time(e)}"
    return (
        Text(size_txt, style="dim"),
        bar,
        pct,
        Text(_iter_str(tree, node_id, n), style="dim"),
        Text(_fmt_time(el) if el is not None else "", style="dim"),
        Text(eta_txt, style="dim"),
    )


def _flatten(sources, opts):
    """Depth-first list of node specs ``(tree, node_id, now, guide)`` for a
    windowed view; a ``("proc", epoch)`` marker precedes each process when several
    are live. Roots are top-level (no guide); descendants get ``├──``/``└──``
    connectors. Honours ``opts.max_depth``."""
    specs: list[tuple] = []
    live = list(_live_sources(sources))
    multi = len(live) > 1

    def walk(tree, node_id, now, prefix, is_last, depth):
        if depth == 0:
            guide, child_prefix = "", ""
        else:
            guide = prefix + ("└── " if is_last else "├── ")
            child_prefix = prefix + ("    " if is_last else "│   ")
        specs.append((tree, node_id, now, guide))
        unlimited = opts.max_depth < 0
        if unlimited or depth < opts.max_depth:
            kids = tree.children(node_id)
            for i, child in enumerate(kids):
                walk(tree, child, now, child_prefix, i == len(kids) - 1, depth + 1)

    for s in live:
        tree = s.tree
        now = tree.producer_now()
        roots = tree.roots()
        if multi:
            specs.append(("proc", s.epoch))
            for i, r in enumerate(roots):
                walk(tree, r, now, "", i == len(roots) - 1, 1)
        else:
            for r in roots:
                walk(tree, r, now, "", True, 0)
    return specs


def _breakdown_table(specs, tick, opts, full_size, inner_w):
    """One aligned table from the windowed node specs. Columns are width-driven:
    the tree name and insts are left-aligned; %, N/M, elapsed and ETA are fixed
    right-aligned columns; the bar fills whatever is left over (never below
    ``_BAR_MIN`` -- when the terminal is too narrow for that, the name compresses
    instead). ``inner_w`` is the panel's inner width."""
    insts_w = 18 if full_size else 11  # left-aligned "<n> instructions" / "<n> insts"

    # Pass 1: build the names, keep the node specs, and measure the widest name.
    rows, max_name = [], _NAME_MIN
    for spec in specs:
        if spec[0] == "proc":
            name = Text(f"process {spec[1]}", style="cyan")
            rows.append((name, None))
        else:
            tree, node_id, now, guide = spec
            n = tree.find(node_id)
            if n is None:
                continue
            rows.append(
                (_name_text(tree, node_id, n, guide, opts), (tree, node_id, n, now))
            )
        max_name = max(max_name, rows[-1][0].cell_len)

    # Widths: name to content (capped); bar fills the rest but keeps _BAR_MIN, so
    # a too-narrow terminal compresses the name rather than the bar.
    right = 4 + 11 + 7 + 11  # % + N/M + elapsed + ETA
    fixed = insts_w + right
    pad = 6  # inter-column gaps (grid padding, collapsed)
    name_w = min(max_name, _NAME_CAP)
    bar_w = inner_w - pad - name_w - fixed
    if bar_w < _BAR_MIN:
        name_w = max(_NAME_MIN, inner_w - pad - fixed - _BAR_MIN)
        bar_w = max(_BAR_MIN, inner_w - pad - name_w - fixed)

    table = Table.grid(padding=(0, 1))
    table.add_column(
        width=name_w, overflow="ellipsis", no_wrap=True
    )  # tree name (left)
    table.add_column(width=insts_w, no_wrap=True)  # insts (left)
    table.add_column(width=bar_w, no_wrap=True)  # bar (fills)
    table.add_column(width=4, justify="right", no_wrap=True)  # percentage
    table.add_column(width=11, justify="right", no_wrap=True)  # N/M
    table.add_column(width=7, justify="right", no_wrap=True)  # elapsed
    table.add_column(width=11, justify="right", no_wrap=True)  # ETA
    for name, node in rows:
        if node is None:
            table.add_row(name, "", "", "", "", "", "")
            continue
        tree, node_id, n, now = node
        size, bar, pct, itr, el, eta = _node_metrics(
            tree, node_id, n, now, tick, opts, full_size, bar_w
        )
        table.add_row(name, size, bar, pct, itr, el, eta)
    return table


def _counts(sources):
    """(done, total) over the subgraphs -- the top-level children of each root --
    for the 'done' stat tile. A sub is counted done by its rollup (fraction 1.0),
    not status: the producer leaves a sub's bars but never the sub's own layer."""
    done = total = 0
    for tree in _live_trees(sources):
        for root in tree.roots():
            for sub in tree.children(root):
                total += 1
                known, val = tree.fraction(sub)
                if known and val >= 1.0:
                    done += 1
    return done, total


def _stat_tiles(sources, ov):
    """A row of headline KPIs: elapsed, ETA, overall %, subgraphs done."""
    known, frac, eta = ov
    done, total = _counts(sources)
    el = _root_elapsed(sources)
    tiles = Text()

    def tile(label, value):
        if len(tiles):
            tiles.append("     ")
        tiles.append(f"{label} ", style="dim")
        tiles.append(value, style="bold")

    tile("elapsed", _fmt_time(el) if el is not None else "--:--")
    tile("ETA", _fmt_time(eta) if (eta is not None and eta > 0) else "--:--")
    tile("overall", f"{frac * 100:.0f}%" if known else "··%")
    tile("done", f"{done}/{total}")
    return tiles


def _gauge_line(ov, gauge_w):
    """The overall gauge + trailing percentage inside the header panel."""
    known, frac, _ = ov
    grid = Table.grid(padding=(0, 1), expand=True)
    grid.add_column(ratio=1, no_wrap=True)  # gauge fills the panel
    grid.add_column(width=4, justify="right", no_wrap=True)  # percentage
    if known:
        bar = _bar(frac, gauge_w, "green" if frac >= 1.0 else "cyan")
        pct = Text(f"{frac * 100:.0f}%", style="bold")
    else:
        bar = Text(_BAR_EMPTY * gauge_w, style="dim")
        pct = Text("··%", style="dim")
    grid.add_row(bar, pct)
    return grid


def _top_panel(info, sources, tick, gauge_w, waiting):
    """Header dashboard panel: title + model, a KPI tile row and the overall
    gauge -- or, before any progress, a single 'waiting for compiler' spinner."""
    title = Text("MERA compile", style="bold cyan")
    if info.get("model"):
        title.append(f"  ·  {info['model']}", style="bold")
    if waiting:
        el = _root_elapsed(sources)
        body = Text()
        body.append("elapsed ", style="dim")
        body.append(
            f"{_fmt_time(el) if el is not None else '--:--'}     ", style="bold"
        )
        body.append(f"{_spin(tick, _SPINNER)}  waiting for compiler…", style="cyan")
    else:
        ov = overall(sources)  # one rollup, shared by the tiles and the gauge
        body = Group(_stat_tiles(sources, ov), _gauge_line(ov, gauge_w))
    return Panel(
        body,
        title=title,
        title_align="left",
        subtitle=f"pid {info.get('pid', '?')}",
        subtitle_align="right",
        box=box.ROUNDED,
        border_style="cyan",
        padding=(0, 1),
    )


def render(sources, tick, info, opts, height=None, width=None, view=None):
    """Dashboard TUI: a header panel (title, KPI tiles, overall gauge) and -- when
    ``view.details`` is toggled on -- a titled 'work breakdown' panel holding a
    scrollable per-node view. ``height``/``width`` are the live terminal size and
    bound the breakdown; ``view`` carries the details toggle + scroll offset, which
    is clamped here against the true row count."""
    live = list(_live_sources(sources))
    waiting = not live or not _any_update(sources)
    inner_w = (width or 80) - 4  # panel borders + padding
    gauge_w = max(10, inner_w - 8)  # fill the panel (leave room for the trailing %)

    parts = [_top_panel(info, sources, tick, gauge_w, waiting)]
    if waiting:
        return Group(*parts)

    if view is None or not view.details:
        if view is not None:
            parts.append(Text("  press d for the per-node breakdown", style="dim"))
        return Group(*parts)

    specs = _flatten(sources, opts)
    total = len(specs)
    # Reserve the header panel (4 lines) + the breakdown panel's own top/bottom
    # borders (2); the rest is the scrollable window.
    budget = max(1, height - 6) if height else total
    view.page = budget
    view.max = max(0, total - budget)
    view.offset = max(0, min(view.offset, view.max))
    off = view.offset
    window = specs[off : off + budget]

    keys = "↑/↓ · PgUp/PgDn · g/G top/bottom · d overview · q quit"
    subtitle = (
        f"↕ {off + 1}–{off + len(window)}/{total}   {keys}" if total > budget else keys
    )
    full_size = width is None or width >= _FULL_INSTS_MIN_WIDTH
    parts.append(
        Panel(
            _breakdown_table(window, tick, opts, full_size, inner_w),
            title="work breakdown",
            title_align="left",
            subtitle=subtitle,
            subtitle_align="left",
            box=box.ROUNDED,
            border_style="dim",
            padding=(0, 1),
        )
    )
    return Group(*parts)
