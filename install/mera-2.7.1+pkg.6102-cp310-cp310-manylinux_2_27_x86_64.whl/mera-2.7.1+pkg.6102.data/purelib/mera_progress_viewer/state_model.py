"""Compiler state model -- Python consumer core.

The wire-protocol contract shared with the compiler's C++ progress producer: keep
the event/node schema here compatible with that backend -- do not diverge it.

Folds the compiler's append-only state-event stream into a tree and rolls up
progress, and adds the late-joiner snapshot handshake, so viewers can subscribe
to a compile's live state. The pure-Python tree logic (StateTree) has no zmq
dependency and is unit-testable offline; ZmqSubscriber adds the transport.
"""

import json
import time

# ---------------------------------------------------------------------------
# Tree model + rollup
# ---------------------------------------------------------------------------


class Node:
    __slots__ = (
        "id",
        "parent_id",
        "label",
        "kind",
        "sizing",
        "progress",
        "status",
        "weight",
        "eta_group",
        "started_at",
        "ended_at",
    )

    def __init__(self, node_id):
        self.id = node_id
        self.parent_id = ""
        self.label = ""
        self.kind = ""
        self.sizing = {"kind": "deferred"}
        self.progress = 0
        self.status = "pending"
        self.weight = 1.0  # contribution to the parent's rolled-up fraction
        self.eta_group = ""  # cohort id for estimating ETA while unstarted
        # Wall-clock timing, stamped by the consumer on enter/leave (the producer
        # does not send timestamps). None = unknown.
        self.started_at = None
        self.ended_at = None


_TERMINAL = ("done", "failed", "skipped")


class StateTree:
    """Folds the append-only event stream into a tree; computes rollup."""

    def __init__(self, clock=time.time):
        self._nodes = {}  # id -> Node
        self._order = {}  # parent_id ("" for roots) -> [child id, ...]
        self._clock = clock  # local wall clock (injectable for tests)
        self._cohorts = {}  # eta_group id -> set of member node ids
        # Producer-vs-local clock offset, learned from the snapshot's `now`, so
        # producer-stamped timestamps and "now" share one (producer) domain.
        # producer_now() == local clock - offset.
        self._clock_offset = 0.0

    def set_clock_offset(self, offset):
        self._clock_offset = offset

    def producer_now(self):
        return self._clock() - self._clock_offset

    # -- folding -----------------------------------------------------------
    def _get(self, node_id):
        node = self._nodes.get(node_id)
        if node is None:
            node = Node(node_id)
            self._nodes[node_id] = node
        return node

    def _record_order(self, parent_id, node_id):
        siblings = self._order.setdefault(parent_id, [])
        if node_id not in siblings:
            siblings.append(node_id)

    def _event_time(self, e):
        # Producer wall-clock timestamp; fall back to our best estimate of the
        # producer's current time only if the event truly lacks one (a present
        # ts of 0.0 is honored, not treated as missing).
        ts = e.get("ts")
        return ts if ts is not None else self.producer_now()

    def apply(self, e):
        t = e.get("type")
        if t == "heartbeat":
            return
        node_id = e.get("id")
        if node_id is None:  # resync or any non-node message: not for apply()
            return
        if t == "declare":
            n = self._get(node_id)
            n.parent_id = e.get("parent_id") or ""
            n.label = e.get("label", "")
            n.kind = e.get("kind", "")
            n.weight = e.get("weight", 1.0)
            new_eg = e.get("eta_group", "")
            if n.eta_group != new_eg:
                if n.eta_group:
                    self._cohorts.get(n.eta_group, set()).discard(node_id)
                if new_eg:
                    self._cohorts.setdefault(new_eg, set()).add(node_id)
                n.eta_group = new_eg
            n.sizing = e.get("sizing") or {"kind": "deferred"}
            n.status = "pending"
            self._record_order(n.parent_id, node_id)
        elif t == "enter":
            n = self._get(node_id)
            n.status = "running"
            if n.started_at is None:
                n.started_at = self._event_time(e)
        elif t == "expand":
            if "sizing" in e:
                self._get(node_id).sizing = e["sizing"]
        elif t == "advance":
            n = self._get(node_id)
            if n.started_at is None:  # progress implies work has begun
                n.started_at = self._event_time(e)
            if "value" in e:
                n.progress = e["value"]
            elif "delta" in e:
                n.progress += e["delta"]
        elif t == "leave":
            n = self._get(node_id)
            n.status = e.get("status", "done")
            if n.ended_at is None:
                n.ended_at = self._event_time(e)
        elif t == "note":
            self._get(node_id)

    def snapshot_nodes(self):
        """Serialize the whole forest as a flat node list (parents before
        children), the inverse of from_snapshot. Used by the broker to serve a
        merged snapshot. Unset timestamps are emitted as 0.0 (the wire sentinel
        from_snapshot reads back as None)."""
        out = []

        def walk(node_id):
            n = self._nodes[node_id]
            out.append(
                {
                    "id": n.id,
                    "parent_id": n.parent_id or None,
                    "label": n.label,
                    "kind": n.kind,
                    "sizing": n.sizing,
                    "progress": n.progress,
                    "status": n.status,
                    "weight": n.weight,
                    "eta_group": n.eta_group,
                    "started_at": n.started_at or 0.0,
                    "ended_at": n.ended_at or 0.0,
                }
            )
            for c in self.children(node_id):
                walk(c)

        for r in self.roots():
            walk(r)
        return out

    def _load_node(self, jn):
        """Upsert one serialized node (from a snapshot or a producer resync)."""
        n = self._get(jn["id"])
        n.parent_id = jn.get("parent_id") or ""
        n.label = jn.get("label", "")
        n.kind = jn.get("kind", "")
        n.sizing = jn.get("sizing") or {"kind": "deferred"}
        n.progress = jn.get("progress", 0)
        n.status = jn.get("status", "pending")
        n.weight = jn.get("weight", 1.0)
        new_eg = jn.get("eta_group", "")
        if n.eta_group != new_eg:
            if n.eta_group:
                self._cohorts.get(n.eta_group, set()).discard(n.id)
            if new_eg:
                self._cohorts.setdefault(new_eg, set()).add(n.id)
            n.eta_group = new_eg
        # Producer-stamped timing (0 == unset). With set_clock_offset() the
        # joiner gets accurate, not join-relative, elapsed/ETA.
        sa = jn.get("started_at")
        ea = jn.get("ended_at")
        n.started_at = sa if sa else None
        n.ended_at = ea if ea else None
        self._record_order(n.parent_id, n.id)

    def apply_snapshot_nodes(self, nodes):
        """Merge a flat node list into this tree (producer resync). Each node is
        keyed by its (producer-unique) id, so this updates that producer's nodes
        without disturbing others'."""
        for jn in nodes:
            self._load_node(jn)

    @classmethod
    def from_snapshot(cls, nodes, clock=time.time):
        t = cls(clock=clock)
        t.apply_snapshot_nodes(nodes)
        return t

    # -- queries -----------------------------------------------------------
    def find(self, node_id):
        return self._nodes.get(node_id)

    def children(self, node_id):
        return list(self._order.get(node_id, ()))

    def roots(self):
        return self.children("")

    def is_leaf(self, node_id):
        return not self._order.get(node_id)

    def size(self):
        return len(self._nodes)

    # -- rollup (mirror of FractionOf) -------------------------------------
    def fraction(self, node_id):
        """Returns (known: bool, value: float in [0,1]). known=False => spinner."""
        n = self._nodes.get(node_id)
        if n is None:
            return (False, 0.0)
        kids = self.children(node_id)
        if not kids:
            if n.status in _TERMINAL:
                return (True, 1.0)
            kind = n.sizing.get("kind", "deferred")
            if kind == "determinate":
                total = n.sizing.get("total", 0)
                if total == 0:
                    return (True, 1.0)
                return (True, max(0.0, min(1.0, n.progress / total)))
            if kind == "deferred":
                return (True, 0.0)
            return (False, 0.0)  # indeterminate -> spinner
        # Weighted average of children: each child's `weight` scales how much it
        # contributes (e.g. a cheap pre-scheduling phase gets a small weight).
        acc = 0.0
        sum_w = 0.0
        for cid in kids:
            known, val = self.fraction(cid)
            if not known:
                return (False, 0.0)
            w = self._nodes[cid].weight
            acc += w * val
            sum_w += w
        return (True, acc / sum_w if sum_w > 0 else 1.0)

    def hint(self, node_id):
        """(done_children, known_children) -- annotates an unknown fraction."""
        done = known = 0
        for cid in self.children(node_id):
            cknown, _ = self.fraction(cid)
            if not cknown:
                continue
            known += 1
            c = self._nodes.get(cid)
            if c and c.status in _TERMINAL:
                done += 1
        return (done, known)

    # -- timing ------------------------------------------------------------
    def elapsed(self, node_id, now=None):
        """Seconds this node has been running (or ran). None if not started.
        Times are in the producer clock domain; `now` defaults to
        producer_now()."""
        n = self._nodes.get(node_id)
        if n is None or n.started_at is None:
            return None
        if now is None:
            now = self.producer_now()
        end = n.ended_at if n.ended_at is not None else now
        return max(0.0, end - n.started_at)

    def _own_eta(self, node_id, frac, now):
        """A node's ETA from its own progress rate: elapsed * (1-f)/f."""
        if frac <= 0.0:
            return None
        el = self.elapsed(node_id, now)
        if not el:
            return None
        return el * (1.0 - frac) / frac

    def _worst_projected_total(self, eta_group, now):
        """Max projected total duration (elapsed / fraction) over the started
        members of `eta_group`. This is the ETA assigned to an unstarted member
        of the cohort -- it assumes a pending node will take as long as the
        worst one observed so far. None if nothing in the cohort has started."""
        worst = None
        for n in self._nodes.values():
            if n.eta_group != eta_group:
                continue
            known, f = self.fraction(n.id)
            if not known or f <= 0.0:  # not started -> no projection
                continue
            el = self.elapsed(n.id, now)
            if el is None or el <= 0.0:
                continue
            projected = el / f
            worst = projected if worst is None else max(worst, projected)
        return worst

    def _cohort_eta(self, eta_group, now):
        """ETA of an eta_group node, treating its members as run sequentially:
        the worst (max) remaining time among running members, plus the full
        projected duration of every member that hasn't started. (Done members
        contribute nothing.) None if nothing in the cohort has started."""
        members = self._cohorts.get(eta_group)
        if not members:
            return None
        worst_proj = self._worst_projected_total(eta_group, now)  # pending estimate
        worst_running = None
        sum_pending = 0.0
        for mid in members:
            known, f = self.fraction(mid)
            if not known or f >= 1.0:  # indeterminate or done -> ignore
                continue
            if f > 0.0:  # running: its own remaining
                e = self._own_eta(mid, f, now)
                if e is not None:
                    worst_running = (
                        e if worst_running is None else max(worst_running, e)
                    )
            elif worst_proj is not None:  # not started: full worst-case duration
                sum_pending += worst_proj
        if worst_running is None and sum_pending == 0.0:
            return None
        return (worst_running or 0.0) + sum_pending

    def eta(self, node_id, now=None):
        """Estimated seconds remaining. None when it can't be estimated
        (indeterminate subtree, or nothing has progressed yet); 0 once complete.

        For an internal node the ETA is the MAX of its children's ETAs: a node
        cannot finish before its slowest child, so an ancestor never reports an
        earlier ETA than one of its descendants. Children that aren't estimable
        yet (a phase bar at 0 progress before its first tick) are skipped rather
        than blanking the parent -- otherwise a sibling building in parallel
        would hide its ETA. When no child yields a positive estimate (no
        children, all done, or none ticked yet) we fall back to the node's own
        progress-rate estimate so the node still shows something; that fallback
        can't undercut a child because there is no child ETA > 0 in that case."""
        if now is None:  # anchor once so a rollup is self-consistent
            now = self.producer_now()
        known, frac = self.fraction(node_id)
        if not known:
            return None
        if frac >= 1.0:
            return 0.0

        # If this node is an ETA cohort target, its ETA is the sequential total
        # of its members (worst running + every pending member's full estimate),
        # not the normal max-of-children rollup.
        if node_id in self._cohorts:
            ce = self._cohort_eta(node_id, now)
            if ce is not None:
                return ce

        best = None
        for cid in self.children(node_id):
            ce = self.eta(cid, now)
            if ce is None:  # child not estimable yet -> skip, don't blank
                continue
            best = ce if best is None else max(best, ce)
        if best is not None and best > 0.0:
            return best  # a progressing child gates completion

        own = self._own_eta(node_id, frac, now)
        if own is not None:
            return own
        # Not estimable from own progress (unstarted). If this node is in an ETA
        # cohort, estimate it as the worst projected total time of the cohort, so
        # a pending bar isn't treated as instant.
        n = self._nodes.get(node_id)
        if n is not None and n.eta_group:
            return self._worst_projected_total(n.eta_group, now)
        return None


# ---------------------------------------------------------------------------
# Transport: the late-joiner handshake (mirror of zmq_transport.cc)
# ---------------------------------------------------------------------------

DEFAULT_EVENT_URL = "ipc://compiler_state_events"
DEFAULT_SNAPSHOT_URL = "ipc://compiler_state_snapshot"
DEFAULT_TOPIC = "state"


class ZmqSubscriber:
    """Connects to a producer's PUB + snapshot ROUTER and maintains a StateTree.

    Usage: connect() once (performs the design-doc 7.1 handshake), then poll()
    in a loop. If needs_resnapshot becomes True, call connect() again.
    """

    def __init__(
        self,
        event_url=DEFAULT_EVENT_URL,
        snapshot_url=DEFAULT_SNAPSHOT_URL,
        topic=DEFAULT_TOPIC,
        context=None,
    ):
        import zmq  # imported lazily so StateTree stays dependency-free

        self._zmq = zmq
        self._ctx = context or zmq.Context.instance()
        self._topic = topic
        self.tree = StateTree()
        self.epoch = None
        self.applied_seq = 0
        self.needs_resnapshot = False

        # Subscribe BEFORE requesting the snapshot so nothing is lost.
        self._sub = self._ctx.socket(zmq.SUB)
        self._sub.setsockopt(zmq.LINGER, 0)
        self._sub.setsockopt_string(zmq.SUBSCRIBE, topic)
        self._sub.connect(event_url)
        self._snapshot_url = snapshot_url
        self._req = self._ctx.socket(zmq.REQ)
        self._req.setsockopt(zmq.LINGER, 0)
        self._req.connect(snapshot_url)

    def _new_req(self):
        """Recreate the snapshot REQ socket. A REQ socket enforces strict
        send/recv alternation, so a connect() that sent a request but timed out
        (producer not up yet) leaves it unable to send again. Starting each
        attempt from a fresh socket avoids that, and discards any stale reply
        from a previous attempt."""
        self._req.close(linger=0)
        self._req = self._ctx.socket(self._zmq.REQ)
        self._req.setsockopt(self._zmq.LINGER, 0)
        self._req.connect(self._snapshot_url)

    def _drain_sub(self, buffer):
        while True:
            try:
                frames = self._sub.recv_multipart(flags=self._zmq.NOBLOCK)
            except self._zmq.Again:
                return
            try:
                buffer.append(json.loads(frames[1]))
            except (IndexError, ValueError):
                pass

    def connect(self, timeout=5.0):
        """Perform the join handshake. Returns True if a snapshot arrived."""
        zmq = self._zmq
        buffer = []
        # Fresh REQ each attempt, so a prior timed-out round-trip can't wedge
        # the socket's send/recv state machine.
        self._new_req()
        self._req.send_multipart([b"snapshot"])

        snap = None
        poller = zmq.Poller()
        poller.register(self._sub, zmq.POLLIN)
        poller.register(self._req, zmq.POLLIN)
        deadline = time.time() + timeout
        while time.time() < deadline:
            socks = dict(poller.poll(timeout=20))
            if self._req in socks:
                snap = json.loads(self._req.recv())  # REQ strips the ROUTER envelope
                break
            if self._sub in socks:
                self._drain_sub(buffer)
        if snap is None:
            return False

        # Build from the snapshot, then apply the buffered suffix exactly once.
        self.epoch = snap["epoch"]
        S = snap["seq"]
        self.tree = StateTree.from_snapshot(snap["nodes"])
        # Align our clock to the producer's, so producer-stamped timestamps and
        # "now" agree even across hosts (corrects any clock skew).
        if "now" in snap:
            self.tree.set_clock_offset(time.time() - snap["now"])
        self.applied_seq = S
        self.needs_resnapshot = False

        self._drain_sub(buffer)
        buffer.sort(key=lambda ev: ev.get("seq", 0))
        for ev in buffer:
            if ev.get("epoch") != self.epoch:
                continue
            if ev.get("seq", 0) <= S:
                continue
            self.tree.apply(ev)
            self.applied_seq = ev["seq"]
        return True

    def _apply(self, payload):
        try:
            ev = json.loads(payload)
        except ValueError:
            return
        if ev.get("epoch") != self.epoch:  # producer restarted
            self.needs_resnapshot = True
            return
        seq = ev.get("seq", 0)
        if seq <= self.applied_seq:
            return
        if seq != self.applied_seq + 1:  # gap: missed events
            self.needs_resnapshot = True
        self.tree.apply(ev)
        self.applied_seq = seq

    def poll(self, block_ms=0):
        """Apply available live events. Returns the count applied."""
        zmq = self._zmq
        applied = 0
        deadline = time.time() + block_ms / 1000.0
        while True:
            try:
                frames = self._sub.recv_multipart(flags=zmq.NOBLOCK)
                self._apply(frames[1])
                applied += 1
                continue
            except zmq.Again:
                pass
            if applied == 0 and time.time() < deadline:
                time.sleep(0.005)
                continue
            break
        return applied

    def close(self):
        self._sub.close()
        self._req.close()
