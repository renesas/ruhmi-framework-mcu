"""mera_progress_viewer -- a live TUI for MERA compiles with progress enabled.

When a deploy sets ``scheduler_config.progress_bars``, ``mera.deploy`` starts an
in-process one-to-many relay and prints how to attach a viewer keyed by the deploy
process pid. Run::

    mera_progress_viewer --pid <pid>

to watch the compile's progress live in another terminal. It opens on the overall
overview (rolled-up percentage + ETA); press ``d`` to toggle the per-node work
breakdown (spinners, elapsed, ETA, iteration counts) and scroll it with the arrow
keys.
"""

__all__ = ["state_model", "endpoints", "relay", "tui", "cli"]
